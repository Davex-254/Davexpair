const { Pool } = require('pg');

let pool = null;
let pgAvailable = false;
let pgInitialized = false;

// ONLY settings tables - removed everything else
const PG_TABLES_SQL = `
    CREATE TABLE IF NOT EXISTS owner_settings (
        setting_key TEXT PRIMARY KEY,
        setting_value TEXT NOT NULL,
        updated_at BIGINT DEFAULT (EXTRACT(EPOCH FROM NOW()))
    );
    CREATE TABLE IF NOT EXISTS group_settings (
        group_jid TEXT NOT NULL,
        setting_key TEXT NOT NULL,
        setting_value TEXT NOT NULL,
        updated_at BIGINT DEFAULT (EXTRACT(EPOCH FROM NOW())),
        PRIMARY KEY (group_jid, setting_key)
    );
`;

// Queue for batch writes (prevents connection flooding)
const writeQueue = [];
let queueProcessor = null;

function getPgUrl() {
    return process.env.DATABASE_URL || process.env.HEROKU_DATABASE_URL || null;
}

async function initPg() {
    if (pgInitialized) return pgAvailable;
    pgInitialized = true;
    
    const url = getPgUrl();
    if (!url) {
        console.log('[ DAVE-X ][PG] No DATABASE_URL found - using SQLite only');
        return false;
    }

    try {
        pool = new Pool({
            connectionString: url,
            ssl: { rejectUnauthorized: false },
            max: 2,                    // Only 2 connections max
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 5000, // 5 second timeout
            statement_timeout: 5000     // 5 second query timeout
        });

        // Test connection
        await pool.query('SELECT 1');
        await pool.query(PG_TABLES_SQL);
        pgAvailable = true;
        
        // Start queue processor
        startQueueProcessor();
        
        console.log('[ DAVE-X ][PG] PostgreSQL connected (settings only)');
        return true;
    } catch (err) {
        console.log('[ DAVE-X ][PG] PostgreSQL unavailable:', err.message);
        pgAvailable = false;
        return false;
    }
}

function startQueueProcessor() {
    if (queueProcessor) clearInterval(queueProcessor);
    
    queueProcessor = setInterval(() => {
        if (!pgAvailable || writeQueue.length === 0) return;
        
        const batch = writeQueue.splice(0, 20);
        const promises = batch.map(op => {
            if (op.type === 'owner') {
                return pool.query(
                    'INSERT INTO owner_settings (setting_key, setting_value, updated_at) VALUES ($1, $2, EXTRACT(EPOCH FROM NOW())) ON CONFLICT (setting_key) DO UPDATE SET setting_value = $2, updated_at = EXTRACT(EPOCH FROM NOW())',
                    [op.key, op.value]
                );
            } else if (op.type === 'group') {
                return pool.query(
                    'INSERT INTO group_settings (group_jid, setting_key, setting_value, updated_at) VALUES ($1, $2, $3, EXTRACT(EPOCH FROM NOW())) ON CONFLICT (group_jid, setting_key) DO UPDATE SET setting_value = $3, updated_at = EXTRACT(EPOCH FROM NOW())',
                    [op.groupJid, op.key, op.value]
                );
            }
        });
        
        Promise.allSettled(promises).catch(() => {});
    }, 2000);
}

// Load settings from PostgreSQL to SQLite on startup
async function loadSettingsToSqlite(sqliteDb) {
    if (!pgAvailable || !pool) return 0;

    let loaded = 0;
    try {
        // Load owner settings
        const ownerRows = await pool.query('SELECT setting_key, setting_value FROM owner_settings');
        for (const row of ownerRows.rows) {
            sqliteDb.prepare('INSERT OR REPLACE INTO owner_settings (setting_key, setting_value, updated_at) VALUES (?, ?, strftime(\'%s\', \'now\'))')
                .run(row.setting_key, row.setting_value);
            loaded++;
        }

        // Load group settings
        const groupRows = await pool.query('SELECT group_jid, setting_key, setting_value FROM group_settings');
        for (const row of groupRows.rows) {
            sqliteDb.prepare('INSERT OR REPLACE INTO group_settings (group_jid, setting_key, setting_value, updated_at) VALUES (?, ?, ?, strftime(\'%s\', \'now\'))')
                .run(row.group_jid, row.setting_key, row.setting_value);
            loaded++;
        }

        if (loaded > 0) {
            console.log(`[ DAVE-X ][PG] Loaded ${loaded} settings from PostgreSQL`);
        }
    } catch (err) {
        console.log('[ DAVE-X ][PG] Load from PG failed:', err.message);
    }
    return loaded;
}

// Queue functions (non-blocking)
function queueOwnerSetting(key, value) {
    if (!pgAvailable) return;
    writeQueue.push({ 
        type: 'owner', 
        key, 
        value: JSON.stringify(value) 
    });
}

function queueGroupSetting(groupJid, key, value) {
    if (!pgAvailable) return;
    writeQueue.push({ 
        type: 'group', 
        groupJid, 
        key, 
        value: JSON.stringify(value) 
    });
}

function queueDeleteGroupSetting(groupJid, key) {
    if (!pgAvailable) return;
    writeQueue.push({ 
        type: 'group', 
        groupJid, 
        key, 
        value: null,
        isDelete: true 
    });
}

async function closePg() {
    if (queueProcessor) {
        clearInterval(queueProcessor);
        queueProcessor = null;
    }
    
    // Process remaining queue items
    if (pgAvailable && writeQueue.length > 0) {
        console.log(`[ DAVE-X ][PG] Flushing ${writeQueue.length} pending writes...`);
        const batch = writeQueue.splice(0, writeQueue.length);
        for (const op of batch) {
            try {
                if (op.type === 'owner') {
                    await pool.query(
                        'INSERT INTO owner_settings (setting_key, setting_value, updated_at) VALUES ($1, $2, EXTRACT(EPOCH FROM NOW())) ON CONFLICT (setting_key) DO UPDATE SET setting_value = $2, updated_at = EXTRACT(EPOCH FROM NOW())',
                        [op.key, op.value]
                    );
                } else if (op.type === 'group' && !op.isDelete) {
                    await pool.query(
                        'INSERT INTO group_settings (group_jid, setting_key, setting_value, updated_at) VALUES ($1, $2, $3, EXTRACT(EPOCH FROM NOW())) ON CONFLICT (group_jid, setting_key) DO UPDATE SET setting_value = $3, updated_at = EXTRACT(EPOCH FROM NOW())',
                        [op.groupJid, op.key, op.value]
                    );
                } else if (op.type === 'group' && op.isDelete) {
                    await pool.query('DELETE FROM group_settings WHERE group_jid = $1 AND setting_key = $2', [op.groupJid, op.key]);
                }
            } catch (e) {}
        }
    }
    
    if (pool) {
        try { await pool.end(); } catch {}
        pool = null;
        pgAvailable = false;
    }
}

module.exports = {
    initPg,
    loadSettingsToSqlite, // Renamed from loadFromPg
    closePg,
    // Only settings functions remain
    queueOwnerSetting,
    queueGroupSetting,
    queueDeleteGroupSetting
};