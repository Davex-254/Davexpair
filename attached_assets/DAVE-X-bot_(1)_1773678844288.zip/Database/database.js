const path = require('path');
const fs = require('fs');
const pg = require('./pgSync');

// ============================================================
// PATH CONFIGURATION
// ============================================================
const STORAGE_PATH = process.env.STORAGE_PATH || path.join(process.cwd(), 'storage');
const SESSIONS_PATH = process.env.SESSION_PATH || path.join(process.cwd(), 'session');
const DB_PATH = process.env.SQLITE_PATH || path.join(STORAGE_PATH, 'davex.db');

// Create directories if they don't exist
if (!fs.existsSync(STORAGE_PATH)) {
    fs.mkdirSync(STORAGE_PATH, { recursive: true });
}
if (!fs.existsSync(SESSIONS_PATH)) {
    fs.mkdirSync(SESSIONS_PATH, { recursive: true });
}

console.log(`[ DAVE-X ] Storage: ${STORAGE_PATH}`);
console.log(`[ DAVE-X ] Sessions: ${SESSIONS_PATH}`);
console.log(`[ DAVE-X ] Database: ${DB_PATH}`);

// ============================================================
// SQLITE INITIALIZATION
// ============================================================
let db = null;
const Database = require('better-sqlite3');

// SQLite tables - ALL tables still exist in SQLite
const SQLITE_TABLE_SQL = `
    CREATE TABLE IF NOT EXISTS owner_settings (
        setting_key TEXT PRIMARY KEY,
        setting_value TEXT NOT NULL,
        updated_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
    CREATE TABLE IF NOT EXISTS group_settings (
        group_jid TEXT NOT NULL,
        setting_key TEXT NOT NULL,
        setting_value TEXT NOT NULL,
        updated_at INTEGER DEFAULT (strftime('%s', 'now')),
        PRIMARY KEY (group_jid, setting_key)
    );
    CREATE TABLE IF NOT EXISTS warnings (
        group_jid TEXT NOT NULL,
        user_jid TEXT NOT NULL,
        count INTEGER DEFAULT 0,
        updated_at INTEGER DEFAULT (strftime('%s', 'now')),
        PRIMARY KEY (group_jid, user_jid)
    );
    CREATE TABLE IF NOT EXISTS banned_users (
        user_jid TEXT PRIMARY KEY,
        reason TEXT,
        banned_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
    CREATE TABLE IF NOT EXISTS sudo_users (
        user_jid TEXT PRIMARY KEY,
        added_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
    CREATE TABLE IF NOT EXISTS premium_users (
        user_jid TEXT PRIMARY KEY,
        expires_at INTEGER,
        added_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
    CREATE TABLE IF NOT EXISTS message_store (
        message_id TEXT PRIMARY KEY,
        chat_jid TEXT NOT NULL,
        sender_jid TEXT NOT NULL,
        content TEXT,
        media_type TEXT,
        media_path TEXT,
        is_view_once INTEGER DEFAULT 0,
        push_name TEXT,
        timestamp INTEGER DEFAULT (strftime('%s', 'now'))
    );
    CREATE TABLE IF NOT EXISTS message_counts (
        group_jid TEXT NOT NULL,
        user_jid TEXT NOT NULL,
        count INTEGER DEFAULT 0,
        PRIMARY KEY (group_jid, user_jid)
    );
    CREATE INDEX IF NOT EXISTS idx_group_settings_jid ON group_settings(group_jid);
    CREATE INDEX IF NOT EXISTS idx_message_store_chat ON message_store(chat_jid);
    CREATE INDEX IF NOT EXISTS idx_message_store_timestamp ON message_store(timestamp);
    CREATE INDEX IF NOT EXISTS idx_msg_counts_group ON message_counts(group_jid);
`;

let checkpointInterval = null;

function initSQLite() {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('synchronous = NORMAL'); // Changed from FULL for speed
    db.pragma('cache_size = -4000');   // Increased cache
    db.exec(SQLITE_TABLE_SQL);
    
    try {
        db.exec(`ALTER TABLE message_store ADD COLUMN push_name TEXT`);
    } catch {}

    checkpointInterval = setInterval(() => {
        try {
            if (db) db.pragma('wal_checkpoint(TRUNCATE)');
        } catch {}
    }, 60000); // Checkpoint every minute instead of 30 seconds

    const settingsCount = db.prepare('SELECT COUNT(*) as c FROM owner_settings').get().c;
    const groupCount = db.prepare('SELECT COUNT(DISTINCT group_jid) as c FROM group_settings').get().c;
    console.log(`[ DAVE-X ] SQLite database ready | ${settingsCount} settings, ${groupCount} groups`);
}

function getDb() {
    if (!db) {
        initSQLite();
    }
    return db;
}

// ============================================================
// DATABASE INITIALIZATION
// ============================================================
async function initDatabase() {
    initSQLite();
    
    // Try to connect to PostgreSQL
    const pgReady = await pg.initPg();
    
    if (pgReady) {
        // Load existing settings from PostgreSQL into SQLite
        await pg.loadSettingsToSqlite(db);
        // Signal settingsStore to flush its stale pre-PG cache
        process.emit('pgSettingsLoaded');
        console.log('[ DAVE-X ] Database ready (SQLite + PostgreSQL for settings)');
    } else {
        console.log('[ DAVE-X ] Database ready (SQLite only)');
    }
}

// Initialize on load
initDatabase().catch(e => {
    console.error('[ DAVE-X ] Database init error:', e.message);
});

// ============================================================
// SETTINGS FUNCTIONS - Write to BOTH (SQLite immediate + PostgreSQL queued)
// ============================================================

function setOwnerSetting(key, value) {
    const val = JSON.stringify(value);
    const database = getDb();
    
    // Write to SQLite immediately (fast)
    const stmt = database.prepare(`INSERT OR REPLACE INTO owner_settings (setting_key, setting_value, updated_at) VALUES (?, ?, strftime('%s', 'now'))`);
    stmt.run(key, val);
    
    // Queue for PostgreSQL (non-blocking)
    pg.queueOwnerSetting(key, value);
}

function getOwnerSetting(key, defaultValue = null) {
    const database = getDb();
    const stmt = database.prepare('SELECT setting_value FROM owner_settings WHERE setting_key = ?');
    const row = stmt.get(key);
    if (row) {
        try { return JSON.parse(row.setting_value); } catch { return row.setting_value; }
    }
    return defaultValue;
}

function getAllOwnerSettings() {
    const database = getDb();
    const stmt = database.prepare('SELECT setting_key, setting_value FROM owner_settings');
    const rows = stmt.all();
    const settings = {};
    for (const row of rows) {
        try { settings[row.setting_key] = JSON.parse(row.setting_value); } catch { settings[row.setting_key] = row.setting_value; }
    }
    return settings;
}

function setGroupSetting(groupJid, key, value) {
    const val = JSON.stringify(value);
    const database = getDb();
    
    // Write to SQLite immediately
    const stmt = database.prepare(`INSERT OR REPLACE INTO group_settings (group_jid, setting_key, setting_value, updated_at) VALUES (?, ?, ?, strftime('%s', 'now'))`);
    stmt.run(groupJid, key, val);
    
    // Queue for PostgreSQL
    pg.queueGroupSetting(groupJid, key, value);
}

function getGroupSetting(groupJid, key, defaultValue = null) {
    const database = getDb();
    const stmt = database.prepare('SELECT setting_value FROM group_settings WHERE group_jid = ? AND setting_key = ?');
    const row = stmt.get(groupJid, key);
    if (row) {
        try { return JSON.parse(row.setting_value); } catch { return row.setting_value; }
    }
    return defaultValue;
}

function getAllGroupSettings(groupJid) {
    const database = getDb();
    const stmt = database.prepare('SELECT setting_key, setting_value FROM group_settings WHERE group_jid = ?');
    const rows = stmt.all(groupJid);
    const settings = {};
    for (const row of rows) {
        try { settings[row.setting_key] = JSON.parse(row.setting_value); } catch { settings[row.setting_key] = row.setting_value; }
    }
    return settings;
}

function getAllGroupJids() {
    const database = getDb();
    try {
        const rows = database.prepare('SELECT DISTINCT group_jid FROM group_settings').all();
        return rows.map(r => r.group_jid);
    } catch { return []; }
}

function deleteGroupSetting(groupJid, key) {
    const database = getDb();
    
    // Delete from SQLite
    const stmt = database.prepare('DELETE FROM group_settings WHERE group_jid = ? AND setting_key = ?');
    stmt.run(groupJid, key);
    
    // Queue delete for PostgreSQL
    pg.queueDeleteGroupSetting(groupJid, key);
}

function hasGroupSetting(groupJid, key) {
    const database = getDb();
    const stmt = database.prepare('SELECT 1 FROM group_settings WHERE group_jid = ? AND setting_key = ?');
    return !!stmt.get(groupJid, key);
}

// ============================================================
// WARNINGS FUNCTIONS - SQLite ONLY (high frequency)
// ============================================================

function getWarningCount(groupJid, userJid) {
    const database = getDb();
    const stmt = database.prepare('SELECT count FROM warnings WHERE group_jid = ? AND user_jid = ?');
    const row = stmt.get(groupJid, userJid);
    return row ? row.count : 0;
}

function incrementWarning(groupJid, userJid) {
    const database = getDb();
    const current = getWarningCount(groupJid, userJid);
    const newCount = current + 1;
    const stmt = database.prepare(`INSERT OR REPLACE INTO warnings (group_jid, user_jid, count, updated_at) VALUES (?, ?, ?, strftime('%s', 'now'))`);
    stmt.run(groupJid, userJid, newCount);
    return newCount;
}

function resetWarning(groupJid, userJid) {
    const database = getDb();
    const stmt = database.prepare('DELETE FROM warnings WHERE group_jid = ? AND user_jid = ?');
    stmt.run(groupJid, userJid);
}

function setWarningCount(groupJid, userJid, count) {
    if (count <= 0) {
        resetWarning(groupJid, userJid);
        return 0;
    }
    const database = getDb();
    const stmt = database.prepare(`INSERT OR REPLACE INTO warnings (group_jid, user_jid, count, updated_at) VALUES (?, ?, ?, strftime('%s', 'now'))`);
    stmt.run(groupJid, userJid, count);
    return count;
}

function getAllWarnings() {
    const warnings = {};
    const database = getDb();
    const stmt = database.prepare('SELECT group_jid, user_jid, count FROM warnings');
    const rows = stmt.all();
    for (const row of rows) {
        if (!warnings[row.group_jid]) warnings[row.group_jid] = {};
        warnings[row.group_jid][row.user_jid] = row.count;
    }
    return warnings;
}

// ============================================================
// BANNED USERS FUNCTIONS - SQLite ONLY
// ============================================================

function addBannedUser(userJid, reason = '') {
    const database = getDb();
    const stmt = database.prepare(`INSERT OR REPLACE INTO banned_users (user_jid, reason, banned_at) VALUES (?, ?, strftime('%s', 'now'))`);
    stmt.run(userJid, reason);
}

function removeBannedUser(userJid) {
    const database = getDb();
    const stmt = database.prepare('DELETE FROM banned_users WHERE user_jid = ?');
    stmt.run(userJid);
}

function isBanned(userJid) {
    const database = getDb();
    const stmt = database.prepare('SELECT 1 FROM banned_users WHERE user_jid = ?');
    return !!stmt.get(userJid);
}

function getAllBannedUsers() {
    const database = getDb();
    const stmt = database.prepare('SELECT user_jid, reason, banned_at FROM banned_users');
    return stmt.all();
}

// ============================================================
// SUDO USERS FUNCTIONS - SQLite ONLY
// ============================================================

function addSudoUser(userJid) {
    const database = getDb();
    const stmt = database.prepare(`INSERT OR IGNORE INTO sudo_users (user_jid, added_at) VALUES (?, strftime('%s', 'now'))`);
    stmt.run(userJid);
}

function removeSudoUser(userJid) {
    const database = getDb();
    const stmt = database.prepare('DELETE FROM sudo_users WHERE user_jid = ?');
    stmt.run(userJid);
}

function isSudo(userJid) {
    const database = getDb();
    const stmt = database.prepare('SELECT 1 FROM sudo_users WHERE user_jid = ?');
    return !!stmt.get(userJid);
}

function getAllSudoUsers() {
    const database = getDb();
    const stmt = database.prepare('SELECT user_jid FROM sudo_users');
    return stmt.all().map(row => row.user_jid);
}

// ============================================================
// PREMIUM USERS FUNCTIONS - SQLite ONLY
// ============================================================

function addPremiumUser(userJid, expiresAt) {
    const database = getDb();
    const stmt = database.prepare(`INSERT OR REPLACE INTO premium_users (user_jid, expires_at, added_at) VALUES (?, ?, strftime('%s', 'now'))`);
    stmt.run(userJid, expiresAt);
}

function removePremiumUser(userJid) {
    const database = getDb();
    const stmt = database.prepare('DELETE FROM premium_users WHERE user_jid = ?');
    stmt.run(userJid);
}

function isPremium(userJid) {
    const database = getDb();
    const row = database.prepare('SELECT expires_at FROM premium_users WHERE user_jid = ?').get(userJid);
    if (!row) return false;
    return row.expires_at > Math.floor(Date.now() / 1000);
}

function getAllPremiumUsers() {
    const database = getDb();
    const stmt = database.prepare('SELECT user_jid, expires_at, added_at FROM premium_users');
    return stmt.all();
}

// ============================================================
// MESSAGE STORE FUNCTIONS - SQLite ONLY
// ============================================================

function storeMessage(messageId, chatJid, senderJid, content, mediaType = null, mediaPath = null, isViewOnce = false, pushName = null) {
    const database = getDb();
    const stmt = database.prepare(`INSERT OR REPLACE INTO message_store (message_id, chat_jid, sender_jid, content, media_type, media_path, is_view_once, push_name, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, strftime('%s', 'now'))`);
    stmt.run(messageId, chatJid, senderJid, content, mediaType, mediaPath, isViewOnce ? 1 : 0, pushName);
}

function getMessage(messageId) {
    const database = getDb();
    const stmt = database.prepare('SELECT * FROM message_store WHERE message_id = ?');
    return stmt.get(messageId);
}

function deleteMessage(messageId) {
    const database = getDb();
    const stmt = database.prepare('DELETE FROM message_store WHERE message_id = ?');
    stmt.run(messageId);
}

function cleanOldMessages(maxAgeSeconds = 86400) {
    const cutoff = Math.floor(Date.now() / 1000) - maxAgeSeconds;
    const database = getDb();
    const stmt = database.prepare('DELETE FROM message_store WHERE timestamp < ?');
    const result = stmt.run(cutoff);
    return result.changes;
}

function getMessageCount() {
    const database = getDb();
    const stmt = database.prepare('SELECT COUNT(*) as count FROM message_store');
    return stmt.get().count;
}

function getMessagesByChat(chatJid, limit = 100) {
    const database = getDb();
    const stmt = database.prepare('SELECT * FROM message_store WHERE chat_jid = ? ORDER BY timestamp DESC LIMIT ?');
    return stmt.all(chatJid, limit);
}

// ============================================================
// MESSAGE COUNTS FUNCTIONS - SQLite ONLY (high frequency)
// ============================================================

function incrementMsgCount(groupJid, userJid) {
    const database = getDb();
    database.prepare(`
        INSERT INTO message_counts (group_jid, user_jid, count) VALUES (?, ?, 1)
        ON CONFLICT(group_jid, user_jid) DO UPDATE SET count = count + 1
    `).run(groupJid, userJid);
}

function getGroupMsgCounts(groupJid) {
    const database = getDb();
    const rows = database.prepare('SELECT user_jid, count FROM message_counts WHERE group_jid = ? ORDER BY count DESC').all(groupJid);
    const result = {};
    for (const row of rows) result[row.user_jid] = row.count;
    return result;
}

function getAllGroupMsgCountJids() {
    const database = getDb();
    const rows = database.prepare('SELECT DISTINCT group_jid FROM message_counts').all();
    return rows.map(r => r.group_jid);
}

function resetGroupMsgCounts(groupJid) {
    const database = getDb();
    database.prepare('DELETE FROM message_counts WHERE group_jid = ?').run(groupJid);
}

function getGroupTotalMsgCount(groupJid) {
    const database = getDb();
    const row = database.prepare('SELECT SUM(count) as total FROM message_counts WHERE group_jid = ?').get(groupJid);
    return row?.total || 0;
}

function getUserMsgCount(groupJid, userJid) {
    const database = getDb();
    const row = database.prepare('SELECT count FROM message_counts WHERE group_jid = ? AND user_jid = ?').get(groupJid, userJid);
    return row?.count || 0;
}

// ============================================================
// BOT MODE FUNCTIONS (uses settings)
// ============================================================

function getBotMode() {
    return getOwnerSetting('bot_mode', 'public');
}

function setBotMode(mode) {
    setOwnerSetting('bot_mode', mode);
}

// ============================================================
// CLEANUP
// ============================================================

function closeDb() {
    if (checkpointInterval) {
        clearInterval(checkpointInterval);
        checkpointInterval = null;
    }
    
    // Close PostgreSQL first (flushes queue)
    pg.closePg().catch(() => {});
    
    if (db) {
        try {
            db.pragma('wal_checkpoint(TRUNCATE)');
        } catch {}
        try {
            db.close();
        } catch {}
        db = null;
        console.log('[ DAVE-X ] Database closed safely');
    }
}

process.on('exit', closeDb);
process.on('SIGINT', () => { closeDb(); process.exit(); });
process.on('SIGTERM', () => { closeDb(); process.exit(); });
process.on('SIGHUP', () => { closeDb(); process.exit(); });

// ============================================================
// EXPORTS
// ============================================================
module.exports = {
    getDb,
    initDatabase,
    
    // Settings (SQLite + PostgreSQL)
    setOwnerSetting,
    getOwnerSetting,
    getAllOwnerSettings,
    setGroupSetting,
    getGroupSetting,
    getAllGroupSettings,
    getAllGroupJids,
    deleteGroupSetting,
    hasGroupSetting,
    
    // Warnings (SQLite only)
    getWarningCount,
    incrementWarning,
    resetWarning,
    setWarningCount,
    getAllWarnings,
    
    // Banned users (SQLite only)
    addBannedUser,
    removeBannedUser,
    isBanned,
    getAllBannedUsers,
    
    // Sudo users (SQLite only)
    addSudoUser,
    removeSudoUser,
    isSudo,
    getAllSudoUsers,
    
    // Premium users (SQLite only)
    addPremiumUser,
    removePremiumUser,
    isPremium,
    getAllPremiumUsers,
    
    // Message store (SQLite only)
    storeMessage,
    getMessage,
    getMessagesByChat,
    deleteMessage,
    cleanOldMessages,
    getMessageCount,
    
    // Message counts (SQLite only)
    incrementMsgCount,
    getGroupMsgCounts,
    getAllGroupMsgCountJids,
    resetGroupMsgCounts,
    getGroupTotalMsgCount,
    getUserMsgCount,
    
    // Bot mode
    getBotMode,
    setBotMode,
    
    closeDb
};