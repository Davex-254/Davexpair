const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const db = require('../../Database/database');
const isAdmin = require('../../davelib/isAdmin');

function parseDateTime(str) {
    const d = new Date(str);
    if (!isNaN(d.getTime())) return d;
    return null;
}

async function createeventCommand(sock, chatId, message, fullArgs) {
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const isGroup = chatId.endsWith('@g.us');

    if (!isGroup) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nThis command only works in groups.`
        }, { quoted: fake });
    }

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
    const isOwner = message.key.fromMe || db.isSudo(senderId);

    if (!isSenderAdmin && !isOwner) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nAdmin only command!`
        }, { quoted: fake });
    }

    const args = (fullArgs || '').trim();

    if (!args) {
        return sock.sendMessage(chatId, {
            text: `*${botName} CREATE EVENT*\n\n` +
                `Usage:\n` +
                `createevent <name>; <description>; <start>; [end]\n\n` +
                `Date format: YYYY-MM-DD HH:MM or ISO string\n\n` +
                `Example:\n` +
                `createevent Dev Meeting; Weekly dev sync; 2026-03-15 10:00; 2026-03-15 12:00\n\n` +
                `End date is optional.`
        }, { quoted: fake });
    }

    const parts = args.split(';').map(p => p.trim());

    if (parts.length < 3) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nNeed at least: name; description; start date\n\nUse: createevent help`
        }, { quoted: fake });
    }

    const name = parts[0];
    const description = parts[1];
    const startStr = parts[2];
    const endStr = parts[3] || null;

    const startDate = parseDateTime(startStr);
    if (!startDate) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nInvalid start date: "${startStr}"\nUse format: 2026-03-15 10:00`
        }, { quoted: fake });
    }

    const endDate = endStr ? parseDateTime(endStr) : null;
    if (endStr && !endDate) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nInvalid end date: "${endStr}"\nUse format: 2026-03-15 12:00`
        }, { quoted: fake });
    }

    if (name.length > 255) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nEvent name too long (max 255 chars).`
        }, { quoted: fake });
    }

    try {
        await sock.sendMessage(chatId, {
            event: {
                name,
                description,
                startDate,
                endDate: endDate || undefined,
                isCancelled: false,
                extraGuestsAllowed: true,
                isScheduleCall: false
            }
        });

        await sock.sendMessage(chatId, { react: { text: '📅', key: message.key } });
    } catch (err) {
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
        await sock.sendMessage(chatId, {
            text: `*${botName}*\nFailed to create event: ${err.message}`
        }, { quoted: fake });
    }
}

module.exports = { createeventCommand };
