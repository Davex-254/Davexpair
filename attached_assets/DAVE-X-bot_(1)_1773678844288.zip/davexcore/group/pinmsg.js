const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const db = require('../../Database/database');
const isAdmin = require('../../davelib/isAdmin');

async function pinmsgCommand(sock, chatId, message, fullArgs) {
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const isGroup = chatId.endsWith('@g.us');

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
    const isOwner = message.key.fromMe || db.isSudo(senderId);

    if (!isSenderAdmin && !isOwner) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nAdmin only command!`
        }, { quoted: fake });
    }

    if (!isBotAdmin && isGroup) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nBot needs to be admin to pin messages.`
        }, { quoted: fake });
    }

    // Get the quoted message key to pin
    const quoted = message.message?.extendedTextMessage?.contextInfo;
    if (!quoted?.stanzaId) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nQuote a message to pin it.\n\nExample: Quote any message and send pinmsg`
        }, { quoted: fake });
    }

    const keyToPinJid = quoted.remoteJid || chatId;
    const keyToPin = {
        remoteJid: chatId,
        id: quoted.stanzaId,
        fromMe: quoted.participant ? false : true,
        participant: quoted.participant || undefined
    };

    // duration: 0 = unpin, 86400 = 24h, 604800 = 7d, 2592000 = 30d
    const args = (fullArgs || '').trim().toLowerCase();
    let duration = 86400; // default 24 hours
    if (args.includes('7') || args.includes('week')) duration = 604800;
    else if (args.includes('30') || args.includes('month')) duration = 2592000;
    else if (args.includes('24') || args.includes('day')) duration = 86400;

    try {
        await sock.sendMessage(chatId, {
            pin: { type: 1, time: duration, key: keyToPin }
        });

        const durationStr = duration === 86400 ? '24 hours' : duration === 604800 ? '7 days' : '30 days';
        await sock.sendMessage(chatId, { react: { text: '📌', key: message.key } });
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n📌 Message pinned for ${durationStr}!`
        }, { quoted: fake });
    } catch (err) {
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
        await sock.sendMessage(chatId, {
            text: `*${botName}*\nFailed to pin message: ${err.message}`
        }, { quoted: fake });
    }
}

async function unpinmsgCommand(sock, chatId, message) {
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const isGroup = chatId.endsWith('@g.us');

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
    const isOwner = message.key.fromMe || db.isSudo(senderId);

    if (!isSenderAdmin && !isOwner) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nAdmin only command!`
        }, { quoted: fake });
    }

    if (!isBotAdmin && isGroup) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nBot needs to be admin to unpin messages.`
        }, { quoted: fake });
    }

    const quoted = message.message?.extendedTextMessage?.contextInfo;
    if (!quoted?.stanzaId) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nQuote the pinned message you want to unpin.`
        }, { quoted: fake });
    }

    const keyToUnpin = {
        remoteJid: chatId,
        id: quoted.stanzaId,
        fromMe: quoted.participant ? false : true,
        participant: quoted.participant || undefined
    };

    try {
        await sock.sendMessage(chatId, {
            pin: { type: 2, time: 0, key: keyToUnpin }
        });

        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n✅ Message unpinned!`
        }, { quoted: fake });
    } catch (err) {
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
        await sock.sendMessage(chatId, {
            text: `*${botName}*\nFailed to unpin message: ${err.message}`
        }, { quoted: fake });
    }
}

module.exports = { pinmsgCommand, unpinmsgCommand };
