const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const db = require('../../Database/database');
const isAdmin = require('../../davelib/isAdmin');

async function memberlabelCommand(sock, chatId, message, fullArgs) {
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const isGroup = chatId.endsWith('@g.us');

    if (!isGroup) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nThis command only works in groups.`
        }, { quoted: fake });
    }

    const { isSenderAdmin } = await isAdmin(sock, chatId, senderId);
    const isOwner = message.key.fromMe || db.isSudo(senderId);

    if (!isSenderAdmin && !isOwner) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nAdmin only command!`
        }, { quoted: fake });
    }

    const args = (fullArgs || '').trim();

    if (!args) {
        return sock.sendMessage(chatId, {
            text: `*${botName} MEMBER LABEL*\n\n` +
                `Set a custom label/tag for a group member.\n\n` +
                `Usage: memberlabel @user label\n\n` +
                `Example:\n` +
                `memberlabel @254712345678 VIP\n` +
                `memberlabel @254712345678 Moderator\n\n` +
                `Label max 30 characters.\n` +
                `Requires: quote someone's message OR @mention them.`
        }, { quoted: fake });
    }

    // Get target from quoted message or mention
    let targetJid = null;

    const quoted = message.message?.extendedTextMessage?.contextInfo;
    if (quoted?.participant) {
        targetJid = quoted.participant;
    } else if (quoted?.remoteJid && !quoted.remoteJid.endsWith('@g.us')) {
        targetJid = quoted.remoteJid;
    }

    if (!targetJid && quoted?.mentionedJid?.length) {
        targetJid = quoted.mentionedJid[0];
    }

    const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!targetJid && mentions.length) {
        targetJid = mentions[0];
    }

    // Parse label — everything after the @mention or first word if no mention
    let label = args;
    if (mentions.length) {
        const mentionNum = targetJid?.split('@')[0];
        label = args.replace(new RegExp(`@${mentionNum}\\s*`), '').trim();
    }

    if (!targetJid) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nPlease quote a message or @mention the member to label.`
        }, { quoted: fake });
    }

    if (!label) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nPlease provide a label text after the @mention.`
        }, { quoted: fake });
    }

    if (label.length > 30) {
        label = label.slice(0, 30);
    }

    try {
        // Ensure targetJid is in the correct format
        if (!targetJid.includes('@')) {
            targetJid = targetJid + '@s.whatsapp.net';
        }

        await sock.updateMemberLabel(chatId, label);

        const targetNum = targetJid.split('@')[0];
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n✅ Member label set!\n\n@${targetNum} → "${label}"`,
            mentions: [targetJid]
        }, { quoted: fake });
    } catch (err) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\nFailed to set label: ${err.message}`
        }, { quoted: fake });
    }
}

module.exports = { memberlabelCommand };
