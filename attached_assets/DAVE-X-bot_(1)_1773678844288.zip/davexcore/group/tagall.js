const isAdmin = require('../../davelib/isAdmin');
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

const { resolvePhoneFromLid, resolveSenderFromGroup, isLidJid, cacheLidPhone } = require('../../davelib/lidResolver');

async function resolveToPhone(sock, jid, groupParticipants) {
    if (!jid) return null;
    const raw = jid.split('@')[0].split(':')[0];
    // Plain phone JID
    if (!isLidJid(jid) && /^\d{7,15}$/.test(raw)) return raw;
    // Sync fast path
    const fast = resolvePhoneFromLid(jid, sock);
    if (fast) return fast;
    // Cross-ref current group participants
    if (groupParticipants) {
        for (const p of groupParticipants) {
            const pid  = (p.id  || '').split('@')[0].split(':')[0];
            const pLid = (p.lid || '').split('@')[0].split(':')[0];
            if ((pLid === raw || pid === raw) && pid && /^\d{7,15}$/.test(pid) && !pid.includes('lid') && pid !== raw) {
                cacheLidPhone(raw, pid);
                return pid;
            }
        }
    }
    // Async fallback: fetch group metadata
    const fromGroup = await resolveSenderFromGroup(jid, null, sock).catch(() => null);
    return fromGroup || null;
}

async function tagAllCommand(sock, chatId, senderId, message) {
    const fake = createFakeContact(senderId);
    const botName = getBotName();
    
    try {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
        
        if (!isSenderAdmin && !isBotAdmin && !message?.key?.fromMe && !db.isSudo(senderId)) {
            await sock.sendMessage(chatId, {
                text: `*${botName}*\nAdmin only command!`
            }, { quoted: fake });
            return;
        }

        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants;

        if (!participants || participants.length === 0) {
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\nNo participants found!` 
            }, { quoted: fake });
            return;
        }

        let profilePictureUrl = null;
        try {
            profilePictureUrl = await sock.profilePictureUrl(chatId, 'image');
        } catch {}

        let textContent = `╭─❖ *${botName} TAGALL* ❖─╮\n`;
        textContent += `│ Group   : ${groupMetadata.subject}\n`;
        textContent += `│ Members : ${participants.length}\n`;
        textContent += `╰────────────────────────╯\n\n`;

        const mentions = [];

        for (let i = 0; i < participants.length; i++) {
            const p = participants[i];
            const num = (i + 1).toString().padStart(2, '0');

            // Resolve LID → phone (pass group list for cross-reference)
            const phone = await resolveToPhone(sock, p.id, participants);

            // Use phone JID for mention if available, otherwise fall back to p.id
            const mentionJid = phone ? `${phone}@s.whatsapp.net` : p.id;
            mentions.push(mentionJid);

            // For @mention in text, use the phone part so WhatsApp shows the contact name
            const mentionPart = phone || p.id.split('@')[0].split(':')[0];

            // Display label: prefer saved contact name, then phone with +, never show raw LID
            const adminBadge = (p.admin === 'admin' || p.admin === 'superadmin') ? ' 👑' : '';

            textContent += `${num}. @${mentionPart}${adminBadge}\n`;
        }

        if (profilePictureUrl) {
            await sock.sendMessage(chatId, {
                image: { url: profilePictureUrl },
                caption: textContent,
                mentions
            }, { quoted: fake });
        } else {
            await sock.sendMessage(chatId, {
                text: textContent,
                mentions
            }, { quoted: fake });
        }

    } catch (error) {
        console.error('TagAll error:', error.message, 'Line:', error.stack?.split('\n')[1]);
        await sock.sendMessage(chatId, { 
            text: `*${botName}*\nFailed to tag members.`
        }, { quoted: fake });
    }
}

module.exports = { tagAllCommand };