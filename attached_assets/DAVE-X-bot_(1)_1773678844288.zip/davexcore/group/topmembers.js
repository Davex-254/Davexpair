const {
    incrementMsgCount,
    getGroupMsgCounts,
    resetGroupMsgCounts,
    getGroupTotalMsgCount
} = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function resolveToPhone(sock, jid) {
    if (!jid) return 'unknown';
    const raw = jid.split('@')[0].split(':')[0];
    if (/^\d{7,15}$/.test(raw)) return raw;
    try {
        if (sock?.signalRepository?.lidMapping?.getPNForLID) {
            const formats = [jid, `${raw}:0@lid`, `${raw}@lid`];
            for (const fmt of formats) {
                try {
                    const pn = await sock.signalRepository.lidMapping.getPNForLID(fmt);
                    if (pn) {
                        const num = String(pn).split('@')[0].replace(/[^0-9]/g, '');
                        if (num.length >= 7 && num.length <= 15 && num !== raw) return num;
                    }
                } catch {}
            }
        }
        const groups = await sock.groupFetchAllParticipating();
        for (const gid of Object.keys(groups)) {
            for (const p of (groups[gid].participants || [])) {
                const pid = (p.id || '').split('@')[0].split(':')[0];
                const pLid = (p.lid || '').split('@')[0].split(':')[0];
                if ((pLid === raw || pid === raw) && pid && /^\d{7,15}$/.test(pid) && pid !== raw) return pid;
            }
        }
    } catch {}
    return raw;
}

function incrementMessageCount(groupId, userId) {
    try {
        incrementMsgCount(groupId, userId);
    } catch (error) {
        console.error('Error incrementing message count:', error);
    }
}

async function topMembers(sock, chatId, isGroup, message, count = 5) {
    const fakeContact = createFakeContact(message);
    const botName = getBotName();

    try {
        if (!isGroup) {
            sock.sendMessage(chatId, { text: `*${botName}*\nGroup command only.` }, { quoted: fakeContact });
            return;
        }

        const groupCounts = getGroupMsgCounts(chatId);
        const sortedMembers = Object.entries(groupCounts)
            .sort(([, a], [, b]) => b - a)
            .slice(0, count);

        if (sortedMembers.length === 0) {
            sock.sendMessage(chatId, { text: `*${botName}*\nNo interaction data available.` }, { quoted: fakeContact });
            return;
        }

        let textContent = `╭─❖ *TOP ${count} MEMBERS* ❖─╮\n`;
        const mentions = [];

        for (let index = 0; index < sortedMembers.length; index++) {
            const [userId, messageCount] = sortedMembers[index];
            const rank = (index + 1).toString().padStart(2, '0');
            const username = await resolveToPhone(sock, userId);

            let displayName = username;
            try {
                const groupMetadata = await sock.groupMetadata(chatId);
                const participant = groupMetadata.participants.find(p => p.id === userId);
                if (participant) {
                    displayName = participant.name || participant.notify || username;
                }
            } catch {}

            textContent += `│ ${rank}. @${username} (${displayName})\n`;
            textContent += `│    📊 ${messageCount} messages\n`;
            mentions.push(userId);
        }

        const totalMessages = getGroupTotalMsgCount(chatId);
        textContent += `╰────────────────────────╯\n\n`;
        textContent += `Total: ${totalMessages} messages`;

        await sock.sendMessage(chatId, {
            text: textContent,
            mentions: mentions
        }, { quoted: fakeContact });

    } catch (error) {
        console.error('Error in topMembers command:', error);
        sock.sendMessage(chatId, { text: `*${botName}*\nFailed to load leaderboard.` }, { quoted: fakeContact });
    }
}

async function getUserRank(sock, chatId, isGroup, userId, message) {
    const fakeContact = createFakeContact(message);
    const botName = getBotName();

    try {
        if (!isGroup) {
            sock.sendMessage(chatId, { text: `*${botName}*\nGroup command only.` }, { quoted: fakeContact });
            return;
        }

        const groupCounts = getGroupMsgCounts(chatId);
        const username = await resolveToPhone(sock, userId);

        if (!groupCounts[userId]) {
            sock.sendMessage(chatId, {
                text: `*${botName}*\n@${username} has no interaction history.`,
                mentions: [userId]
            }, { quoted: fakeContact });
            return;
        }

        const sortedMembers = Object.entries(groupCounts).sort(([, a], [, b]) => b - a);
        const userRank = sortedMembers.findIndex(([id]) => id === userId) + 1;
        const userMessageCount = groupCounts[userId];
        const totalMembers = sortedMembers.length;
        const percentile = Math.round(((totalMembers - userRank + 1) / totalMembers) * 100);

        const textContent = `╭─❖ *USER RANK* ❖─╮\n` +
                           `│ User    : @${username}\n` +
                           `│ Rank    : ${userRank}/${totalMembers}\n` +
                           `│ Messages: ${userMessageCount}\n` +
                           `│ Top     : ${percentile}%\n` +
                           `╰─────────────────╯`;

        sock.sendMessage(chatId, {
            text: textContent,
            mentions: [userId]
        }, { quoted: fakeContact });

    } catch (error) {
        console.error('Error in getUserRank command:', error);
        sock.sendMessage(chatId, {
            text: `*${botName}*\nFailed to get user rank.`
        }, { quoted: fakeContact });
    }
}

function resetMessageCounts(groupId) {
    try {
        resetGroupMsgCounts(groupId);
        return true;
    } catch (error) {
        console.error('Error resetting message counts:', error);
        return false;
    }
}

async function getGroupStats(sock, chatId, isGroup, message) {
    const fakeContact = createFakeContact(message);
    const botName = getBotName();

    try {
        if (!isGroup) {
            sock.sendMessage(chatId, { text: `*${botName}*\nGroup command only.` }, { quoted: fakeContact });
            return;
        }

        const groupCounts = getGroupMsgCounts(chatId);
        const totalMessages = getGroupTotalMsgCount(chatId);
        const activeMembers = Object.keys(groupCounts).length;
        const sortedCounts = Object.values(groupCounts).sort((a, b) => b - a);
        const averageMessages = activeMembers > 0 ? Math.round(totalMessages / activeMembers) : 0;
        const medianMessages = sortedCounts.length > 0 ? sortedCounts[Math.floor(sortedCounts.length / 2)] : 0;

        const textContent = `╭─❖ *GROUP STATS* ❖─╮\n` +
                           `│ Active    : ${activeMembers}\n` +
                           `│ Total     : ${totalMessages}\n` +
                           `│ Average   : ${averageMessages}\n` +
                           `│ Median    : ${medianMessages}\n` +
                           `│ Top user  : ${sortedCounts[0] || 0}\n` +
                           `╰────────────────────╯`;

        sock.sendMessage(chatId, { text: textContent }, { quoted: fakeContact });

    } catch (error) {
        console.error('Error in getGroupStats command:', error);
        sock.sendMessage(chatId, {
            text: `*${botName}*\nFailed to load group stats.`
        }, { quoted: fakeContact });
    }
}

module.exports = {
    incrementMessageCount,
    topMembers,
    getUserRank,
    resetMessageCounts,
    getGroupStats,
    createFakeContact
};
