const db = require('../../Database/database');
const isAdminCheck = require('../../davelib/isAdmin');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function ensureGroupAdmin(sock, chatId, senderId, message) {
    if (!chatId.endsWith('@g.us')) return { ok: false, reason: 'group' };
    const { isSenderAdmin, isBotAdmin } = await isAdminCheck(sock, chatId, senderId);
    if (!isBotAdmin) return { ok: false, reason: 'botadmin' };
    if (!isSenderAdmin && !message?.key?.fromMe && !db.isSudo(senderId)) return { ok: false, reason: 'admin' };
    return { ok: true, isBotAdmin, isSenderAdmin };
}

// Lock group settings so only admins can edit group info
async function groupLockCommand(sock, chatId, senderId, message) {
    const fake = createFakeContact(senderId);
    const botName = getBotName();
    const check = await ensureGroupAdmin(sock, chatId, senderId, message);
    if (!check.ok) {
        const msg = check.reason === 'group' ? 'Group command only!'
                  : check.reason === 'botadmin' ? 'Bot needs admin rights!'
                  : 'Admin only command!';
        return sock.sendMessage(chatId, { text: `*${botName}*\n❌ ${msg}` }, { quoted: fake });
    }
    try {
        await sock.groupSettingUpdate(chatId, 'locked');
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n🔒 Group settings *locked* — only admins can edit group info.`
        }, { quoted: fake });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Failed: ${e.message}` }, { quoted: fake });
    }
}

// Unlock group settings so everyone can edit group info
async function groupUnlockCommand(sock, chatId, senderId, message) {
    const fake = createFakeContact(senderId);
    const botName = getBotName();
    const check = await ensureGroupAdmin(sock, chatId, senderId, message);
    if (!check.ok) {
        const msg = check.reason === 'group' ? 'Group command only!'
                  : check.reason === 'botadmin' ? 'Bot needs admin rights!'
                  : 'Admin only command!';
        return sock.sendMessage(chatId, { text: `*${botName}*\n❌ ${msg}` }, { quoted: fake });
    }
    try {
        await sock.groupSettingUpdate(chatId, 'unlocked');
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n🔓 Group settings *unlocked* — all members can edit group info.`
        }, { quoted: fake });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Failed: ${e.message}` }, { quoted: fake });
    }
}

// Announcement mode: only admins can send messages
async function groupCloseCommand(sock, chatId, senderId, message) {
    const fake = createFakeContact(senderId);
    const botName = getBotName();
    const check = await ensureGroupAdmin(sock, chatId, senderId, message);
    if (!check.ok) {
        const msg = check.reason === 'group' ? 'Group command only!'
                  : check.reason === 'botadmin' ? 'Bot needs admin rights!'
                  : 'Admin only command!';
        return sock.sendMessage(chatId, { text: `*${botName}*\n❌ ${msg}` }, { quoted: fake });
    }
    try {
        await sock.groupSettingUpdate(chatId, 'announcement');
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n🔕 Group *closed* — only admins can send messages now.`
        }, { quoted: fake });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Failed: ${e.message}` }, { quoted: fake });
    }
}

// Open mode: all members can send messages
async function groupOpenCommand(sock, chatId, senderId, message) {
    const fake = createFakeContact(senderId);
    const botName = getBotName();
    const check = await ensureGroupAdmin(sock, chatId, senderId, message);
    if (!check.ok) {
        const msg = check.reason === 'group' ? 'Group command only!'
                  : check.reason === 'botadmin' ? 'Bot needs admin rights!'
                  : 'Admin only command!';
        return sock.sendMessage(chatId, { text: `*${botName}*\n❌ ${msg}` }, { quoted: fake });
    }
    try {
        await sock.groupSettingUpdate(chatId, 'not_announcement');
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n🔔 Group *opened* — all members can send messages.`
        }, { quoted: fake });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Failed: ${e.message}` }, { quoted: fake });
    }
}

// Member add mode: who can add members to the group
async function addModeCommand(sock, chatId, senderId, message, args) {
    const fake = createFakeContact(senderId);
    const botName = getBotName();
    const check = await ensureGroupAdmin(sock, chatId, senderId, message);
    if (!check.ok) {
        const msg = check.reason === 'group' ? 'Group command only!'
                  : check.reason === 'botadmin' ? 'Bot needs admin rights!'
                  : 'Admin only command!';
        return sock.sendMessage(chatId, { text: `*${botName}*\n❌ ${msg}` }, { quoted: fake });
    }
    const sub = (args || '').trim().toLowerCase();
    if (sub !== 'admin' && sub !== 'all') {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\n✦ *ADDMODE*\n\nUsage:\n*.addmode admin* — only admins can add members\n*.addmode all* — all members can add others`
        }, { quoted: fake });
    }
    try {
        const mode = sub === 'admin' ? 'admin_add' : 'all_member_add';
        await sock.groupMemberAddMode(chatId, mode);
        const label = sub === 'admin' ? 'only admins' : 'all members';
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n✅ Add mode set — *${label}* can add members.`
        }, { quoted: fake });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Failed: ${e.message}` }, { quoted: fake });
    }
}

// Join approval mode: require admin approval to join via invite link
async function joinApprovalCommand(sock, chatId, senderId, message, args) {
    const fake = createFakeContact(senderId);
    const botName = getBotName();
    const check = await ensureGroupAdmin(sock, chatId, senderId, message);
    if (!check.ok) {
        const msg = check.reason === 'group' ? 'Group command only!'
                  : check.reason === 'botadmin' ? 'Bot needs admin rights!'
                  : 'Admin only command!';
        return sock.sendMessage(chatId, { text: `*${botName}*\n❌ ${msg}` }, { quoted: fake });
    }
    const sub = (args || '').trim().toLowerCase();
    if (sub !== 'on' && sub !== 'off') {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\n✦ *JOINAPPROVAL*\n\nUsage:\n*.joinapproval on* — require admin approval to join\n*.joinapproval off* — anyone can join via link`
        }, { quoted: fake });
    }
    try {
        await sock.groupJoinApprovalMode(chatId, sub);
        const label = sub === 'on' ? 'enabled — admins must approve new members' : 'disabled — anyone can join via link';
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n✅ Join approval *${label}*.`
        }, { quoted: fake });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Failed: ${e.message}` }, { quoted: fake });
    }
}

module.exports = {
    groupLockCommand,
    groupUnlockCommand,
    groupCloseCommand,
    groupOpenCommand,
    addModeCommand,
    joinApprovalCommand
};
