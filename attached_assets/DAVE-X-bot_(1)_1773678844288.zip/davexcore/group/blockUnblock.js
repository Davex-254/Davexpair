const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { resolvePhoneFromLid, isLidJid } = require('../../davelib/lidResolver');

function isPhoneJid(jid) {
    if (!jid || typeof jid !== 'string') return false;
    if (!jid.endsWith('@s.whatsapp.net')) return false;
    const num = jid.split('@')[0].split(':')[0];
    return /^\d{7,15}$/.test(num);
}

function getContextInfo(message) {
    const msg = message.message;
    if (!msg) return null;
    const type = Object.keys(msg)[0];
    return msg[type]?.contextInfo || msg.extendedTextMessage?.contextInfo || null;
}

function resolveRawTarget(message) {
    const msg = message.message;
    if (!msg) return null;
    const contextInfo = getContextInfo(message);
    const quotedParticipant = contextInfo?.participant;
    const mentionedJids = contextInfo?.mentionedJid || [];
    const type = Object.keys(msg)[0];
    const text = msg.conversation || msg.extendedTextMessage?.text ||
                 msg[type]?.caption || '';
    const argNumber = text.split(/\s+/).slice(1).join('').replace(/[^0-9]/g, '');
    if (quotedParticipant) return quotedParticipant;
    if (mentionedJids.length > 0) return mentionedJids[0];
    if (argNumber.length >= 7 && argNumber.length <= 15) return `${argNumber}@s.whatsapp.net`;
    return null;
}

function normalizePhoneJid(jid) {
    if (!jid) return null;
    return jid.replace(/:\d+@/, '@');
}

async function resolveToPhoneJid(rawJid, sock) {
    if (!rawJid) return null;
    if (!isLidJid(rawJid)) return normalizePhoneJid(rawJid);
    try {
        if (sock?.signalRepository?.lidMapping?.getPNForLID) {
            for (const fmt of [rawJid, rawJid.split('@')[0] + '@lid', rawJid.split('@')[0] + ':0@lid']) {
                const pn = await Promise.resolve(sock.signalRepository.lidMapping.getPNForLID(fmt));
                if (pn) return normalizePhoneJid(`${pn}@s.whatsapp.net`);
            }
        }
    } catch {}
    const resolved = resolvePhoneFromLid(rawJid, sock);
    if (resolved) return `${resolved}@s.whatsapp.net`;
    return null;
}

function isOwner(message, senderId) {
    return message.key.fromMe || db.isSudo(senderId);
}

async function blockCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    try {
        if (!isOwner(message, senderId)) {
            return sock.sendMessage(chatId, { text: `✦ *${botName}* | Owner only command.` }, { quoted: fake });
        }
        const rawTarget = resolveRawTarget(message);
        if (!rawTarget) {
            return sock.sendMessage(chatId, {
                text: `✦ *${botName}* | How to block:\n• Reply to a message → .block\n• Mention: .block @user\n• By number: .block 254712345678`
            }, { quoted: fake });
        }
        const userToBlock = await resolveToPhoneJid(rawTarget, sock);
        if (!userToBlock) {
            return sock.sendMessage(chatId, {
                text: `✦ *${botName}* | Could not resolve that user's phone number.\nTry: .block 254712345678`
            }, { quoted: fake });
        }
        const botId = (sock.user?.id || '').replace(/:\d+@/, '@');
        if (userToBlock === botId || userToBlock.split('@')[0] === botId.split('@')[0]) {
            return sock.sendMessage(chatId, { text: `✦ *${botName}* | Cannot block the bot itself!` }, { quoted: fake });
        }
        await sock.updateBlockStatus(userToBlock, 'block');
        const num = userToBlock.split('@')[0];
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}* | ✅ Blocked +${num}`,
            mentions: [userToBlock]
        }, { quoted: fake });
    } catch (error) {
        console.error('[Block]', error.message);
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}* | ❌ Block failed: ${error.message}`
        }, { quoted: fake }).catch(() => {});
    }
}

async function unblockCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    try {
        if (!isOwner(message, senderId)) {
            return sock.sendMessage(chatId, { text: `✦ *${botName}* | Owner only command.` }, { quoted: fake });
        }
        const rawTarget = resolveRawTarget(message);
        if (!rawTarget) {
            return sock.sendMessage(chatId, {
                text: `✦ *${botName}* | How to unblock:\n• Mention: .unblock @user\n• By number: .unblock 254712345678`
            }, { quoted: fake });
        }
        const userToUnblock = await resolveToPhoneJid(rawTarget, sock);
        if (!userToUnblock) {
            return sock.sendMessage(chatId, {
                text: `✦ *${botName}* | Could not resolve that user's phone number.\nTry: .unblock 254712345678`
            }, { quoted: fake });
        }
        await sock.updateBlockStatus(userToUnblock, 'unblock');
        const num = userToUnblock.split('@')[0];
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}* | ✅ Unblocked +${num}`,
            mentions: [userToUnblock]
        }, { quoted: fake });
    } catch (error) {
        console.error('[Unblock]', error.message);
        await sock.sendMessage(chatId, { text: `✦ *${botName}* | ❌ Unblock failed: ${error.message}` }, { quoted: fake }).catch(() => {});
    }
}

async function blocklistCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    try {
        if (!isOwner(message, senderId)) {
            return sock.sendMessage(chatId, { text: `✦ *${botName}* | Owner only command.` }, { quoted: fake });
        }
        const allBlocked = await sock.fetchBlocklist().catch(() => []);
        const realBlocked = allBlocked.filter(isPhoneJid);
        if (!realBlocked.length) {
            return sock.sendMessage(chatId, { text: `✦ *${botName}* | Blocklist is empty.` }, { quoted: fake });
        }
        const total = realBlocked.length;
        const listText = realBlocked
            .slice(0, 30)
            .map((jid, i) => `${i + 1}. +${jid.split('@')[0]}`)
            .join('\n');
        let text = `✦ *${botName}* | Blocklist\n\n📋 Total: *${total}*\n\n${listText}`;
        if (total > 30) text += `\n\n... and ${total - 30} more`;
        await sock.sendMessage(chatId, { text }, { quoted: fake });
    } catch (error) {
        console.error('[Blocklist]', error.message);
        await sock.sendMessage(chatId, { text: `✦ *${botName}* | ❌ Failed to fetch blocklist.` }, { quoted: fake }).catch(() => {});
    }
}

async function unblockallCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    try {
        if (!isOwner(message, senderId)) {
            return sock.sendMessage(chatId, { text: `✦ *${botName}* | Owner only command.` }, { quoted: fake });
        }
        const allBlocked = await sock.fetchBlocklist().catch(() => []);
        const realBlocked = allBlocked.filter(isPhoneJid);
        if (!realBlocked.length) {
            return sock.sendMessage(chatId, { text: `✦ *${botName}* | No real contacts to unblock.` }, { quoted: fake });
        }
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });
        let successCount = 0;
        for (const jid of realBlocked) {
            try {
                await sock.updateBlockStatus(jid, 'unblock');
                successCount++;
                await delay(300);
            } catch {}
        }
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}* | ✅ Unblocked *${successCount}* contact${successCount !== 1 ? 's' : ''}.`
        }, { quoted: fake });
    } catch (error) {
        console.error('[UnblockAll]', error.message);
        await sock.sendMessage(chatId, { text: `✦ *${botName}* | ❌ Failed to unblock all.` }, { quoted: fake }).catch(() => {});
    }
}

module.exports = { blockCommand, unblockCommand, blocklistCommand, unblockallCommand };
