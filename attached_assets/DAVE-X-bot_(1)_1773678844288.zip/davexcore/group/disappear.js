const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

const DURATIONS = {
    'off':  0,
    '0':    0,
    '1d':   86400,
    '24h':  86400,
    '7d':   604800,
    '1w':   604800,
    '90d':  7776000,
    '3m':   7776000,
    '3mo':  7776000,
};

const LABELS = {
    0:       'OFF',
    86400:   '24 Hours',
    604800:  '7 Days',
    7776000: '90 Days',
};

async function disappearCommand(sock, chatId, message, args) {
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const botName = getBotName();
    const isGroup = chatId.endsWith('@g.us');

    if (!args[0]) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n╭─ Disappearing Messages ─╮\n│\n│ Available durations:\n│ • off / 0\n│ • 1d / 24h\n│ • 7d / 1w\n│ • 90d / 3m\n│\n│ Example: .disappear 7d\n╰─────────────────────────╯`
        }, { quoted: fake });
        return;
    }

    const key = args[0].toLowerCase();
    if (!(key in DURATIONS)) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Unknown duration: *${args[0]}*\nOptions: off, 1d, 7d, 90d`
        }, { quoted: fake });
        return;
    }

    const seconds = DURATIONS[key];

    try {
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        if (isGroup) {
            await sock.groupToggleEphemeral(chatId, seconds);
        } else {
            await sock.sendMessage(chatId, {
                disappearingMessagesInChat: seconds
            });
        }

        const label = LABELS[seconds] || 'Custom';
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n✅ Disappearing messages: *${label}*`
        }, { quoted: fake });
    } catch (e) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Failed: ${e.message}`
        }, { quoted: fake });
    }
}

module.exports = disappearCommand;
