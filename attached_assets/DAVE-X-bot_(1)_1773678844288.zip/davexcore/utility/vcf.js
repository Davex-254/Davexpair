const fs = require('fs');
const path = require('path');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { resolvePhoneFromLid, isLidJid } = require('../../davelib/lidResolver');

const DEFAULT_NAME = null;

function resolveParticipantPhone(participant, sock) {
    const raw = (participant.id || '').split('@')[0].split(':')[0];
    if (!isLidJid(participant.id)) return /^\d{7,15}$/.test(raw) ? raw : null;
    const resolved = resolvePhoneFromLid(participant.id, sock);
    if (resolved && /^\d{7,15}$/.test(resolved)) return resolved;
    if (global.lidCache) {
        const fromLid = global.lidCache.get(raw);
        if (fromLid && /^\d{7,15}$/.test(fromLid)) return fromLid;
    }
    const phoneFromLid = (participant.lid || '').split('@')[0].split(':')[0];
    if (/^\d{7,15}$/.test(phoneFromLid)) return phoneFromLid;
    return null;
}

function resolveParticipantName(participant, phone) {
    if (global.pushNameCache) {
        if (phone) {
            const n = global.pushNameCache.get(phone);
            if (n) return n;
        }
        const raw = (participant.id || '').split('@')[0].split(':')[0];
        const n = global.pushNameCache.get(raw);
        if (n) return n;
    }
    if (participant.notify) return participant.notify;
    if (participant.name) return participant.name;
    return phone ? `Contact ${phone}` : 'Unknown';
}

async function vcfCommand(sock, chatId, message) {
    const fkontak = createFakeContact(message);
    const botName = getBotName();

    try {
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { text: `✦ Group command only` }, { quoted: fkontak });
            return;
        }

        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants || [];

        if (participants.length < 2) {
            await sock.sendMessage(chatId, { text: `✦ Group must have at least 2 members` }, { quoted: fkontak });
            return;
        }

        let vcfContent = '';
        let resolved = 0;
        let lidFallbacks = 0;

        for (const participant of participants) {
            const phone = resolveParticipantPhone(participant, sock);
            const displayName = resolveParticipantName(participant, phone);

            if (!phone) {
                lidFallbacks++;
                continue;
            }

            resolved++;
            vcfContent += `BEGIN:VCARD\nVERSION:3.0\nFN:${displayName}\nTEL;TYPE=CELL:+${phone}\nEND:VCARD\n`;
        }

        if (!vcfContent) {
            await sock.sendMessage(chatId, {
                text: `✦ Could not resolve any phone numbers from this group.\nTry sending a command first so the bot can learn member numbers.`
            }, { quoted: fkontak });
            return;
        }

        const sanitizedGroupName = groupMetadata.subject.replace(/[^\w]/g, '_');
        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

        const vcfPath = path.join(tempDir, `${sanitizedGroupName}.vcf`);
        fs.writeFileSync(vcfPath, vcfContent);

        const note = lidFallbacks > 0 ? `\n  ⚠️ Skipped: ${lidFallbacks} (LID — send a msg to unlock)` : '';

        await sock.sendMessage(chatId, {
            document: fs.readFileSync(vcfPath),
            mimetype: 'text/vcard',
            fileName: `${sanitizedGroupName}.vcf`,
            caption: `✦ *VCF EXPORT*\n\n  Group: ${groupMetadata.subject}\n  Contacts: ${resolved}/${participants.length}${note}`
        }, { quoted: fkontak });

        setTimeout(() => { try { if (fs.existsSync(vcfPath)) fs.unlinkSync(vcfPath); } catch {} }, 5000);

    } catch (error) {
        console.error('VCF Error:', error.message);
        await sock.sendMessage(chatId, { text: `✦ Failed to generate contacts` }, { quoted: fkontak });
    }
}

function parseVcfContacts(vcfText) {
    const contacts = [];
    const cards = vcfText.split(/END:VCARD/i).filter(c => c.trim());
    for (const card of cards) {
        const fnMatch = card.match(/FN:(.+)/i);
        const telMatch = card.match(/TEL[^:]*:\+?(\d{7,15})/i);
        if (telMatch) {
            contacts.push({
                displayName: fnMatch ? fnMatch[1].trim() : `Contact ${telMatch[1]}`,
                phone: telMatch[1]
            });
        }
    }
    return contacts;
}

async function vcfFilterCommand(sock, chatId, message, query) {
    const fkontak = createFakeContact(message);

    try {
        const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const quotedDoc = quotedMsg?.documentMessage;
        const isReplyToVcf = quotedDoc && (quotedDoc.mimetype === 'text/vcard' || (quotedDoc.fileName || '').endsWith('.vcf'));

        if (isReplyToVcf) {
            if (!query) {
                await sock.sendMessage(chatId, {
                    text: `✦ *VCF FILTER*\n\nUsage: Reply to the VCF file with *filter vcf <name or number>*`
                }, { quoted: fkontak });
                return;
            }

            const { downloadMediaMessage } = require('@whiskeysockets/baileys');
            const quotedMsgFull = await sock.loadMessage(
                message.message.extendedTextMessage.contextInfo.stanzaId ||
                message.message.extendedTextMessage.contextInfo.quotedMessage,
                chatId
            ).catch(() => null);

            let vcfBuffer;
            try {
                const contextStanzaId = message.message?.extendedTextMessage?.contextInfo?.stanzaId;
                const contextMsg = { message: quotedMsg, key: { remoteJid: chatId, id: contextStanzaId, fromMe: false } };
                vcfBuffer = await downloadMediaMessage(contextMsg, 'buffer', {}, { logger: { warn: () => {}, info: () => {}, error: () => {} } });
            } catch (e) {
                vcfBuffer = null;
            }

            if (!vcfBuffer) {
                await sock.sendMessage(chatId, { text: `✦ Could not download the VCF file. Try forwarding it again.` }, { quoted: fkontak });
                return;
            }

            const vcfText = vcfBuffer.toString('utf-8');
            const allContacts = parseVcfContacts(vcfText);
            const q = query.toLowerCase();
            const matches = allContacts.filter(c =>
                c.displayName.toLowerCase().includes(q) || c.phone.includes(q)
            );

            if (matches.length === 0) {
                await sock.sendMessage(chatId, { text: `✦ No contacts found matching "*${query}*" in that VCF file` }, { quoted: fkontak });
                return;
            }

            let vcfContent = '';
            for (const { phone, displayName } of matches) {
                vcfContent += `BEGIN:VCARD\nVERSION:3.0\nFN:${displayName}\nTEL;TYPE=CELL:+${phone}\nEND:VCARD\n`;
            }

            const tempDir = path.join(__dirname, '../temp');
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
            const vcfPath = path.join(tempDir, `filter_${Date.now()}.vcf`);
            fs.writeFileSync(vcfPath, vcfContent);

            await sock.sendMessage(chatId, {
                document: fs.readFileSync(vcfPath),
                mimetype: 'text/vcard',
                fileName: `filtered_contacts.vcf`,
                caption: `✦ *VCF FILTER RESULTS*\n\n  Query: "${query}"\n  From VCF file: ${matches.length}/${allContacts.length} matched`
            }, { quoted: fkontak });

            setTimeout(() => { try { if (fs.existsSync(vcfPath)) fs.unlinkSync(vcfPath); } catch {} }, 5000);
            return;
        }

        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { text: `✦ Use in a group or reply to a VCF file` }, { quoted: fkontak });
            return;
        }

        if (!query) {
            await sock.sendMessage(chatId, {
                text: `✦ *VCF FILTER*\n\nUsage:\n• *.filter vcf <name or number>* — filter group members\n• Reply to a VCF file with *.filter vcf <name>* — filter from that file`
            }, { quoted: fkontak });
            return;
        }

        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants || [];
        const q = query.toLowerCase();

        const matches = [];
        for (const participant of participants) {
            const phone = resolveParticipantPhone(participant, sock);
            const displayName = resolveParticipantName(participant, phone);
            if (!phone) continue;
            if (displayName.toLowerCase().includes(q) || phone.includes(q)) {
                matches.push({ phone, displayName });
            }
        }

        if (matches.length === 0) {
            await sock.sendMessage(chatId, {
                text: `✦ No contacts found matching "*${query}*"`
            }, { quoted: fkontak });
            return;
        }

        let vcfContent = '';
        for (const { phone, displayName } of matches) {
            vcfContent += `BEGIN:VCARD\nVERSION:3.0\nFN:${displayName}\nTEL;TYPE=CELL:+${phone}\nEND:VCARD\n`;
        }

        const tempDir = path.join(__dirname, '../temp');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

        const vcfPath = path.join(tempDir, `filter_${Date.now()}.vcf`);
        fs.writeFileSync(vcfPath, vcfContent);

        await sock.sendMessage(chatId, {
            document: fs.readFileSync(vcfPath),
            mimetype: 'text/vcard',
            fileName: `filtered_contacts.vcf`,
            caption: `✦ *VCF FILTER RESULTS*\n\n  Query: "${query}"\n  Matches: ${matches.length}`
        }, { quoted: fkontak });

        setTimeout(() => { try { if (fs.existsSync(vcfPath)) fs.unlinkSync(vcfPath); } catch {} }, 5000);

    } catch (error) {
        console.error('VCF Filter Error:', error.message);
        await sock.sendMessage(chatId, { text: `✦ Failed to filter contacts` }, { quoted: fkontak });
    }
}

module.exports = vcfCommand;
module.exports.vcfFilterCommand = vcfFilterCommand;
