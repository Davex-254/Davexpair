const isAdmin = require('../../davelib/isAdmin');
const store = require('../../davelib/lightweight_store');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function deleteCommand(sock, chatId, message, senderId) {
    const fake = createFakeContact(message);
    const botName = getBotName();

    try {
        const isGroup = chatId.endsWith('@g.us');

        if (isGroup) {
            const adminStatus = await isAdmin(sock, chatId, senderId);
            if (!adminStatus.isBotAdmin) {
                await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
                return;
            }
            if (!adminStatus.isSenderAdmin && !message.key.fromMe) {
                await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
                return;
            }
        } else {
            if (senderId !== chatId && !message.key.fromMe) {
                await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
                return;
            }
        }

        const ctxInfo = message.message?.extendedTextMessage?.contextInfo || {};
        const repliedParticipant = ctxInfo.participant || null;
        const repliedMsgId = ctxInfo.stanzaId || null;

        // If replying to a message, delete that specific message directly (no store needed)
        if (repliedMsgId && repliedParticipant) {
            try {
                await sock.sendMessage(chatId, {
                    delete: {
                        remoteJid: chatId,
                        fromMe: false,
                        id: repliedMsgId,
                        participant: repliedParticipant
                    }
                });
            } catch {}
            // Also delete the command message itself silently
            try {
                if (message.key?.id) {
                    await sock.sendMessage(chatId, {
                        delete: {
                            remoteJid: chatId,
                            fromMe: message.key.fromMe || false,
                            id: message.key.id,
                            participant: senderId
                        }
                    });
                }
            } catch {}
            return; // Silent — no success message
        }

        // No reply: try to delete recent messages from mentioned user via store
        const mentioned = Array.isArray(ctxInfo.mentionedJid) && ctxInfo.mentionedJid.length > 0
            ? ctxInfo.mentionedJid[0]
            : null;
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
        const parts = text.trim().split(/\s+/);
        let countArg = 5;
        if (parts.length > 1) {
            const maybeNum = parseInt(parts[1], 10);
            if (!isNaN(maybeNum) && maybeNum > 0) countArg = Math.min(maybeNum, 50);
        }

        const targetUser = mentioned || (isGroup ? null : chatId);
        if (!targetUser) {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
            return;
        }

        const chatMessages = store.messages[chatId] || [];
        const userMessages = chatMessages.filter(m => {
            const participant = m.key.participant || m.key.remoteJid;
            return participant === targetUser && !m.message?.protocolMessage;
        }).sort((a, b) => (b.messageTimestamp || 0) - (a.messageTimestamp || 0))
          .slice(0, countArg);

        if (userMessages.length === 0) {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
            return;
        }

        for (const m of userMessages) {
            try {
                await sock.sendMessage(chatId, {
                    delete: {
                        remoteJid: chatId,
                        fromMe: m.key.fromMe || false,
                        id: m.key.id,
                        participant: m.key.participant || targetUser
                    }
                });
                await new Promise(r => setTimeout(r, 200));
            } catch {}
        }
        // Delete command message too
        try {
            if (message.key?.id) {
                await sock.sendMessage(chatId, {
                    delete: { remoteJid: chatId, fromMe: message.key.fromMe || false, id: message.key.id, participant: senderId }
                });
            }
        } catch {}
        // Silent — no success message

    } catch (err) {
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } }).catch(() => {});
    }
}

module.exports = deleteCommand;
