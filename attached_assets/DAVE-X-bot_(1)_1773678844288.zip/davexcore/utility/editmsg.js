const { getBotName, createFakeContact } = require('../../davelib/fakeContact');

async function ceditCommand(sock, chatId, message, args) {
    const botName = getBotName();
    const fake = createFakeContact(message);

    const newText = args.join(' ').trim();
    if (!newText) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nUsage: .cedit <new text>\nQuote the bot message you want to edit.`
        }, { quoted: fake });
    }

    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedKey = message.message?.extendedTextMessage?.contextInfo;

    if (!quotedKey || !quotedKey.stanzaId) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nQuote the bot message you want to edit first.`
        }, { quoted: fake });
    }

    const editKey = {
        remoteJid: chatId,
        id: quotedKey.stanzaId,
        fromMe: true,
        participant: quotedKey.participant
    };

    try {
        await sock.sendMessage(chatId, {
            text: newText,
            edit: editKey
        });
    } catch (err) {
        console.error('[CEDIT] Error:', err.message);
        await sock.sendMessage(chatId, {
            text: `*${botName}*\nFailed to edit message. Can only edit the bot's own messages.`
        }, { quoted: fake });
    }
}

module.exports = ceditCommand;
