const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

const HELP_TEXT = (botName, prefix) =>
    `✦ *${botName}* | Share Location\n\n` +
    `Sends a GPS location pin — like WhatsApp's "Share Location".\n\n` +
    `*Usage:*\n` +
    `› ${prefix}sharelocation <lat>, <lon>\n` +
    `› ${prefix}sharelocation <lat> <lon>\n\n` +
    `*Examples:*\n` +
    `› ${prefix}sharelocation -1.2921, 36.8219\n` +
    `› ${prefix}sharelocation 0.3136 32.5811\n\n` +
    `*Or* quote any WhatsApp location message to re-share it.\n\n` +
    `_Tip: Get coordinates from Google Maps → long-press a spot → copy the numbers shown._`;

function parseCoordinates(input) {
    if (!input || !input.trim()) return null;

    // Try "lat, lon" or "lat lon" or "lat,lon"
    const cleaned = input.trim().replace(/[°]/g, '');
    const match = cleaned.match(/^(-?\d{1,3}(?:\.\d+)?)[,\s]+(-?\d{1,3}(?:\.\d+)?)$/);
    if (!match) return null;

    const lat = parseFloat(match[1]);
    const lon = parseFloat(match[2]);

    if (isNaN(lat) || isNaN(lon)) return null;
    if (lat < -90 || lat > 90) return null;
    if (lon < -180 || lon > 180) return null;

    return { lat, lon };
}

async function shareLocationCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();

    // Determine prefix from the message text
    const rawText = message.message?.conversation ||
                    message.message?.extendedTextMessage?.text || '';
    const prefix = rawText[0] || '.';

    // ── Case 1: User quoted a location message → re-share it ──────────────
    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (quoted?.locationMessage && (!args || !args.trim())) {
        const loc = quoted.locationMessage;
        try {
            await sock.sendMessage(chatId, {
                react: { text: '📍', key: message.key }
            });
            await sock.sendMessage(chatId, {
                location: {
                    degreesLatitude:  loc.degreesLatitude,
                    degreesLongitude: loc.degreesLongitude,
                    name:    loc.name    || '',
                    address: loc.address || ''
                }
            }, { quoted: fake });
        } catch {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
            await sock.sendMessage(chatId, {
                text: `✦ *${botName}*\nFailed to re-share the location.`
            }, { quoted: fake });
        }
        return;
    }

    // ── Case 2: Coordinates provided ──────────────────────────────────────
    if (args && args.trim()) {
        const coords = parseCoordinates(args.trim());

        if (!coords) {
            return sock.sendMessage(chatId, {
                text: `✦ *${botName}*\nInvalid coordinates.\n\n` +
                      `Format: \`${prefix}sharelocation <lat>, <lon>\`\n` +
                      `Example: \`${prefix}sharelocation -1.2921, 36.8219\`\n\n` +
                      `_Tip: Get coordinates from Google Maps → long-press a location._`
            }, { quoted: fake });
        }

        try {
            await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

            await sock.sendMessage(chatId, {
                location: {
                    degreesLatitude:  coords.lat,
                    degreesLongitude: coords.lon,
                    name: `${coords.lat.toFixed(4)}, ${coords.lon.toFixed(4)}`,
                    address: `GPS: ${coords.lat}, ${coords.lon}`
                }
            }, { quoted: fake });

            await sock.sendMessage(chatId, { react: { text: '📍', key: message.key } });

        } catch {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
            await sock.sendMessage(chatId, {
                text: `✦ *${botName}*\nFailed to send location pin.`
            }, { quoted: fake });
        }
        return;
    }

    // ── Case 3: No args, no quoted location → show help ───────────────────
    await sock.sendMessage(chatId, {
        text: HELP_TEXT(botName, prefix)
    }, { quoted: fake });
}

module.exports = shareLocationCommand;
