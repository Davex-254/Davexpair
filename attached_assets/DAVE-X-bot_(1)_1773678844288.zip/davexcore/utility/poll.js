const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function pollCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const isGroup = chatId.endsWith('@g.us');

    if (!isGroup) {
        return sock.sendMessage(chatId, {
            text: `✦ *${botName}*\nPolls can only be created in groups.`
        }, { quoted: fake });
    }

    if (!args || !args.trim()) {
        return sock.sendMessage(chatId, {
            text: `✦ *${botName}* | Poll Creator\n\n` +
                  `Usage:\n_.poll Question; Option1; Option2; Option3_\n\n` +
                  `Example:\n_.poll Favourite colour?; Red; Blue; Green; Yellow_\n\n` +
                  `• Minimum 2 options, maximum 12\n` +
                  `• Separate question and options with *;*\n` +
                  `• Add *multi* at end for multi-select:\n` +
                  `_.poll Question?; A; B; C; multi_`
        }, { quoted: fake });
    }

    let parts = args.split(';').map(p => p.trim()).filter(p => p.length > 0);

    if (parts.length < 3) {
        return sock.sendMessage(chatId, {
            text: `✦ *${botName}*\nNeed at least a question and 2 options.\n\nFormat: _.poll Question; Option1; Option2_`
        }, { quoted: fake });
    }

    // Check if last part is "multi" for multi-select
    let multiSelect = false;
    if (parts[parts.length - 1].toLowerCase() === 'multi') {
        multiSelect = true;
        parts = parts.slice(0, -1);
    }

    const question = parts[0];
    const options = parts.slice(1);

    if (options.length < 2) {
        return sock.sendMessage(chatId, {
            text: `✦ *${botName}*\nNeed at least 2 options.`
        }, { quoted: fake });
    }
    if (options.length > 12) {
        return sock.sendMessage(chatId, {
            text: `✦ *${botName}*\nMaximum 12 options allowed (you have ${options.length}).`
        }, { quoted: fake });
    }
    if (question.length > 255) {
        return sock.sendMessage(chatId, {
            text: `✦ *${botName}*\nQuestion too long (max 255 chars).`
        }, { quoted: fake });
    }

    // Validate option lengths
    const longOption = options.find(o => o.length > 100);
    if (longOption) {
        return sock.sendMessage(chatId, {
            text: `✦ *${botName}*\nOption too long: "${longOption.slice(0, 30)}..." (max 100 chars)`
        }, { quoted: fake });
    }

    try {
        await sock.sendMessage(chatId, {
            poll: {
                name: question,
                values: options,
                // 0 = multi-select, 1 = single select
                selectableCount: multiSelect ? 0 : 1
            }
        });

        await sock.sendMessage(chatId, { react: { text: '📊', key: message.key } });

    } catch (err) {
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}*\nFailed to create poll. Make sure the bot has permission to send polls in this group.`
        }, { quoted: fake });
    }
}

module.exports = pollCommand;
