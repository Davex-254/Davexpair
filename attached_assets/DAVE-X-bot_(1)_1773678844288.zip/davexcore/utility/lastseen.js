const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function lastseenCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    
    try {
        await sock.sendMessage(chatId, {
            react: { text: '⏳', key: message.key }
        });

        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        const raw = text?.split(' ').slice(1).join(' ').trim().toLowerCase() || '';
        const option = raw.replace(/-/g, '_');

        const validOptions = {
            all:               'Everyone can see your last seen',
            contacts:          'Only contacts can see your last seen',
            contact_blacklist: 'Everyone except blacklisted contacts',
            none:              'No one can see your last seen'
        };

        if (!option) {
            return sock.sendMessage(chatId, { 
                text: `✦ *${botName}* Last Seen\n\nUse: .lastseen <option>\n\nOptions:\n• all\n• contacts\n• contact_blacklist\n• none\n\nExample: .lastseen contacts`
            }, { quoted: fake });
        }

        if (!validOptions[option]) {
            return sock.sendMessage(chatId, { 
                text: `✦ *${botName}*\nInvalid option\n\nUse: all, contacts, contact_blacklist, none`
            }, { quoted: fake });
        }

        await sock.updateLastSeenPrivacy(option);

        await sock.sendMessage(chatId, {
            react: { text: '✅', key: message.key }
        });

        return sock.sendMessage(chatId, {
            text: `✦ *${botName}* - am know invisible 🔥\n\nLast seen set to: *${option}*\n_${validOptions[option]}_`
        }, { quoted: fake });

    } catch (error) {
        console.error('Lastseen command error:', error);

        let errorMessage = '✦ Failed to update';
        if (error.message?.includes('privacy')) errorMessage = '✦ Privacy update failed';
        else if (error.message?.includes('timeout') || error.code === 'ECONNABORTED') errorMessage = '✦ Request timeout';
        else if (error.code === 'ENOTFOUND') errorMessage = '✦ Network error';

        await sock.sendMessage(chatId, { text: errorMessage }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
    }
}

module.exports = lastseenCommand;
