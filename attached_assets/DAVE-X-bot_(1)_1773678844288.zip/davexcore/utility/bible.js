const fetch = require('node-fetch');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function bibleCommand(sock, chatId, message, text, prefix) {
    try {
        const fake = createFakeContact(message);
        const BASE_URL = "https://bible-api.com";

        if (!text || text.trim() === '') {
            await sock.sendMessage(chatId, {
                text: `✦ *BIBLE*
  ╭─────────────────
  │
  │ Usage:
  │ ${prefix}bible <chapter:verse>
  │
  │ Examples:
  │ ${prefix}bible John 3:16
  │ ${prefix}bible Genesis 1:1
  │ ${prefix}bible Psalm 23
  │
  │ Use ${prefix}biblelist for all books
  │
  ╰─────────────────`
            }, { quoted: fake });
            return;
        }

        const chapterInput = encodeURIComponent(text.trim());
        const chapterRes = await fetch(`${BASE_URL}/${chapterInput}`);

        if (!chapterRes.ok) {
            await sock.sendMessage(chatId, {
                text: `✦ *ERROR*
  ╭─────────────────
  │
  │ Invalid format!
  │
  │ Use: Book Chapter:Verse
  │ Example: ${prefix}bible John 3:16
  │
  ╰─────────────────`
            }, { quoted: fake });
            return;
        }

        const chapterData = await chapterRes.json();
        const bibleText = `✦ *BIBLE*
  ╭─────────────────
  │
  │ Reference: ${chapterData.reference}
  │ Translation: ${chapterData.translation_name}
  │ Verses: ${chapterData.verses.length}
  │
  │ ${chapterData.text}
  │
  ╰─────────────────`;

        await sock.sendMessage(chatId, { text: bibleText }, { quoted: fake });

    } catch (error) {
        console.error('Bible command error:', error);
        const fake = createFakeContact(message);
        await sock.sendMessage(chatId, {
            text: `✦ *ERROR*
  ╭─────────────────
  │
  │ ${error.message}
  │
  ╰─────────────────`
        }, { quoted: fake });
    }
}

async function bibleListCommand(sock, chatId, message) {
    try {
        const fake = createFakeContact(message);
        
        const bibleList = `✦ *OLD TESTAMENT*
  ╭────────────────────────────────
  │ Genesis • Exodus • Leviticus • Numbers • Deuteronomy
  │ Joshua • Judges • Ruth • 1 Samuel • 2 Samuel
  │ 1 Kings • 2 Kings • 1 Chronicles • 2 Chronicles
  │ Ezra • Nehemiah • Esther • Job • Psalms
  │ Proverbs • Ecclesiastes • Song of Solomon
  │ Isaiah • Jeremiah • Lamentations • Ezekiel
  │ Daniel • Hosea • Joel • Amos • Obadiah
  │ Jonah • Micah • Nahum • Habakkuk
  │ Zephaniah • Haggai • Zechariah • Malachi
  ╰────────────────────────────────

✦ *NEW TESTAMENT*
  ╭────────────────────────────────
  │ Matthew • Mark • Luke • John • Acts
  │ Romans • 1 Corinthians • 2 Corinthians
  │ Galatians • Ephesians • Philippians
  │ Colossians • 1 Thessalonians • 2 Thessalonians
  │ 1 Timothy • 2 Timothy • Titus • Philemon
  │ Hebrews • James • 1 Peter • 2 Peter
  │ 1 John • 2 John • 3 John • Jude • Revelation
  ╰────────────────────────────────

✦ *USAGE*
  ╭─────────────────
  │ .bible John 3:16
  │ .bible Genesis 1:1
  ╰─────────────────`;

        await sock.sendMessage(chatId, { text: bibleList }, { quoted: fake });

    } catch (error) {
        console.error('Bible list command error:', error);
        const fake = createFakeContact(message);
        await sock.sendMessage(chatId, {
            text: `✦ *ERROR*
  ╭─────────────────
  │
  │ Failed to fetch Bible list
  │
  ╰─────────────────`
        }, { quoted: fake });
    }
}

async function quranCommand(sock, chatId, message, text) {
    try {
        const fake = createFakeContact(message);
        
        if (!text || isNaN(parseInt(text.trim()))) {
            await sock.sendMessage(chatId, {
                text: `✦ *QURAN*
  ╭─────────────────
  │
  │ Usage:
  │ .quran <surah>
  │
  │ Example:
  │ .quran 1
  │
  │ Surahs available:
  │ 1 - 114
  │
  ╰─────────────────`
            }, { quoted: fake });
            return;
        }

        const surahNumber = parseInt(text.trim());
        
        if (surahNumber < 1 || surahNumber > 114) {
            await sock.sendMessage(chatId, {
                text: `✦ *ERROR*
  ╭─────────────────
  │
  │ Invalid number!
  │ Use 1 - 114
  │
  ╰─────────────────`
            }, { quoted: fake });
            return;
        }

        const url = `https://apis.davidcyriltech.my.id/quran?surah=${surahNumber}`;
        const res = await fetch(url);
        const data = await res.json();

        if (!data.success) {
            await sock.sendMessage(chatId, {
                text: `✦ *ERROR*
  ╭─────────────────
  │
  │ Could not fetch Surah
  │
  ╰─────────────────`
            }, { quoted: fake });
            return;
        }

        const { number, name, type, ayahCount, tafsir, recitation } = data.surah;

        let replyText = `✦ *SURAH ${name.english}*
  ╭─────────────────
  │
  │ Arabic: ${name.arabic}
  │ Number: ${number}
  │ Type: ${type}
  │ Ayahs: ${ayahCount}
  │
  │ Tafsir:
  │ ${tafsir.id}
  │
  ╰─────────────────`;

        // Send text first
        await sock.sendMessage(chatId, { text: replyText }, { quoted: fake });

        // Then send audio if available
        if (recitation) {
            try {
                const audioRes = await fetch(recitation);
                const audioBuffer = await audioRes.buffer();
                
                await sock.sendMessage(chatId, {
                    audio: audioBuffer,
                    mimetype: "audio/mpeg",
                    ptt: false
                }, { quoted: fake });
            } catch (audioError) {
                console.error('Audio download error:', audioError);
                await sock.sendMessage(chatId, {
                    text: `✦ *AUDIO*
  ╭─────────────────
  │
  │ Recitation unavailable
  │
  ╰─────────────────`
                }, { quoted: fake });
            }
        }

    } catch (error) {
        console.error('Quran command error:', error);
        const fake = createFakeContact(message);
        await sock.sendMessage(chatId, {
            text: `✦ *ERROR*
  ╭─────────────────
  │
  │ Failed to fetch Quran data
  │
  ╰─────────────────`
        }, { quoted: fake });
    }
}

module.exports = {
    bibleCommand,
    bibleListCommand,
    quranCommand
};