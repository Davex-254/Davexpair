const axios = require("axios");
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

// Football Data API configuration
const apiKey = '7b6507c792f74a2b9db41cfc8fd8cf05';
const apiUrl = 'https://api.football-data.org/v4/competitions';

// Helper function to fetch data from football-data.org
const fetchFootballData = async (endpoint) => {
    try {
        const response = await axios.get(`${apiUrl}/${endpoint}`, {
            headers: {
                'X-Auth-Token': apiKey,
            },
            timeout: 10000
        });
        return response.data;
    } catch (error) {
        console.error('Football API error:', error);
        return null;
    }
};

// Format date helper
const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
};

// 1. EPL Standings
async function eplStandingsCommand(sock, chatId, message) {
    try {
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        const data = await fetchFootballData('PL/standings');
        if (!data || !data.standings) {
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\n❌ Error fetching EPL standings.` 
            }, { quoted: fake });
            return;
        }

        const standings = data.standings[0].table;
        let standingsMessage = `╭─❖ *PREMIER LEAGUE* ❖─╮\n\n`;
        
        standings.forEach((team, index) => {
            const position = index + 1;
            const emoji = position <= 4 ? '🏆' : position <= 6 ? '⚽' : position >= 18 ? '⬇️' : '🔵';
            standingsMessage += `${emoji} ${position}. ${team.team.name}\n`;
            standingsMessage += `   📊 ${team.playedGames}G | ${team.won}W | ${team.draw}D | ${team.lost}L\n`;
            standingsMessage += `   ⚽ ${team.goalsFor}:${team.goalsAgainst} (${team.goalDifference > 0 ? '+' : ''}${team.goalDifference})\n`;
            standingsMessage += `   📈 ${team.points} pts\n\n`;
        });
        
        standingsMessage += `╰──────────────────────╯`;

        await sock.sendMessage(chatId, { text: standingsMessage }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('EPL standings error:', error);
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { 
            text: `*${botName}*\n❌ Error fetching EPL standings.` 
        }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
    }
}

// 2. EPL Matchday (Fixtures)
async function eplFixturesCommand(sock, chatId, message) {
    try {
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        const data = await fetchFootballData('PL/matches?status=SCHEDULED');
        if (!data || !data.matches) {
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\n❌ Error fetching EPL fixtures.` 
            }, { quoted: fake });
            return;
        }

        const matches = data.matches.slice(0, 10);
        let fixturesMessage = `╭─❖ *UPCOMING EPL FIXTURES* ❖─╮\n\n`;
        
        if (matches.length === 0) {
            fixturesMessage += "No upcoming matches scheduled.\n";
        } else {
            matches.forEach((match, index) => {
                const matchDate = formatDate(match.utcDate);
                fixturesMessage += `${index + 1}. ${match.homeTeam.name} 🆚 ${match.awayTeam.name}\n`;
                fixturesMessage += `   📅 ${matchDate}\n`;
                fixturesMessage += `   🏟️ ${match.venue || 'TBA'}\n\n`;
            });
        }
        
        fixturesMessage += `╰────────────────────────────╯`;

        await sock.sendMessage(chatId, { text: fixturesMessage }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('EPL fixtures error:', error);
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { 
            text: `*${botName}*\n❌ Error fetching EPL fixtures.` 
        }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
    }
}

// 3. EPL Top Scorers
async function eplTopScorersCommand(sock, chatId, message) {
    try {
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        const data = await fetchFootballData('PL/scorers');
        if (!data || !data.scorers) {
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\n❌ Error fetching EPL top scorers.` 
            }, { quoted: fake });
            return;
        }

        const topScorers = data.scorers.slice(0, 10);
        let scorersMessage = `╭─❖ *EPL TOP SCORERS* ❖─╮\n\n`;
        
        topScorers.forEach((scorer, index) => {
            const position = index + 1;
            const emoji = position === 1 ? '🥇' : position === 2 ? '🥈' : position === 3 ? '🥉' : '⚽';
            scorersMessage += `${emoji} ${position}. ${scorer.player.name}\n`;
            scorersMessage += `   👟 ${scorer.goals || scorer.numberOfGoals || 0} goals\n`;
            scorersMessage += `   👕 ${scorer.team?.name || 'N/A'}\n`;
            if (scorer.assists) scorersMessage += `   🎯 ${scorer.assists} assists\n`;
            scorersMessage += '\n';
        });
        
        scorersMessage += `╰───────────────────────╯`;

        await sock.sendMessage(chatId, { text: scorersMessage }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('EPL top scorers error:', error);
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { 
            text: `*${botName}*\n❌ Error fetching EPL top scorers.` 
        }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
    }
}

// 4. Bundesliga Standings
async function bundesligaStandingsCommand(sock, chatId, message) {
    try {
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        const data = await fetchFootballData('BL1/standings');
        if (!data || !data.standings) {
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\n❌ Error fetching Bundesliga standings.` 
            }, { quoted: fake });
            return;
        }

        const standings = data.standings[0].table;
        let standingsMessage = `╭─❖ *BUNDESLIGA* ❖─╮\n\n`;
        
        standings.forEach((team, index) => {
            const position = index + 1;
            const emoji = position <= 4 ? '🏆' : position >= 16 ? '⬇️' : '🔵';
            standingsMessage += `${emoji} ${position}. ${team.team.name}\n`;
            standingsMessage += `   📊 ${team.playedGames}G | ${team.won}W | ${team.draw}D | ${team.lost}L\n`;
            standingsMessage += `   ⚽ ${team.goalsFor}:${team.goalsAgainst} (${team.goalDifference > 0 ? '+' : ''}${team.goalDifference})\n`;
            standingsMessage += `   📈 ${team.points} pts\n\n`;
        });
        
        standingsMessage += `╰───────────────────╯`;

        await sock.sendMessage(chatId, { text: standingsMessage }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('Bundesliga standings error:', error);
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { 
            text: `*${botName}*\n❌ Error fetching Bundesliga standings.` 
        }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
    }
}

// 5. LaLiga Standings
async function laligaStandingsCommand(sock, chatId, message) {
    try {
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        const data = await fetchFootballData('PD/standings');
        if (!data || !data.standings) {
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\n❌ Error fetching LaLiga standings.` 
            }, { quoted: fake });
            return;
        }

        const standings = data.standings[0].table;
        let standingsMessage = `╭─❖ *LALIGA* ❖─╮\n\n`;
        
        standings.forEach((team, index) => {
            const position = index + 1;
            const emoji = position <= 4 ? '🏆' : position >= 18 ? '⬇️' : '🔵';
            standingsMessage += `${emoji} ${position}. ${team.team.name}\n`;
            standingsMessage += `   📊 ${team.playedGames}G | ${team.won}W | ${team.draw}D | ${team.lost}L\n`;
            standingsMessage += `   ⚽ ${team.goalsFor}:${team.goalsAgainst} (${team.goalDifference > 0 ? '+' : ''}${team.goalDifference})\n`;
            standingsMessage += `   📈 ${team.points} pts\n\n`;
        });
        
        standingsMessage += `╰────────────────╯`;

        await sock.sendMessage(chatId, { text: standingsMessage }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('LaLiga standings error:', error);
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { 
            text: `*${botName}*\n❌ Error fetching LaLiga standings.` 
        }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
    }
}

// 6. Serie A Standings
async function serieAStandingsCommand(sock, chatId, message) {
    try {
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        const data = await fetchFootballData('SA/standings');
        if (!data || !data.standings) {
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\n❌ Error fetching Serie A standings.` 
            }, { quoted: fake });
            return;
        }

        const standings = data.standings[0].table;
        let standingsMessage = `╭─❖ *SERIE A* ❖─╮\n\n`;
        
        standings.forEach((team, index) => {
            const position = index + 1;
            const emoji = position <= 4 ? '🏆' : position >= 18 ? '⬇️' : '🔵';
            standingsMessage += `${emoji} ${position}. ${team.team.name}\n`;
            standingsMessage += `   📊 ${team.playedGames}G | ${team.won}W | ${team.draw}D | ${team.lost}L\n`;
            standingsMessage += `   ⚽ ${team.goalsFor}:${team.goalsAgainst} (${team.goalDifference > 0 ? '+' : ''}${team.goalDifference})\n`;
            standingsMessage += `   📈 ${team.points} pts\n\n`;
        });
        
        standingsMessage += `╰────────────────╯`;

        await sock.sendMessage(chatId, { text: standingsMessage }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('Serie A standings error:', error);
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { 
            text: `*${botName}*\n❌ Error fetching Serie A standings.` 
        }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
    }
}

// 7. Ligue 1 Standings
async function ligue1StandingsCommand(sock, chatId, message) {
    try {
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        const data = await fetchFootballData('FL1/standings');
        if (!data || !data.standings) {
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\n❌ Error fetching Ligue 1 standings.` 
            }, { quoted: fake });
            return;
        }

        const standings = data.standings[0].table;
        let standingsMessage = `╭─❖ *LIGUE 1* ❖─╮\n\n`;
        
        standings.forEach((team, index) => {
            const position = index + 1;
            const emoji = position <= 3 ? '🏆' : position >= 18 ? '⬇️' : '🔵';
            standingsMessage += `${emoji} ${position}. ${team.team.name}\n`;
            standingsMessage += `   📊 ${team.playedGames}G | ${team.won}W | ${team.draw}D | ${team.lost}L\n`;
            standingsMessage += `   ⚽ ${team.goalsFor}:${team.goalsAgainst} (${team.goalDifference > 0 ? '+' : ''}${team.goalDifference})\n`;
            standingsMessage += `   📈 ${team.points} pts\n\n`;
        });
        
        standingsMessage += `╰────────────────╯`;

        await sock.sendMessage(chatId, { text: standingsMessage }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('Ligue 1 standings error:', error);
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { 
            text: `*${botName}*\n❌ Error fetching Ligue 1 standings.` 
        }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
    }
}

// 8. All Leagues Today's Matches
async function matchesCommand(sock, chatId, message) {
    try {
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        const today = new Date().toISOString().split('T')[0];
        
        const [eplData, laligaData, bundesligaData, serieAData, ligue1Data] = await Promise.all([
            fetchFootballData(`PL/matches?dateFrom=${today}&dateTo=${today}`),
            fetchFootballData(`PD/matches?dateFrom=${today}&dateTo=${today}`),
            fetchFootballData(`BL1/matches?dateFrom=${today}&dateTo=${today}`),
            fetchFootballData(`SA/matches?dateFrom=${today}&dateTo=${today}`),
            fetchFootballData(`FL1/matches?dateFrom=${today}&dateTo=${today}`)
        ]);

        let matchesMessage = `╭─❖ *TODAY'S FIXTURES* ❖─╮\n\n`;
        
        const addLeagueMatches = (data, leagueName, flag) => {
            if (data && data.matches && data.matches.length > 0) {
                matchesMessage += `${flag} *${leagueName}:*\n`;
                data.matches.forEach(match => {
                    const matchTime = formatDate(match.utcDate);
                    matchesMessage += `   • ${match.homeTeam.name} 🆚 ${match.awayTeam.name}\n`;
                    matchesMessage += `     🕐 ${matchTime}\n`;
                    if (match.status === 'IN_PLAY') matchesMessage += `     ⚽ LIVE\n`;
                });
                matchesMessage += '\n';
            }
        };

        addLeagueMatches(eplData, 'Premier League', '🇬🇧');
        addLeagueMatches(laligaData, 'LaLiga', '🇪🇸');
        addLeagueMatches(bundesligaData, 'Bundesliga', '🇩🇪');
        addLeagueMatches(serieAData, 'Serie A', '🇮🇹');
        addLeagueMatches(ligue1Data, 'Ligue 1', '🇫🇷');
        
        matchesMessage += `╰───────────────────────╯`;

        await sock.sendMessage(chatId, { text: matchesMessage }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('Matches command error:', error);
        const fake = createFakeContact(message);
        const botName = getBotName();
        await sock.sendMessage(chatId, { 
            text: `*${botName}*\n❌ Error fetching today's matches.` 
        }, { quoted: fake });
        await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
    }
}

module.exports = {
    eplStandingsCommand,
    eplFixturesCommand,
    eplTopScorersCommand,
    bundesligaStandingsCommand,
    laligaStandingsCommand,
    serieAStandingsCommand,
    ligue1StandingsCommand,
    matchesCommand
};