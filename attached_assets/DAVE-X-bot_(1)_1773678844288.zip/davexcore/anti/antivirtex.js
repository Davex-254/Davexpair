const { getGroupConfig, setGroupConfig, parseToggleCommand } = require('../../Database/settingsStore');
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

// Unicode crash/vortex patterns that can cause WhatsApp to lag, freeze, or crash
const CRASH_PATTERNS = [
    // RTL override characters — used in crash attacks
    /\u202E/,
    // Large clusters of zero-width characters (5+ consecutive)
    /[\u200B\u200C\u200D\uFEFF]{5,}/,
    // Null characters
    /\u0000/,
    // Extremely long repeated Unicode sequences (likely a bomb/flood)
    /(.)\1{500,}/,
    // Specific Zalgo-style character overload (combining diacritics)
    /(?:[\u0300-\u036F\u1DC0-\u1DFF\u20D0-\u20FF]){15,}/,
    // Invisible characters mixed with RTL marks
    /[\u202A-\u202F\u2066-\u2069]{3,}/,
    // Object replacement character (used in some crash attacks)
    /\uFFFC{3,}/,
];

const MAX_SAFE_MESSAGE_LENGTH = 8000;
const MAX_SAFE_NEWLINES = 200;

function detectVirtex(text) {
    if (!text || typeof text !== 'string') return null;

    if (text.length > MAX_SAFE_MESSAGE_LENGTH) {
        return `Message too long (${text.length} chars — limit ${MAX_SAFE_MESSAGE_LENGTH})`;
    }

    const newlines = (text.match(/\n/g) || []).length;
    if (newlines > MAX_SAFE_NEWLINES) {
        return `Excessive newlines (${newlines})`;
    }

    for (const pattern of CRASH_PATTERNS) {
        if (pattern.test(text)) {
            return `Crash pattern detected: ${pattern.toString().substring(0, 30)}`;
        }
    }

    return null;
}

function normalizeJid(jid) {
    if (!jid) return '';
    return jid.split('@')[0].split(':')[0] + '@s.whatsapp.net';
}

async function handleAntivirtexDetection(sock, chatId, message, userMessage, senderId) {
    try {
        if (!chatId.endsWith('@g.us')) return;
        if (message.key.fromMe) return;

        const config = getGroupConfig(chatId, 'antivirtex');
        if (!config?.enabled) return;

        const normalizedSender = normalizeJid(senderId);
        if (db.isSudo(senderId) || db.isSudo(normalizedSender)) return;

        const groupMetadata = await sock.groupMetadata(chatId);
        const botId = normalizeJid(sock.user.id);
        const botParticipant = groupMetadata.participants.find(p => normalizeJid(p.id) === botId);
        const botIsAdmin = !!botParticipant?.admin;

        const senderParticipant = groupMetadata.participants.find(p => normalizeJid(p.id) === normalizedSender);
        if (senderParticipant?.admin) return;

        const reason = detectVirtex(userMessage);
        if (!reason) return;

        const botName = getBotName();
        const fake = createFakeContact(senderId);
        const action = config.action || 'kick';
        const senderNumber = senderId.split('@')[0];

        if (botIsAdmin) {
            try { await sock.sendMessage(chatId, { delete: message.key }); } catch {}
        }

        switch (action) {
            case 'delete':
                await sock.sendMessage(chatId, {
                    text: `*${botName}*\n🛡️ Virtex/crash message blocked!\nFrom: @${senderNumber}\n${botIsAdmin ? 'Message deleted.' : '⚠️ Make me admin to delete messages.'}`,
                    mentions: [senderId]
                }, { quoted: fake });
                break;

            case 'kick':
                if (botIsAdmin) {
                    try {
                        await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
                        await sock.sendMessage(chatId, {
                            text: `*${botName}*\n🛡️ @${senderNumber} removed for sending a virtex/crash message!\nThis group is protected.`,
                            mentions: [senderId]
                        }, { quoted: fake });
                    } catch {
                        await sock.sendMessage(chatId, {
                            text: `*${botName}*\n🛡️ Virtex message detected from @${senderNumber}! (Could not remove — check admin permissions)`,
                            mentions: [senderId]
                        }, { quoted: fake });
                    }
                } else {
                    await sock.sendMessage(chatId, {
                        text: `*${botName}*\n🛡️ Virtex message from @${senderNumber} blocked!\n⚠️ Make me admin to remove the sender.`,
                        mentions: [senderId]
                    }, { quoted: fake });
                }
                break;

            case 'warn':
            default:
                await sock.sendMessage(chatId, {
                    text: `*${botName}*\n🛡️ ⚠️ @${senderNumber} sent a potential crash message!\nDo not send such messages.`,
                    mentions: [senderId]
                }, { quoted: fake });
                break;
        }
    } catch (err) {
        console.error('Error in handleAntivirtexDetection:', err.message);
    }
}

async function antivirtexCommand(sock, chatId, message, args) {
    const senderId = message.key.participant || message.key.remoteJid;
    const botName = getBotName();
    const fake = createFakeContact(senderId);

    try {
        const groupMetadata = await sock.groupMetadata(chatId);
        const participant = groupMetadata.participants.find(p => normalizeJid(p.id) === normalizeJid(senderId));
        if (!participant?.admin && !message.key.fromMe && !db.isSudo(senderId)) {
            return sock.sendMessage(chatId, { text: `*${botName}*\nAdmin only command!` }, { quoted: fake });
        }
    } catch {}

    const config = getGroupConfig(chatId, 'antivirtex') || {};
    const sub = (args || '').trim().toLowerCase();

    if (!sub) {
        const helpText = `*${botName} ANTIVIRTEX*\n\n` +
            `Status: ${config.enabled ? 'ON' : 'OFF'}\n` +
            `Action: ${config.action || 'kick'}\n\n` +
            `Protects against crash/vortex messages:\n` +
            `• RTL override attacks\n` +
            `• Zero-width character floods\n` +
            `• Zalgo/Unicode overload\n` +
            `• Message bombs (length/newline floods)\n\n` +
            `*Commands:*\n` +
            `.antivirtex on — Enable protection\n` +
            `.antivirtex off — Disable protection\n` +
            `.antivirtex warn — Warn only\n` +
            `.antivirtex delete — Delete crash messages\n` +
            `.antivirtex kick — Remove sender (recommended)\n` +
            `.antivirtex status — Show current config`;
        return sock.sendMessage(chatId, { text: helpText }, { quoted: fake });
    }

    let newConfig = { ...config };
    let responseText = '';

    const toggle = parseToggleCommand(sub);
    if (toggle === 'on') {
        newConfig.enabled = true;
        responseText = `*${botName}*\n🛡️ Antivirtex ENABLED\nAction: ${newConfig.action || 'kick'}`;
    } else if (toggle === 'off') {
        newConfig.enabled = false;
        responseText = `*${botName}*\n🛡️ Antivirtex DISABLED`;
    } else if (sub === 'warn' || sub === 'delete' || sub === 'kick') {
        newConfig.action = sub;
        newConfig.enabled = true;
        responseText = `*${botName}*\n🛡️ Antivirtex action: ${sub.toUpperCase()}\nProtection ENABLED`;
    } else if (sub === 'status') {
        responseText = `*${botName} ANTIVIRTEX STATUS*\n\nStatus: ${config.enabled ? 'ON' : 'OFF'}\nAction: ${config.action || 'kick'}`;
    } else {
        responseText = `*${botName}*\nInvalid command. Use .antivirtex for help.`;
    }

    setGroupConfig(chatId, 'antivirtex', newConfig);
    await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
}

module.exports = { antivirtexCommand, handleAntivirtexDetection };
