const { getOwnerConfig, setOwnerConfig, getGroupConfig, setGroupConfig, parseToggleCommand } = require('../../Database/settingsStore');
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

const originalMessages = new Map();
const MAX_STORED_MESSAGES = 5000;
const MESSAGE_RETENTION_MS = 604800000;

async function isAuthorized(sock, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        if (message.key.fromMe) return true;
        return db.isSudo(senderId);
    } catch {
        return message.key.fromMe;
    }
}

function normalizeOwnerConfig(raw) {
    if (!raw || typeof raw !== 'object') {
        return { gc: { enabled: true, mode: 'private' }, pm: { enabled: true, mode: 'private' } };
    }
    if (raw.gc && raw.pm) return raw;
    const enabled = raw.enabled !== undefined ? raw.enabled : true;
    const mode = raw.mode || 'private';
    return { gc: { enabled, mode }, pm: { enabled, mode } };
}

function getEffectiveConfig(chatId) {
    const isGroup = chatId.endsWith('@g.us');
    if (isGroup) {
        if (db.hasGroupSetting(chatId, 'antiedit')) {
            const groupConf = getGroupConfig(chatId, 'antiedit');
            if (typeof groupConf === 'object' && groupConf.enabled !== undefined) {
                return groupConf;
            }
        }
        const ownerRaw = getOwnerConfig('antiedit');
        const ownerConf = normalizeOwnerConfig(ownerRaw);
        return { enabled: ownerConf.gc.enabled, mode: ownerConf.gc.mode };
    } else {
        const ownerRaw = getOwnerConfig('antiedit');
        const ownerConf = normalizeOwnerConfig(ownerRaw);
        return { enabled: ownerConf.pm.enabled, mode: ownerConf.pm.mode };
    }
}

async function antieditCommand(sock, chatId, message, args) {
    const isGroup = chatId.endsWith('@g.us');
    const senderId = message.key.participant || message.key.remoteJid;
    const botName = getBotName();
    const fake = createFakeContact(senderId);
    
    if (isGroup) {
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participant = groupMetadata.participants.find(p => p.id === senderId);
            if (!participant?.admin && !message.key.fromMe && !db.isSudo(senderId)) {
                return sock.sendMessage(chatId, { 
                    text: `*${botName}*\nAdmin only command!` 
                }, { quoted: fake });
            }
        } catch {}
    } else {
        if (!await isAuthorized(sock, message)) {
            return sock.sendMessage(chatId, { 
                text: `*${botName}*\nOwner only command!` 
            }, { quoted: fake });
        }
    }

    const ownerRaw = getOwnerConfig('antiedit');
    const ownerConf = normalizeOwnerConfig(ownerRaw);
    const sub = (args || '').trim().toLowerCase();

    if (!sub) {
        const { getPrefix } = require('../owner/setprefix');
        const p = getPrefix();
        let groupStatus = '';
        if (isGroup) {
            const gc = getEffectiveConfig(chatId);
            groupStatus = `This Group: ${gc.enabled ? 'ON' : 'OFF'} (${gc.mode})\n`;
        }
        const helpText = `*${botName} ANTIEDIT*\n\n` +
                        `Groups: ${ownerConf.gc.enabled ? 'ON' : 'OFF'} (${ownerConf.gc.mode})\n` +
                        `PMs: ${ownerConf.pm.enabled ? 'ON' : 'OFF'} (${ownerConf.pm.mode})\n` +
                        `Tracked: ${originalMessages.size} messages\n\n` +
                        `*Commands:*\n` +
                        `${p}antiedit on — Enable all\n` +
                        `${p}antiedit off — Disable all\n` +
                        `${p}antiedit private — Notify in your DM\n` +
                        `${p}antiedit chat — Notify in same chat\n` +
                        `${p}antiedit both — Notify in DM + chat\n` +
                        `${p}antiedit gc off — Disable groups only\n` +
                        `${p}antiedit gc on — Enable groups only\n` +
                        `${p}antiedit pm off — Disable PMs only\n` +
                        `${p}antiedit pm on — Enable PMs only\n` +
                        `${p}antiedit status — Show status`;
        
        await sock.sendMessage(chatId, { text: helpText }, { quoted: fake });
        return;
    }

    let responseText = '';
    const parts = sub.split(/\s+/);
    const scope = parts[0];
    const action = parts[1] || '';

    if (scope === 'gc' || scope === 'group' || scope === 'groups') {
        const toggle = parseToggleCommand(action);
        if (toggle === 'on') {
            ownerConf.gc.enabled = true;
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit GROUPS: ON\nMode: ${ownerConf.gc.mode}`;
        } else if (toggle === 'off') {
            ownerConf.gc.enabled = false;
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit GROUPS: OFF`;
        } else if (['private', 'prvt', 'priv', 'pm'].includes(action)) {
            ownerConf.gc.enabled = true;
            ownerConf.gc.mode = 'private';
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit GROUPS: PRIVATE\nEdit notifications sent to owner DM.`;
        } else if (['chat', 'cht'].includes(action)) {
            ownerConf.gc.enabled = true;
            ownerConf.gc.mode = 'chat';
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit GROUPS: CHAT\nEdit notifications sent to same chat.`;
        } else if (['both', 'all'].includes(action)) {
            ownerConf.gc.enabled = true;
            ownerConf.gc.mode = 'both';
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit GROUPS: BOTH\nEdit notifications sent to owner DM and chat.`;
        } else {
            responseText = `*${botName}*\nUsage: .antiedit gc on/off/private/chat/both`;
        }
    } else if (scope === 'pm' || scope === 'dm' || scope === 'pms' || scope === 'dms') {
        const toggle = parseToggleCommand(action);
        if (toggle === 'on') {
            ownerConf.pm.enabled = true;
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit PMs: ON\nMode: ${ownerConf.pm.mode}`;
        } else if (toggle === 'off') {
            ownerConf.pm.enabled = false;
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit PMs: OFF`;
        } else if (['private', 'prvt', 'priv'].includes(action)) {
            ownerConf.pm.enabled = true;
            ownerConf.pm.mode = 'private';
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit PMs: PRIVATE\nEdit notifications sent to owner DM.`;
        } else if (['chat', 'cht'].includes(action)) {
            ownerConf.pm.enabled = true;
            ownerConf.pm.mode = 'chat';
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit PMs: CHAT\nEdit notifications sent to same chat.`;
        } else if (['both', 'all'].includes(action)) {
            ownerConf.pm.enabled = true;
            ownerConf.pm.mode = 'both';
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit PMs: BOTH\nEdit notifications sent to owner DM and chat.`;
        } else {
            responseText = `*${botName}*\nUsage: .antiedit pm on/off/private/chat/both`;
        }
    } else if (scope === 'status') {
        responseText = `*${botName} ANTIEDIT STATUS*\n\n` +
                      `Groups: ${ownerConf.gc.enabled ? 'ON' : 'OFF'} (${ownerConf.gc.mode})\n` +
                      `PMs: ${ownerConf.pm.enabled ? 'ON' : 'OFF'} (${ownerConf.pm.mode})\n` +
                      `Tracked: ${originalMessages.size} messages`;
    } else {
        const toggle = parseToggleCommand(scope);
        if (toggle === 'on') {
            ownerConf.gc.enabled = true;
            ownerConf.pm.enabled = true;
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit ENABLED (Groups + PMs)\nMode: ${ownerConf.gc.mode}`;
        } else if (toggle === 'off') {
            ownerConf.gc.enabled = false;
            ownerConf.pm.enabled = false;
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit DISABLED (Groups + PMs)`;
        } else if (['private', 'prvt', 'priv'].includes(scope)) {
            ownerConf.gc.enabled = true;
            ownerConf.gc.mode = 'private';
            ownerConf.pm.enabled = true;
            ownerConf.pm.mode = 'private';
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit PRIVATE (all chats).\nEdit notifications → your own DM.`;
        } else if (['chat', 'cht'].includes(scope)) {
            ownerConf.gc.enabled = true;
            ownerConf.gc.mode = 'chat';
            ownerConf.pm.enabled = true;
            ownerConf.pm.mode = 'chat';
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit CHAT (all chats).\nEdit notifications → same chat where edit happened.`;
        } else if (['both', 'all'].includes(scope)) {
            ownerConf.gc.enabled = true;
            ownerConf.gc.mode = 'both';
            ownerConf.pm.enabled = true;
            ownerConf.pm.mode = 'both';
            setOwnerConfig('antiedit', ownerConf);
            responseText = `*${botName}*\nAntiEdit BOTH (all chats).\nEdit notifications → your DM + same chat.`;
        } else {
            responseText = `*${botName}*\nInvalid! Use:\n` +
                          `.antiedit on/off\n` +
                          `.antiedit private/chat/both\n` +
                          `.antiedit gc on/off - Toggle groups only\n` +
                          `.antiedit pm on/off - Toggle PMs only`;
        }
    }

    await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
}

function storeOriginalMessage(message) {
    try {
        if (!message?.key?.id) return;
        
        const chatId = message.key.remoteJid;
        if (!chatId || chatId === 'status@broadcast') return;
        
        let text = '';
        const msg = message.message;
        if (!msg) return;
        
        if (msg.protocolMessage || msg.senderKeyDistributionMessage) return;
        
        if (msg.conversation) {
            text = msg.conversation;
        } else if (msg.extendedTextMessage?.text) {
            text = msg.extendedTextMessage.text;
        } else if (msg.imageMessage?.caption) {
            text = msg.imageMessage.caption;
        } else if (msg.videoMessage?.caption) {
            text = msg.videoMessage.caption;
        }
        
        if (!text) return;
        
        if (originalMessages.size >= MAX_STORED_MESSAGES) {
            const firstKey = originalMessages.keys().next().value;
            originalMessages.delete(firstKey);
        }
        
        originalMessages.set(message.key.id, {
            text,
            sender: message.key.participant || message.key.remoteJid,
            chatId,
            timestamp: Date.now(),
            pushName: message.pushName || 'Unknown'
        });
        
    } catch (err) {
        console.error('Error storing original message:', err.message, 'Line:', err.stack?.split('\n')[1]);
    }
}

async function handleEditedMessage(sock, editedMessage) {
    try {
        const chatId = editedMessage.key?.remoteJid;
        if (!chatId) {
            const msg = editedMessage.message || editedMessage.update?.message;
            const protoKey = msg?.protocolMessage?.key;
            if (protoKey?.id) {
                const orig = originalMessages.get(protoKey.id);
                if (orig?.chatId) {
                    editedMessage = { ...editedMessage, key: { ...editedMessage.key, remoteJid: orig.chatId } };
                } else {
                    return;
                }
            } else {
                return;
            }
        }
        
        const resolvedChatId = editedMessage.key.remoteJid;

        let messageId = editedMessage.key.id;
        
        const msg = editedMessage.message;
        if (msg?.protocolMessage?.key?.id) {
            messageId = msg.protocolMessage.key.id;
        }
        
        if (editedMessage.update?.message?.protocolMessage?.key?.id) {
            messageId = editedMessage.update.message.protocolMessage.key.id;
        }
        
        const original = originalMessages.get(messageId);
        if (!original) return;

        // Use the stored chatId from the original message as the authoritative target
        // resolvedChatId from the edit key can be wrong in LID/device contexts
        const notifyChatId = original.chatId || resolvedChatId;

        const config = getEffectiveConfig(notifyChatId);
        if (!config?.enabled) return;

        let newText = '';
        
        if (msg?.protocolMessage?.editedMessage) {
            const edited = msg.protocolMessage.editedMessage;
            if (edited.conversation) {
                newText = edited.conversation;
            } else if (edited.extendedTextMessage?.text) {
                newText = edited.extendedTextMessage.text;
            } else if (edited.imageMessage?.caption) {
                newText = edited.imageMessage.caption;
            } else if (edited.videoMessage?.caption) {
                newText = edited.videoMessage.caption;
            }
        } else if (msg?.editedMessage) {
            const em = msg.editedMessage.message || msg.editedMessage;
            if (em.conversation) {
                newText = em.conversation;
            } else if (em.extendedTextMessage?.text) {
                newText = em.extendedTextMessage.text;
            } else if (em.imageMessage?.caption) {
                newText = em.imageMessage.caption;
            } else if (em.videoMessage?.caption) {
                newText = em.videoMessage.caption;
            }
        }
        
        if (!newText && editedMessage.update?.message) {
            const updateMsg = editedMessage.update.message;
            if (updateMsg.conversation) {
                newText = updateMsg.conversation;
            } else if (updateMsg.extendedTextMessage?.text) {
                newText = updateMsg.extendedTextMessage.text;
            } else if (updateMsg.imageMessage?.caption) {
                newText = updateMsg.imageMessage.caption;
            } else if (updateMsg.videoMessage?.caption) {
                newText = updateMsg.videoMessage.caption;
            } else if (updateMsg.protocolMessage?.editedMessage) {
                const pe = updateMsg.protocolMessage.editedMessage;
                newText = pe.conversation || pe.extendedTextMessage?.text || pe.imageMessage?.caption || pe.videoMessage?.caption || '';
            }
        }
        
        if (!newText && msg) {
            newText = msg.conversation || msg.extendedTextMessage?.text || msg.imageMessage?.caption || msg.videoMessage?.caption || '';
        }
        
        if (!newText || newText === original.text) return;
        
        const botName = getBotName();
        const senderNumber = original.sender.split('@')[0];
        const time = new Date().toLocaleString('en-US', {
            hour12: true, hour: '2-digit', minute: '2-digit'
        });
        
        let groupName = '';
        if (notifyChatId.endsWith('@g.us')) {
            try {
                const metadata = await sock.groupMetadata(notifyChatId);
                groupName = metadata.subject;
            } catch {}
        }
        
        let notificationText = `*${botName} - MESSAGE EDITED*\n\n` +
                              `By: @${senderNumber}\n` +
                              `Name: ${original.pushName}\n` +
                              `Time: ${time}\n`;
        if (groupName) notificationText += `Group: ${groupName}\n`;
        notificationText += `\n*ORIGINAL MESSAGE:*\n${original.text.substring(0, 500)}${original.text.length > 500 ? '...' : ''}\n\n` +
                           `*EDITED TO:*\n${newText.substring(0, 500)}${newText.length > 500 ? '...' : ''}`;
        
        const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const fake = createFakeContact(original.sender);
        const mode = config.mode || 'private';
        
        const targets = [];
        if (mode === 'private' || mode === 'both') targets.push(ownerNumber);
        if ((mode === 'chat' || mode === 'both') && notifyChatId !== ownerNumber) targets.push(notifyChatId);
        if (targets.length === 0) targets.push(ownerNumber);
        
        for (const target of targets) {
            await sock.sendMessage(target, {
                text: notificationText,
                mentions: [original.sender]
            }, { quoted: fake });
        }
        
        originalMessages.set(messageId, {
            ...original,
            text: newText,
            timestamp: Date.now()
        });
        
    } catch (err) {
        console.error('Error handling edited message:', err.message, 'Line:', err.stack?.split('\n')[1]);
    }
}

setInterval(() => {
    const cutoff = Date.now() - MESSAGE_RETENTION_MS;
    for (const [key, value] of originalMessages.entries()) {
        if (value.timestamp < cutoff) {
            originalMessages.delete(key);
        }
    }
}, 3600000);

module.exports = {
    antieditCommand,
    storeOriginalMessage,
    handleEditedMessage,
    handleMessageUpdate: handleEditedMessage
};
