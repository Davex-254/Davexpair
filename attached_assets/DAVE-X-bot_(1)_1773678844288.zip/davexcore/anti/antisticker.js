const { getGroupConfig, setGroupConfig, deleteGroupToggle } = require('../../Database/settingsStore');
const isAdmin = require('../../davelib/isAdmin');
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { shouldWarn } = require('../../davelib/antiWarnCooldown');
const { sendAntiStatus } = require('../../davelib/antiStatusButtons');

async function antistickerCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message) {
    try {
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        if (!isSenderAdmin && !message?.key?.fromMe && !db.isSudo(senderId)) {
            await sock.sendMessage(chatId, { text: `*${botName}*\nAdmin only command!` }, { quoted: fake });
            return;
        }

        const args = userMessage.slice(12).toLowerCase().trim().split(' ');
        const action = args[0];

        if (!action) {
            const config = getGroupConfig(chatId, 'antisticker') || { enabled: false };
            const currentMode = config.enabled ? (config.action || 'delete') : 'off';
            const prefix = userMessage.charAt(0);
            await sendAntiStatus(sock, chatId, message, {
                label: 'ANTI-STICKER',
                configKey: 'antisticker',
                currentMode,
                prefix,
                modes: [
                    { label: 'Off', value: 'off' },
                    { label: 'Delete', value: 'delete' },
                    { label: 'Warn', value: 'warn' },
                    { label: 'Kick', value: 'kick' }
                ]
            });
            return;
        }

        const validModes = ["off", "delete", "warn", "kick"];

        if (!validModes.includes(action)) {
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\nInvalid mode! Use: off, delete, warn, kick` 
            }, { quoted: fake });
            return;
        }

        if (action === 'off') {
            deleteGroupToggle(chatId, 'antisticker');
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\nAnti-Sticker DISABLED` 
            }, { quoted: fake });
        } else {
            setGroupConfig(chatId, 'antisticker', { enabled: true, action: action });
            await sock.sendMessage(chatId, { 
                text: `*${botName}*\nAnti-Sticker: ${action.toUpperCase()}` 
            }, { quoted: fake });
        }
    } catch (error) {
        console.error('Error in antisticker command:', error.message, 'Line:', error.stack?.split('\n')[1]);
    }
}

async function handleStickerDetection(sock, chatId, message, senderId) {
    try {
        const isSticker = message.type === 'stickerMessage' || 
                         (message.message && message.message.stickerMessage);

        if (!isSticker) return;
        if (!chatId.endsWith('@g.us')) return;

        const config = getGroupConfig(chatId, 'antisticker');
        if (!config || !config.enabled) return;

        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
        if (!isBotAdmin || isSenderAdmin || db.isSudo(senderId)) return;

        const botName = getBotName();
        const userTag = `@${senderId.split("@")[0]}`;

        try {
            await sock.sendMessage(chatId, {
                delete: {
                    remoteJid: chatId,
                    fromMe: false,
                    id: message.key.id,
                    participant: senderId
                }
            });
        } catch (e) {
            console.error("[ANTI-STICKER] Delete failed:", e.message);
            return;
        }

        if (config.action === 'kick') {
            if (shouldWarn(chatId, senderId, 'sticker')) {
                await sock.sendMessage(chatId, {
                    text: `*${botName}*\n\n${userTag} kicked for sending sticker.`,
                    mentions: [senderId]
                });
            }
            await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
        } else {
            if (shouldWarn(chatId, senderId, 'sticker')) {
                await sock.sendMessage(chatId, {
                    text: `*${botName}*\n\n${userTag}, stickers are not allowed!`,
                    mentions: [senderId]
                });
            }
        }
    } catch (error) {
        console.error('Error in handleStickerDetection:', error.message, 'Line:', error.stack?.split('\n')[1]);
    }
}

module.exports = {
    antistickerCommand,
    handleStickerDetection
};
