const { getGroupConfig, setGroupConfig, deleteGroupToggle } = require('../../Database/settingsStore');
const isAdmin = require('../../davelib/isAdmin');
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { shouldWarn } = require('../../davelib/antiWarnCooldown');
const { sendAntiStatus } = require('../../davelib/antiStatusButtons');

async function antiforwardCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message) {
    try {
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        if (!isSenderAdmin && !message?.key?.fromMe && !db.isSudo(senderId)) {
            await sock.sendMessage(chatId, { text: `*${botName}*\nAdmin only command!` }, { quoted: fake });
            return;
        }

        const args = userMessage.slice(12).toLowerCase().trim().split(' ');
        const action = args[0];

        if (!action) {
            const config = getGroupConfig(chatId, 'antiforward') || { enabled: false };
            const currentMode = config.enabled ? (config.action || 'delete') : 'off';
            const prefix = userMessage.charAt(0);
            await sendAntiStatus(sock, chatId, message, {
                label: 'ANTI-FORWARD',
                configKey: 'antiforward',
                currentMode,
                prefix,
                modes: [
                    { label: 'Off', value: 'off' },
                    { label: 'Delete', value: 'delete' },
                    { label: 'Warn', value: 'warn' },
                    { label: 'Kick', value: 'kick' }
                ]
            });
            return;
        }

        const validModes = ['off', 'delete', 'warn', 'kick'];
        if (!validModes.includes(action)) {
            await sock.sendMessage(chatId, {
                text: `*${botName}*\nInvalid mode! Use: off, delete, warn, kick`
            }, { quoted: fake });
            return;
        }

        if (action === 'off') {
            deleteGroupToggle(chatId, 'antiforward');
            await sock.sendMessage(chatId, {
                text: `*${botName}*\nAnti-Forward DISABLED`
            }, { quoted: fake });
        } else {
            setGroupConfig(chatId, 'antiforward', { enabled: true, action });
            await sock.sendMessage(chatId, {
                text: `*${botName}*\nAnti-Forward: ${action.toUpperCase()}`
            }, { quoted: fake });
        }
    } catch (error) {
        console.error('Error in antiforward command:', error.message);
    }
}

async function handleForwardDetection(sock, chatId, message, senderId) {
    try {
        if (!chatId.endsWith('@g.us')) return;

        const config = getGroupConfig(chatId, 'antiforward');
        if (!config || !config.enabled) return;

        const ctx = message.message?.extendedTextMessage?.contextInfo ||
                    message.message?.imageMessage?.contextInfo ||
                    message.message?.videoMessage?.contextInfo ||
                    message.message?.audioMessage?.contextInfo ||
                    message.message?.documentMessage?.contextInfo ||
                    message.message?.stickerMessage?.contextInfo;

        const isForwarded = ctx?.isForwarded || (ctx?.forwardingScore > 0);
        if (!isForwarded) return;

        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
        if (!isBotAdmin || isSenderAdmin || db.isSudo(senderId)) return;

        const botName = getBotName();
        const userTag = `@${senderId.split('@')[0]}`;

        try {
            await sock.sendMessage(chatId, {
                delete: {
                    remoteJid: chatId,
                    fromMe: false,
                    id: message.key.id,
                    participant: senderId
                }
            });
        } catch {
            return;
        }

        if (config.action === 'kick') {
            if (shouldWarn(chatId, senderId, 'forward')) {
                await sock.sendMessage(chatId, {
                    text: `*${botName}*\n\n${userTag} kicked for forwarding messages.`,
                    mentions: [senderId]
                });
            }
            await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
        } else {
            if (shouldWarn(chatId, senderId, 'forward')) {
                await sock.sendMessage(chatId, {
                    text: `*${botName}*\n\n${userTag}, forwarded messages are not allowed!`,
                    mentions: [senderId]
                });
            }
        }
    } catch (error) {
        console.error('Error in handleForwardDetection:', error.message);
    }
}

module.exports = { antiforwardCommand, handleForwardDetection };
