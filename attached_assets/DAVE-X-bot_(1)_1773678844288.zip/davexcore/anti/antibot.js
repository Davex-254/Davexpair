const { getGroupConfig, setGroupConfig, parseToggleCommand } = require('../../Database/settingsStore');
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

// Common WhatsApp bot JID suffixes and patterns
const BOT_HEURISTICS = [
    // Typical bot prefixes in message text
    /^[!\/\.\$\#\@\~\*\^\&\%\=\+\-]{1,2}[a-z]/i,
    // Bot response frames (box drawing)
    /[┌└├│╔╗╚╝╠╣╦╩╬]+/,
    // Common bot banners
    /DAVE-X|BOT|𝗕𝗢𝗧|ʙᴏᴛ|𝘽𝙊𝙏/i
];

function normalizeJid(jid) {
    if (!jid) return '';
    return jid.split('@')[0].split(':')[0] + '@s.whatsapp.net';
}

function isBotMessage(message, userMessage) {
    if (!message || !userMessage) return false;

    // Check heuristics against message text
    for (const pattern of BOT_HEURISTICS) {
        if (pattern.test(userMessage)) return true;
    }

    return false;
}

async function handleAntibotDetection(sock, chatId, message, userMessage, senderId) {
    try {
        if (!chatId.endsWith('@g.us')) return;
        if (message.key.fromMe) return;

        const config = getGroupConfig(chatId, 'antibot');
        if (!config?.enabled) return;

        const normalizedSender = normalizeJid(senderId);
        if (db.isSudo(senderId) || db.isSudo(normalizedSender)) return;

        const groupMetadata = await sock.groupMetadata(chatId);
        const botId = normalizeJid(sock.user.id);
        const botParticipant = groupMetadata.participants.find(p => normalizeJid(p.id) === botId);
        const botIsAdmin = !!botParticipant?.admin;

        const senderParticipant = groupMetadata.participants.find(p => normalizeJid(p.id) === normalizedSender);
        if (senderParticipant?.admin) return;

        // Check manual bot JID list first
        const knownBots = Array.isArray(config.bots) ? config.bots : [];
        const isKnownBot = knownBots.some(b => normalizeJid(b) === normalizedSender);

        // Also check message heuristics if heuristic mode is on
        const heuristicsEnabled = config.heuristics !== false;
        const detectedByHeuristic = heuristicsEnabled && isBotMessage(message, userMessage || '');

        if (!isKnownBot && !detectedByHeuristic) return;

        const botName = getBotName();
        const fake = createFakeContact(senderId);
        const action = config.action || 'warn';
        const senderNumber = senderId.split('@')[0];

        if (botIsAdmin) {
            try { await sock.sendMessage(chatId, { delete: message.key }); } catch {}
        }

        const reason = isKnownBot ? 'Known bot JID' : 'Bot-like message pattern';

        switch (action) {
            case 'delete':
                await sock.sendMessage(chatId, {
                    text: `*${botName}*\n@${senderNumber} — bot activity detected!\nReason: ${reason}\n${botIsAdmin ? 'Message deleted.' : '⚠️ Make me admin to delete messages.'}`,
                    mentions: [senderId]
                }, { quoted: fake });
                break;

            case 'kick':
                if (botIsAdmin) {
                    try {
                        await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
                        await sock.sendMessage(chatId, {
                            text: `*${botName}*\n@${senderNumber} removed — bot activity detected!\nReason: ${reason}`,
                            mentions: [senderId]
                        }, { quoted: fake });
                    } catch {
                        await sock.sendMessage(chatId, {
                            text: `*${botName}*\n@${senderNumber} — bot detected! (Could not remove — check admin permissions)`,
                            mentions: [senderId]
                        }, { quoted: fake });
                    }
                } else {
                    await sock.sendMessage(chatId, {
                        text: `*${botName}*\n@${senderNumber} — bot activity detected!\n⚠️ Make me admin to remove bots.`,
                        mentions: [senderId]
                    }, { quoted: fake });
                }
                break;

            case 'warn':
            default:
                await sock.sendMessage(chatId, {
                    text: `*${botName}*\n⚠️ @${senderNumber} — bot activity detected in this group!\nReason: ${reason}`,
                    mentions: [senderId]
                }, { quoted: fake });
                break;
        }
    } catch (err) {
        console.error('Error in handleAntibotDetection:', err.message);
    }
}

async function antibotCommand(sock, chatId, message, args) {
    const senderId = message.key.participant || message.key.remoteJid;
    const botName = getBotName();
    const fake = createFakeContact(senderId);

    try {
        const groupMetadata = await sock.groupMetadata(chatId);
        const participant = groupMetadata.participants.find(p => normalizeJid(p.id) === normalizeJid(senderId));
        if (!participant?.admin && !message.key.fromMe && !db.isSudo(senderId)) {
            return sock.sendMessage(chatId, { text: `*${botName}*\nAdmin only command!` }, { quoted: fake });
        }
    } catch {}

    const config = getGroupConfig(chatId, 'antibot') || {};
    const sub = (args || '').trim().toLowerCase();

    if (!sub) {
        const knownBots = Array.isArray(config.bots) ? config.bots : [];
        const helpText = `*${botName} ANTIBOT*\n\n` +
            `Status: ${config.enabled ? 'ON' : 'OFF'}\n` +
            `Action: ${config.action || 'warn'}\n` +
            `Heuristics: ${config.heuristics !== false ? 'ON' : 'OFF'}\n` +
            `Known bots: ${knownBots.length}\n\n` +
            `*Commands:*\n` +
            `.antibot on — Enable\n` +
            `.antibot off — Disable\n` +
            `.antibot warn — Warn on detection\n` +
            `.antibot delete — Delete bot messages\n` +
            `.antibot kick — Remove bots from group\n` +
            `.antibot heuristics on/off — Toggle auto-detection\n` +
            `.antibot add @user — Add to known bot list\n` +
            `.antibot remove @user — Remove from list\n` +
            `.antibot list — Show known bots`;
        return sock.sendMessage(chatId, { text: helpText }, { quoted: fake });
    }

    let newConfig = { ...config };
    let responseText = '';

    const toggle = parseToggleCommand(sub);
    if (toggle === 'on') {
        newConfig.enabled = true;
        responseText = `*${botName}*\nAntibot ENABLED\nAction: ${newConfig.action || 'warn'}`;
    } else if (toggle === 'off') {
        newConfig.enabled = false;
        responseText = `*${botName}*\nAntibot DISABLED`;
    } else if (sub === 'warn' || sub === 'delete' || sub === 'kick') {
        newConfig.action = sub;
        newConfig.enabled = true;
        responseText = `*${botName}*\nAntibot action: ${sub.toUpperCase()}`;
    } else if (sub === 'list') {
        const bots = Array.isArray(config.bots) ? config.bots : [];
        responseText = `*${botName} ANTIBOT LIST*\n\n` + (bots.length ? bots.map(b => `• ${b.split('@')[0]}`).join('\n') : 'No bots in list yet.\nUse .antibot add @user to add one.');
    } else if (sub.startsWith('heuristics ')) {
        const hToggle = parseToggleCommand(sub.replace('heuristics ', '').trim());
        if (hToggle === 'on') { newConfig.heuristics = true; responseText = `*${botName}*\nAntibot heuristics (auto-detection) ON`; }
        else if (hToggle === 'off') { newConfig.heuristics = false; responseText = `*${botName}*\nAntibot heuristics OFF — only manual list used`; }
        else responseText = `*${botName}*\nUse: .antibot heuristics on/off`;
    } else if (sub.startsWith('add ')) {
        const targets = (message.message?.extendedTextMessage?.contextInfo?.mentionedJid || []);
        if (targets.length === 0) {
            responseText = `*${botName}*\nTag the user(s) to add as known bot. Example: .antibot add @user`;
        } else {
            const bots = Array.isArray(config.bots) ? [...config.bots] : [];
            const added = [];
            for (const t of targets) {
                const n = normalizeJid(t);
                if (!bots.includes(n)) { bots.push(n); added.push(t.split('@')[0]); }
            }
            newConfig.bots = bots;
            if (!newConfig.enabled) newConfig.enabled = true;
            responseText = `*${botName}*\n✅ Added ${added.length} bot(s): ${added.join(', ')}`;
        }
    } else if (sub.startsWith('remove ')) {
        const targets = (message.message?.extendedTextMessage?.contextInfo?.mentionedJid || []);
        if (targets.length === 0) {
            responseText = `*${botName}*\nTag the user(s) to remove. Example: .antibot remove @user`;
        } else {
            const bots = Array.isArray(config.bots) ? [...config.bots] : [];
            const removed = [];
            for (const t of targets) {
                const n = normalizeJid(t);
                const idx = bots.indexOf(n);
                if (idx > -1) { bots.splice(idx, 1); removed.push(t.split('@')[0]); }
            }
            newConfig.bots = bots;
            responseText = `*${botName}*\n✅ Removed: ${removed.join(', ')}`;
        }
    } else {
        responseText = `*${botName}*\nInvalid command. Use .antibot for help.`;
    }

    setGroupConfig(chatId, 'antibot', newConfig);
    await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
}

module.exports = { antibotCommand, handleAntibotDetection };
