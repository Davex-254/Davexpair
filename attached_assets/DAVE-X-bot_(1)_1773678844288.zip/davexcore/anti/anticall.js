const { getOwnerConfig, setOwnerConfig, parseToggleCommand, parseActionCommand } = require('../../Database/settingsStore');
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

const processedCalls = new Map();
const CALL_COOLDOWN_MS = 30000;

async function isAuthorized(sock, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        if (message.key.fromMe) return true;
        return db.isSudo(senderId);
    } catch {
        return message.key.fromMe;
    }
}

async function anticallCommand(sock, chatId, message, args) {
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    
    if (!await isAuthorized(sock, message)) {
        return sock.sendMessage(chatId, { 
            text: `✦ Owner only command` 
        }, { quoted: fake });
    }

    const config = getOwnerConfig('anticall') || { enabled: false, mode: 'block', message: 'Calls not allowed!' };
    const sub = (args || '').trim().toLowerCase();

    if (!sub) {
        const helpText = `✦ *ANTICALL*
    
  Status: ${config.enabled ? 'ON' : 'OFF'}
  Mode: ${config.mode || 'block'}
  Message: ${config.message || 'Calls not allowed!'}

  Commands:
  › on
  › off
  › block
  › decline
  › both
  › allow
  › .setcallmsg <text>
  › status`;
        
        await sock.sendMessage(chatId, { text: helpText }, { quoted: fake });
        return;
    }

    let newConfig = { ...config };
    let responseText = '';

    if (sub === 'status') {
        const statusText = `✦ *ANTICALL STATUS*
    
  Status: ${config.enabled ? 'ACTIVE' : 'INACTIVE'}
  Mode: ${config.mode || 'block'}
  Message: ${config.message || 'Calls not allowed!'}`;
        await sock.sendMessage(chatId, { text: statusText }, { quoted: fake });
        return;
    }

    const toggle = parseToggleCommand(sub);
    if (toggle === 'on') {
        newConfig.enabled = true;
        responseText = `✦ Anticall ENABLED\n  Mode: ${newConfig.mode || 'block'}`;
    } else if (toggle === 'off') {
        newConfig.enabled = false;
        responseText = `✦ Anticall DISABLED`;
    } else {
        const action = parseActionCommand(sub);
        if (action === 'block') {
            newConfig.mode = 'block';
            newConfig.enabled = true;
            responseText = `✦ Mode: BLOCK\n  Callers will be blocked`;
        } else if (action === 'decline') {
            newConfig.mode = 'decline';
            newConfig.enabled = true;
            responseText = `✦ Mode: DECLINE\n  Calls will be declined only`;
        } else if (sub === 'both') {
            newConfig.mode = 'both';
            newConfig.enabled = true;
            responseText = `✦ Mode: BOTH\n  Declined and blocked`;
        } else if (action === 'allow') {
            newConfig.mode = 'allow';
            newConfig.enabled = false;
            responseText = `✦ Mode: ALLOW\n  All calls allowed`;
        } else if (sub.startsWith('msg ') || sub.startsWith('message ')) {
            const msgText = args.replace(/^(msg|message)\s+/i, '').trim();
            if (msgText) {
                newConfig.message = msgText;
                responseText = `✦ Message set: "${msgText}"`;
            } else {
                responseText = `✦ Provide a message`;
            }
        } else {
            responseText = `✦ Invalid command\n  Use: on, off, block, decline, both, allow`;
        }
    }

    if (responseText && !responseText.includes('Invalid') && !responseText.includes('Provide')) {
        setOwnerConfig('anticall', newConfig);
    }

    await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
}

async function setcallmsgCommand(sock, chatId, message, args) {
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    
    if (!await isAuthorized(sock, message)) {
        return sock.sendMessage(chatId, { 
            text: `✦ Owner only command` 
        }, { quoted: fake });
    }

    const msgText = (args || '').trim();
    
    if (!msgText) {
        const config = getOwnerConfig('anticall') || { message: 'Calls not allowed!' };
        return sock.sendMessage(chatId, { 
            text: `✦ *SETCALLMSG*
    
  Current: ${config.message}

  Use: .setcallmsg <message>` 
        }, { quoted: fake });
    }

    const config = getOwnerConfig('anticall') || {};
    setOwnerConfig('anticall', { ...config, message: msgText });
    
    await sock.sendMessage(chatId, { 
        text: `✦ Message set: "${msgText}"` 
    }, { quoted: fake });
}

async function handleIncomingCall(sock, call) {
    try {
        const config = getOwnerConfig('anticall');
        if (!config || !config.enabled || config.mode === 'allow') return;

        // Group calls are handled by groupanticall — silently reject here to suppress notification
        if (call.isGroup) {
            try { await sock.rejectCall(call.id, call.chatId || call.from); } catch {}
            return;
        }

        const callKey = call.id || `${call.from}_${Date.now()}`;
        const now = Date.now();
        if (processedCalls.has(callKey)) {
            const lastTime = processedCalls.get(callKey);
            if (now - lastTime < CALL_COOLDOWN_MS) return;
        }
        processedCalls.set(callKey, now);

        if (processedCalls.size > 50) {
            for (const [key, time] of processedCalls) {
                if (now - time > 60000) processedCalls.delete(key);
            }
        }

        // Baileys v7: call.from may be a LID JID for newer accounts.
        // call.callerPn is the real phone number in that case — use it for messaging.
        const callerId = call.callerPn
            ? (call.callerPn.endsWith('@s.whatsapp.net') ? call.callerPn : call.callerPn + '@s.whatsapp.net')
            : call.from;
        const callerNumber = callerId.split('@')[0];
        const callType = call.isVideo ? '📹 Video' : '📞 Voice';
        const botName = getBotName();
        const fake = createFakeContact(callerId);

        // Reject the call first (uses call.chatId per Baileys v7 rejectCall signature)
        try { await sock.rejectCall(call.id, call.chatId || call.from); } catch (e) {}

        const customMsg = config.message || 'Calls not allowed!';
        let modeText = '';

        switch (config.mode) {
            case 'block':
                modeText = 'You have been blocked';
                break;
            case 'decline':
                modeText = 'Call declined';
                break;
            case 'both':
                modeText = 'Call declined and blocked';
                break;
            default:
                modeText = 'Call declined';
        }

        await sock.sendMessage(callerId, {
            text: `✦ *${botName}*\n\n${customMsg}\n${modeText}`
        }, { quoted: fake });

        if (config.mode === 'block' || config.mode === 'both') {
            try {
                await sock.updateBlockStatus(callerId, 'block');
            } catch (blockErr) {
                console.error('Error blocking caller:', blockErr.message);
            }

            const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
            await sock.sendMessage(ownerNumber, {
                text: `✦ *CALL BLOCKED*\n\nFrom: @${callerNumber}\nType: ${callType}\nAction: ${config.mode.toUpperCase()}`,
                mentions: [callerId]
            }, { quoted: fake });
        }

    } catch (err) {
        console.error('Error handling call:', err.message);
    }
}

function readState() {
    const config = getOwnerConfig('anticall') || {};
    return { enabled: config.enabled || false };
}

module.exports = { 
    anticallCommand, 
    setcallmsgCommand,
    handleIncomingCall,
    readState 
};