const { getOwnerConfig, setOwnerConfig } = require('../../Database/settingsStore');
const { isBugMessage } = require('../../davelib/index');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { getPrefix } = require('../owner/setprefix');

function getConfig() {
    return getOwnerConfig('antibugdm') || { enabled: false, action: 'block' };
}

async function handleAntibugDm(sock, chatId, message, senderId) {
    try {
        if (chatId.endsWith('@g.us')) return;
        if (message.key.fromMe) return;

        const config = getConfig();
        if (!config.enabled) return;

        if (!isBugMessage(message)) return;

        const botName = getBotName();
        const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const senderNumber = senderId.split('@')[0];

        await sock.sendMessage(ownerNumber, {
            text: `*${botName} - ANTIBUGDM*\n\n🛡️ Bug/crash message detected in DM\nFrom: @${senderNumber}\nAction: ${config.action.toUpperCase()}`,
            mentions: [senderId]
        }).catch(() => {});

        if (config.action === 'block' || config.action === 'warn') {
            await sock.updateBlockStatus(senderId, 'block').catch(() => {});
        }

    } catch (err) {
        console.error('[ANTIBUGDM]', err.message);
    }
}

async function antibugDmCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const prefix = getPrefix();
    const sub = (args || '').trim().toLowerCase();
    const config = getConfig();

    const reply = (text) => sock.sendMessage(chatId, { text }, { quoted: fake });

    if (!sub) {
        return reply(
            `*${botName} - ANTIBUGDM*\n\n` +
            `Status: ${config.enabled ? 'ON' : 'OFF'}\n` +
            `Action: ${config.action}\n\n` +
            `*Commands:*\n` +
            `${prefix}antibugdm on — Enable (block bug senders)\n` +
            `${prefix}antibugdm off — Disable\n` +
            `${prefix}antibugdm block — Block sender (default)\n` +
            `${prefix}antibugdm warn — Notify only, no block\n` +
            `${prefix}antibugdm status — Show current settings`
        );
    }

    if (sub === 'on') {
        setOwnerConfig('antibugdm', { enabled: true, action: config.action || 'block' });
        return reply(`*${botName}*\nAntiBugDM: ON\nAction: ${config.action || 'block'}`);
    }
    if (sub === 'off') {
        setOwnerConfig('antibugdm', { enabled: false, action: config.action });
        return reply(`*${botName}*\nAntiBugDM: OFF`);
    }
    if (sub === 'block') {
        setOwnerConfig('antibugdm', { enabled: true, action: 'block' });
        return reply(`*${botName}*\nAntiBugDM: ON — Bug senders will be BLOCKED`);
    }
    if (sub === 'warn') {
        setOwnerConfig('antibugdm', { enabled: true, action: 'warn' });
        return reply(`*${botName}*\nAntiBugDM: ON — Bug messages notify only (no block)`);
    }
    if (sub === 'status') {
        return reply(`*${botName} - ANTIBUGDM STATUS*\n\nEnabled: ${config.enabled ? 'YES' : 'NO'}\nAction: ${config.action}`);
    }

    return reply(`*${botName}*\nInvalid option. Use: on, off, block, warn, status`);
}

module.exports = { antibugDmCommand, handleAntibugDm };
