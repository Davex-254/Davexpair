const { getGroupConfig, setGroupConfig } = require('../../Database/settingsStore');
const db = require('../../Database/database');
const isAdmin = require('../../davelib/isAdmin');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

const processedGroupCalls = new Map();
const GROUP_CALL_COOLDOWN_MS = 30000;

async function groupanticallCommand(sock, chatId, message, args) {
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const isGroup = chatId.endsWith('@g.us');

    if (!isGroup) {
        return sock.sendMessage(chatId, {
            text: `┌─ *${botName}* ─┐\n│\n│ Group command only!\n│\n└─────────────┘`
        }, { quoted: fake });
    }

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
    if (!isSenderAdmin && !message.key.fromMe && !db.isSudo(senderId)) {
        return sock.sendMessage(chatId, {
            text: `┌─ *${botName}* ─┐\n│\n│ Admin only command!\n│\n└─────────────┘`
        }, { quoted: fake });
    }

    const config = getGroupConfig(chatId, 'groupanticall') || { enabled: false, action: 'warn' };
    const sub = (args || '').trim().toLowerCase();

    if (!sub) {
        const helpText = `┌─ *${botName}* ─┐
│
│ *ANTI-CALL (Group)*
│ Status: ${config.enabled ? '✅ ON' : '❌ OFF'}
│ Action: ${(config.action || 'warn').toUpperCase()}
│ Bot admin: ${isBotAdmin ? 'Yes' : 'No'}
│
│ Commands:
│ .groupanticall on
│ .groupanticall off
│ .groupanticall warn
│ .groupanticall delete
│ .groupanticall kick
│ .groupanticall status
│
│ Actions:
│ WARN - Silence + warn in group
│ DELETE - Silence + remove caller
│ KICK - Silence + kick caller
│
└─────────────┘`;
        return sock.sendMessage(chatId, { text: helpText }, { quoted: fake });
    }

    let newConfig = { ...config };
    let responseText = '';

    if (sub === 'status') {
        responseText = `┌─ *${botName}* ─┐
│
│ Anti-Call: ${config.enabled ? '✅ ACTIVE' : '❌ INACTIVE'}
│ Action: ${(config.action || 'warn').toUpperCase()}
│ Bot admin: ${isBotAdmin ? 'Yes' : 'No'}
│
└─────────────┘`;
    } else if (sub === 'on' || sub === 'enable') {
        newConfig.enabled = true;
        if (!newConfig.action) newConfig.action = 'warn';
        responseText = `┌─ *${botName}* ─┐\n│\n│ ✅ Anti-Call ENABLED\n│ Action: ${newConfig.action.toUpperCase()}\n│\n└─────────────┘`;
        setGroupConfig(chatId, 'groupanticall', newConfig);
    } else if (sub === 'off' || sub === 'disable') {
        newConfig.enabled = false;
        responseText = `┌─ *${botName}* ─┐\n│\n│ ❌ Anti-Call DISABLED\n│\n└─────────────┘`;
        setGroupConfig(chatId, 'groupanticall', newConfig);
    } else if (sub === 'warn') {
        newConfig.enabled = true;
        newConfig.action = 'warn';
        responseText = `┌─ *${botName}* ─┐\n│\n│ Mode: WARN\n│ Silence call + warn in group\n│\n└─────────────┘`;
        setGroupConfig(chatId, 'groupanticall', newConfig);
    } else if (sub === 'delete' || sub === 'remove') {
        newConfig.enabled = true;
        newConfig.action = 'delete';
        responseText = isBotAdmin
            ? `┌─ *${botName}* ─┐\n│\n│ Mode: DELETE\n│ Silence + remove caller\n│\n└─────────────┘`
            : `┌─ *${botName}* ─┐\n│\n│ Mode: DELETE\n│ ⚠️ Bot needs admin rights!\n│\n└─────────────┘`;
        setGroupConfig(chatId, 'groupanticall', newConfig);
    } else if (sub === 'kick') {
        newConfig.enabled = true;
        newConfig.action = 'kick';
        responseText = isBotAdmin
            ? `┌─ *${botName}* ─┐\n│\n│ Mode: KICK\n│ Silence + kick caller\n│\n└─────────────┘`
            : `┌─ *${botName}* ─┐\n│\n│ Mode: KICK\n│ ⚠️ Bot needs admin rights!\n│\n└─────────────┘`;
        setGroupConfig(chatId, 'groupanticall', newConfig);
    } else {
        responseText = `┌─ *${botName}* ─┐\n│\n│ Invalid option!\n│ Use: on, off, warn, delete, kick, status\n│\n└─────────────┘`;
    }

    await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
}

async function handleGroupCall(sock, call) {
    try {
        if (!call.isGroup) return false;

        // Baileys v7: call.from = caller participant JID (may be LID).
        // call.callerPn = real phone number JID when call.from is a LID JID.
        const callerJid = call.callerPn
            ? (call.callerPn.endsWith('@s.whatsapp.net') ? call.callerPn : call.callerPn + '@s.whatsapp.net')
            : call.from;
        if (!callerJid) return false;

        // For group calls, chatId is the group JID; groupJid is also available
        const groupJid = call.groupJid || call.chatId;
        if (!groupJid || !groupJid.endsWith('@g.us')) return false;

        const config = getGroupConfig(groupJid, 'groupanticall');
        if (!config || !config.enabled) return false;

        const callKey = call.id || `${callerJid}_${groupJid}_${Date.now()}`;
        const now = Date.now();
        if (processedGroupCalls.has(callKey)) {
            const lastTime = processedGroupCalls.get(callKey);
            if (now - lastTime < GROUP_CALL_COOLDOWN_MS) return true;
        }
        processedGroupCalls.set(callKey, now);

        if (processedGroupCalls.size > 50) {
            for (const [key, time] of processedGroupCalls) {
                if (now - time > 60000) processedGroupCalls.delete(key);
            }
        }

        // Silence the call — for group calls, rejectCall targets the group JID (call.chatId)
        try {
            await sock.rejectCall(call.id, groupJid);
        } catch (e) {}

        const botName = getBotName();
        const callerTag = `@${callerJid.split('@')[0]}`;
        const action = config.action || 'warn';

        // Send warning to GROUP (not to caller's inbox)
        if (action === 'warn') {
            try {
                await sock.sendMessage(groupJid, {
                    text: `⚠️ *${botName}*\n\n${callerTag} tried to start a call.\n📵 Call has been silenced — calls are not allowed in this group!`,
                    mentions: [callerJid]
                });
            } catch (e) {}
        } else if (action === 'delete' || action === 'kick') {
            try {
                const botJid = sock.user?.id?.split(':')[0] + '@s.whatsapp.net';
                const groupMeta = await sock.groupMetadata(groupJid);
                const botIsAdmin = groupMeta.participants.some(
                    p => (p.id === botJid || p.id.startsWith(sock.user?.id?.split(':')[0])) &&
                         (p.admin === 'admin' || p.admin === 'superadmin')
                );
                const callerIsAdmin = groupMeta.participants.some(
                    p => p.id === callerJid && (p.admin === 'admin' || p.admin === 'superadmin')
                );

                if (callerIsAdmin) {
                    await sock.sendMessage(groupJid, {
                        text: `⚠️ *${botName}*\n\n${callerTag} tried to call — calls not allowed!\n⚡ Cannot remove admin.`,
                        mentions: [callerJid]
                    });
                } else if (botIsAdmin) {
                    await sock.sendMessage(groupJid, {
                        text: `⚠️ *${botName}*\n\n${callerTag} tried to start a call.\n📵 Call silenced — caller removed from group!`,
                        mentions: [callerJid]
                    });
                    await sock.groupParticipantsUpdate(groupJid, [callerJid], 'remove');
                } else {
                    await sock.sendMessage(groupJid, {
                        text: `⚠️ *${botName}*\n\n${callerTag} tried to call — calls not allowed!\n⚡ Bot needs admin rights to remove.`,
                        mentions: [callerJid]
                    });
                }
            } catch (e) {}
        }

        return true;
    } catch (error) {
        return false;
    }
}

module.exports = {
    groupanticallCommand,
    handleGroupCall
};
