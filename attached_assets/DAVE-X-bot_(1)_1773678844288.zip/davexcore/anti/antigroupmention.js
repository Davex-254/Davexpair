const { getGroupConfig, setGroupConfig, deleteGroupToggle } = require('../../Database/settingsStore');
const isAdmin = require('../../davelib/isAdmin');
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { getPrefix } = require('../owner/setprefix');

// Rate limit: max 1 action per sender per group per 30 seconds — prevents double-fire
// Uses phone digits so LID and phone JID for the same person share one slot
const _rateLimitMap = new Map();
function isRateLimited(chatId, sender) {
    const senderPhone = (sender || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    const key = `${chatId}:${senderPhone}`;
    const last = _rateLimitMap.get(key) || 0;
    if (Date.now() - last < 30000) return true;
    _rateLimitMap.set(key, Date.now());
    if (_rateLimitMap.size > 300) {
        const cutoff = Date.now() - 120000;
        for (const [k, v] of _rateLimitMap) if (v < cutoff) _rateLimitMap.delete(k);
    }
    return false;
}

async function handleAntiStatusMention(sock, m) {
    try {
        if (!m?.message) return;
        if (m.key.fromMe) return;
        
        const chatId = m.key.remoteJid;
        if (!chatId?.endsWith('@g.us')) return;

        const config = getGroupConfig(chatId, 'antigroupmention');
        if (!config || !config.enabled) return;

        const mode = config.action || 'delete';
        if (mode === 'off') return;

        const sender = m.key.participant || m.key.remoteJid;

        // Guard: never act on bot's own messages even if fromMe is wrong (LID issue)
        const botPhone = (sock.user?.id || '').split('@')[0].split(':')[0].replace(/\D/g, '');
        const senderPhone = (sender || '').split('@')[0].split(':')[0].replace(/\D/g, '');
        if (botPhone && senderPhone && botPhone === senderPhone) return;

        // Guard: rate limit per sender per group to prevent loops
        if (isRateLimited(chatId, sender)) return;

        // Check if this IS a proper groupStatusMentionMessage (must be the PRIMARY msg type)
        const allKeys = Object.keys(m.message || {})
            .filter(k => k !== 'messageContextInfo' && k !== 'senderKeyDistributionMessage');
        const primaryType = allKeys[0];
        const isGroupStatusMention = primaryType === 'groupStatusMentionMessage';
        
        if (!isGroupStatusMention) {
            // Fallback: forwarded message that contains the group invite link or ID
            const ctxInfo = m.message?.extendedTextMessage?.contextInfo ||
                            m.message?.imageMessage?.contextInfo ||
                            m.message?.videoMessage?.contextInfo;
            const isForwarded = ctxInfo?.isForwarded;
            const forwardingScore = ctxInfo?.forwardingScore || 0;
            
            if (!isForwarded && forwardingScore === 0) return;
            
            const text = m.message?.extendedTextMessage?.text ||
                         m.message?.conversation || '';
            const groupIdPart = chatId.split('@')[0];
            if (!text.includes(groupIdPart)) return;
        }

        const botName = getBotName();
        
        const adminStatus = await isAdmin(sock, chatId, sender);
        const isSenderAdmin = adminStatus.isSenderAdmin;
        const isBotAdmin = adminStatus.isBotAdmin;

        if (isSenderAdmin || db.isSudo(sender)) {
            return;
        }

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName}* ─┐\n│\n│ Cannot delete - need admin!\n│\n└─────────────┘`,
            });
            return;
        }

        const userTag = `@${sender.split('@')[0]}`;

        if (mode === 'warn') {
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName}* ─┐\n│\n│ ⚠️ ${userTag}\n│ Warning: Do not tag\n│ this group in status!\n│\n└─────────────┘`,
                mentions: [sender],
            });
            return;
        }

        try {
            await sock.sendMessage(chatId, { delete: m.key });
        } catch { return; }

        if (mode === 'kick' || mode === 'remove') {
            try {
                await sock.groupParticipantsUpdate(chatId, [sender], 'remove');
                await sock.sendMessage(chatId, {
                    text: `┌─ *${botName}* ─┐\n│\n│ ${userTag}\n│ Kicked for group mention!\n│\n└─────────────┘`,
                    mentions: [sender],
                });
            } catch {
                await sock.sendMessage(chatId, {
                    text: `┌─ *${botName}* ─┐\n│\n│ ${userTag}\n│ Message deleted.\n│ (Could not kick)\n│\n└─────────────┘`,
                    mentions: [sender],
                });
            }
        } else {
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName}* ─┐\n│\n│ ${userTag}\n│ Message deleted!\n│ Don't tag this group\n│\n└─────────────┘`,
                mentions: [sender],
            });
        }
    } catch (err) {
        console.error('Error in handleAntiStatusMention:', err.message, 'Line:', err.stack?.split('\n')[1]);
    }
}

async function antigroupmentionCommand(sock, chatId, message, senderId, fullArgs) {
    try {
        const fake = createFakeContact(message);
        const botName = getBotName();
        const prefix = getPrefix();

        const subCmd = (fullArgs || '').trim().split(/\s+/)[0]?.toLowerCase() || '';

        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName}* ─┐\n│\n│ Group command only!\n│\n└─────────────┘`
            }, { quoted: fake });
            return;
        }

        const adminStatus = await isAdmin(sock, chatId, senderId);
        const isSenderAdmin = adminStatus.isSenderAdmin;
        const isBotAdmin = adminStatus.isBotAdmin;

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName}* ─┐\n│\n│ Bot needs to be admin!\n│\n└─────────────┘`
            }, { quoted: fake });
            return;
        }

        if (!subCmd || subCmd === 'help') {
            const config = getGroupConfig(chatId, 'antigroupmention') || { enabled: false };
            const { sendAntiStatus } = require('../../davelib/antiStatusButtons');
            const currentMode = config.enabled ? (config.action || 'delete') : 'off';
            await sendAntiStatus(sock, chatId, message, {
                label: 'ANTI-GROUP MENTION',
                configKey: 'antigroupmention',
                currentMode,
                prefix,
                modes: [
                    { label: 'Off', value: 'off' },
                    { label: 'Delete', value: 'delete' },
                    { label: 'Warn', value: 'warn' },
                    { label: 'Kick', value: 'kick' }
                ]
            });
            return;
        }

        if (subCmd === 'status') {
            const config = getGroupConfig(chatId, 'antigroupmention') || { enabled: false };
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName}* ─┐
│
│ Anti-Group Mention:
│ ${config.enabled ? 'ACTIVE' : 'INACTIVE'}
│ ${config.enabled ? 'Mode: ' + (config.action || 'delete').toUpperCase() : ''}
│
└─────────────┘`
            }, { quoted: fake });
            return;
        }

        if (!isSenderAdmin && !message.key.fromMe && !db.isSudo(senderId)) {
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName}* ─┐\n│\n│ Admin only command!\n│\n└─────────────┘`
            }, { quoted: fake });
            return;
        }

        const validActions = ['on', 'off', 'delete', 'warn', 'kick', 'remove'];
        if (!validActions.includes(subCmd)) {
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName}* ─┐
│
│ Invalid option!
│ Use: on, off, delete, kick
│
└─────────────┘`
            }, { quoted: fake });
            return;
        }

        if (subCmd === 'off') {
            deleteGroupToggle(chatId, 'antigroupmention');
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName} ANTI-GROUP MENTION* ─┐\n│\n│ Status: DISABLED\n│\n└─────────────────────┘`
            }, { quoted: fake });
        } else {
            const action = subCmd === 'on' ? 'delete' : subCmd;
            setGroupConfig(chatId, 'antigroupmention', { enabled: true, action: action });
            await sock.sendMessage(chatId, {
                text: `┌─ *${botName} ANTI-GROUP MENTION* ─┐\n│\n│ Status: ENABLED\n│ Mode: ${action.toUpperCase()}\n│\n└─────────────────────┘`
            }, { quoted: fake });
        }
    } catch (error) {
        console.error('Error in antigroupmentionCommand:', error.message, 'Line:', error.stack?.split('\n')[1]);
    }
}

module.exports = {
    handleAntiStatusMention,
    antigroupmentionCommand
};