const { getGroupConfig, setGroupConfig, parseToggleCommand, parseActionCommand } = require('../../Database/settingsStore');
const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { shouldWarn } = require('../../davelib/antiWarnCooldown');
const { resolvePhoneFromLid, isLidJid } = require('../../davelib/lidResolver');

const DEFAULT_BAD_WORDS = [
    'gandu', 'madarchod', 'bhosdike', 'bsdk', 'fucker', 'bhosda', 
    'lauda', 'laude', 'betichod', 'chutiya', 'behenchod', 
    'randi', 'chuchi', 'boobs', 'idiot', 'nigga', 'fuck', 
    'dick', 'bitch', 'bastard', 'asshole', 'lund', 'mc', 'lodu',
    'shit', 'damn', 'piss', 'crap', 'slut', 'whore', 'prick',
    'motherfucker', 'cock', 'cunt', 'pussy', 'twat', 'wanker',
    'chut', 'harami', 'kameena', 'haramzada'
];

async function handleAntiBadwordCommand(sock, chatId, message, match) {
    const senderId = message.key.participant || message.key.remoteJid;
    const botName = getBotName();
    
    try {
        const groupMetadata = await sock.groupMetadata(chatId);
        const senderNum = senderId.split('@')[0].split(':')[0];
        const participant = groupMetadata.participants.find(p => {
            if (p.id === senderId) return true;
            if (p.lid && p.lid.split('@')[0].split(':')[0] === senderNum) return true;
            return p.id.split('@')[0].split(':')[0] === senderNum;
        });
        if (!participant?.admin && !message.key.fromMe && !db.isSudo(senderId)) {
            const fake = createFakeContact(senderId);
            return sock.sendMessage(chatId, { 
                text: `*${botName}*\nAdmin only command!` 
            }, { quoted: fake });
        }
    } catch {}

    const fake = createFakeContact(senderId);
    const config = getGroupConfig(chatId, 'antibadword');

    if (!match) {
        const { sendAntiStatus } = require('../../davelib/antiStatusButtons');
        const currentMode = config.enabled ? (config.action || 'delete') : 'off';
        const msgText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
        const prefix = msgText.trim().charAt(0) || '.';
        await sendAntiStatus(sock, chatId, message, {
            label: 'ANTI-BADWORD',
            configKey: 'antibadword',
            currentMode,
            prefix,
            modes: [
                { label: 'Off', value: 'off' },
                { label: 'Delete', value: 'delete' },
                { label: 'Warn', value: 'warn' },
                { label: 'Kick', value: 'kick' }
            ],
            extraInfo: `Words: ${config.words?.length || 0} custom | Warnings: ${config.maxWarnings || 3}`
        });
        return;
    }

    let newConfig = { ...config };
    let responseText = '';
    const sub = match.toLowerCase().trim();

    if (sub === 'status') {
        responseText = `*${botName} ANTIBADWORD STATUS*\n\n` +
                      `Status: ${config.enabled ? 'ACTIVE' : 'INACTIVE'}\n` +
                      `Action: ${config.action || 'delete'}\n` +
                      `Max Warnings: ${config.maxWarnings || 3}\n` +
                      `Custom Words: ${config.words?.length || 0}`;
        await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
        return;
    }

    if (sub === 'list') {
        const customWords = Array.isArray(config.words) ? config.words : [];
        const allWords = [...new Set([...DEFAULT_BAD_WORDS, ...customWords])];
        let listText = `*${botName} BADWORD LIST*\n\n`;
        listText += `Default words: ${DEFAULT_BAD_WORDS.length}\n`;
        listText += `Custom words: ${customWords.length}\n`;
        listText += `Total detected: ${allWords.length}\n\n`;
        if (customWords.length > 0) {
            listText += `*Custom words:*\n${customWords.join(', ')}\n\n`;
        }
        listText += `*Default words:*\n${DEFAULT_BAD_WORDS.slice(0, 30).join(', ')}`;
        if (DEFAULT_BAD_WORDS.length > 30) listText += `\n...and ${DEFAULT_BAD_WORDS.length - 30} more`;
        responseText = listText;
        await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
        return;
    }

    if (sub.startsWith('add ')) {
        const rawInput = sub.slice(4).trim();
        const wordsToAdd = rawInput.split(/[,\s]+/).map(w => w.trim().toLowerCase()).filter(w => w.length > 1);
        if (wordsToAdd.length > 0) {
            const currentWords = Array.isArray(config.words) ? [...config.words] : [];
            const addedWords = [];
            for (const word of wordsToAdd) {
                if (!currentWords.includes(word)) {
                    currentWords.push(word);
                    addedWords.push(word);
                }
            }
            newConfig.words = currentWords;
            // Auto-enable when words are added so it works immediately
            if (!newConfig.enabled) newConfig.enabled = true;
            setGroupConfig(chatId, 'antibadword', newConfig);
            if (addedWords.length > 0) {
                responseText = `*${botName}*\n✅ Added ${addedWords.length} word(s): ${addedWords.join(', ')}\nTotal custom words: ${currentWords.length}\nAntibadword is now ACTIVE.`;
            } else {
                responseText = `*${botName}*\nAll those words are already in the list!\nCurrent list: ${currentWords.length} custom word(s)`;
            }
        } else {
            responseText = `*${botName}*\nProvide words to add! Example: .antibadword add badword1,badword2`;
        }
        await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
        return;
    }

    if (sub.startsWith('remove ')) {
        const wordToRemove = sub.slice(7).trim().toLowerCase();
        const currentWords = Array.isArray(config.words) ? [...config.words] : [];
        const index = currentWords.indexOf(wordToRemove);
        if (index > -1) {
            currentWords.splice(index, 1);
            newConfig.words = currentWords;
            setGroupConfig(chatId, 'antibadword', newConfig);
            responseText = `*${botName}*\n✅ Removed: ${wordToRemove}\nRemaining custom words: ${currentWords.length}`;
        } else {
            responseText = `*${botName}*\n❌ "${wordToRemove}" not found in custom word list!\nUse .antibadword list to see all words`;
        }
        await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
        return;
    }

    if (sub.startsWith('setwarn ')) {
        const num = parseInt(sub.replace('setwarn ', '').trim());
        if (num > 0 && num <= 10) {
            newConfig.maxWarnings = num;
            setGroupConfig(chatId, 'antibadword', newConfig);
            responseText = `*${botName}*\nMax warnings set to: ${num}`;
        } else {
            responseText = `*${botName}*\nInvalid number! Use 1-10`;
        }
        await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
        return;
    }

    if (sub === 'reset') {
        newConfig.words = [...DEFAULT_BAD_WORDS];
        setGroupConfig(chatId, 'antibadword', newConfig);
        responseText = `*${botName}*\nReset to default ${DEFAULT_BAD_WORDS.length} words`;
        await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
        return;
    }

    const toggle = parseToggleCommand(sub);
    if (toggle === 'on') {
        newConfig.enabled = true;
        responseText = `*${botName}*\nAntiBadword ENABLED\nAction: ${newConfig.action || 'delete'}`;
    } else if (toggle === 'off') {
        newConfig.enabled = false;
        responseText = `*${botName}*\nAntiBadword DISABLED`;
    } else {
        const action = parseActionCommand(sub);
        if (action === 'delete') {
            newConfig.action = 'delete';
            newConfig.enabled = true;
            responseText = `*${botName}*\nAction: DELETE\nBad word messages will be deleted.`;
        } else if (action === 'kick') {
            newConfig.action = 'kick';
            newConfig.enabled = true;
            responseText = `*${botName}*\nAction: KICK\nUsers will be removed for bad words.`;
        } else if (action === 'warn') {
            newConfig.action = 'warn';
            newConfig.enabled = true;
            responseText = `*${botName}*\nAction: WARN\nUsers get ${newConfig.maxWarnings || 3} warnings before kick.`;
        } else {
            responseText = `*${botName}*\nInvalid command!\nUse: on, off, delete, kick, warn, add, remove, list`;
        }
    }

    if (responseText && !responseText.includes('Invalid')) {
        setGroupConfig(chatId, 'antibadword', newConfig);
    }

    await sock.sendMessage(chatId, { text: responseText }, { quoted: fake });
}

function normalizeJid(jid) {
    if (!jid) return '';
    const num = jid.split('@')[0].split(':')[0];
    return num + '@s.whatsapp.net';
}

async function handleBadwordDetection(sock, chatId, message, userMessage, senderId) {
    try {
        if (!chatId.endsWith('@g.us')) return;
        if (message.key.fromMe) return;
        
        const config = getGroupConfig(chatId, 'antibadword');
        if (!config?.enabled) return;

        const groupMetadata = await sock.groupMetadata(chatId);
        const botId = normalizeJid(sock.user.id);
        const normalizedSender = normalizeJid(senderId);
        const senderRawNum = senderId.split('@')[0].split(':')[0];
        const bot = groupMetadata.participants.find(p => normalizeJid(p.id) === botId);
        const botIsAdmin = !!bot?.admin;

        const participant = groupMetadata.participants.find(p => {
            if (normalizeJid(p.id) === normalizedSender) return true;
            if (p.lid && p.lid.split('@')[0].split(':')[0] === senderRawNum) return true;
            return p.id.split('@')[0].split(':')[0] === senderRawNum;
        });
        if (participant?.admin) return;
        if (db.isSudo(senderId) || db.isSudo(normalizedSender)) return;

        const cleanMessage = userMessage.toLowerCase()
            .replace(/[^\w\s]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();

        // Always include both custom words AND defaults for detection
        const customWords = Array.isArray(config.words) ? config.words : [];
        const badWords = [...new Set([...DEFAULT_BAD_WORDS, ...customWords])];
        const messageWords = cleanMessage.split(' ').filter(Boolean);
        let containsBadWord = false;
        let detectedWord = '';

        // Exact word match
        for (const word of messageWords) {
            if (word.length < 2) continue;
            if (badWords.includes(word)) {
                containsBadWord = true;
                detectedWord = word;
                break;
            }
        }

        // Sub-word match: catch variations like "fucking"→"fuck", "bullshitter"→"shit"
        if (!containsBadWord) {
            for (const word of messageWords) {
                if (word.length < 3) continue;
                for (const badWord of badWords) {
                    if (badWord.length >= 3 && word.includes(badWord)) {
                        containsBadWord = true;
                        detectedWord = badWord;
                        break;
                    }
                }
                if (containsBadWord) break;
            }
        }

        // Multi-word phrase match
        if (!containsBadWord) {
            for (const badWord of badWords) {
                if (badWord.includes(' ') && cleanMessage.includes(badWord)) {
                    containsBadWord = true;
                    detectedWord = badWord;
                    break;
                }
            }
        }

        if (!containsBadWord) return;

        const botName = getBotName();
        const fake = createFakeContact(senderId);
        const action = config.action || 'delete';
        const rawNum = senderId.split('@')[0].split(':')[0];
        const senderNumber = isLidJid(senderId)
            ? (resolvePhoneFromLid(senderId, sock) || rawNum)
            : rawNum;
        const maxWarnings = config.maxWarnings || 3;

        // Try to delete the message — only possible if bot is admin
        if (botIsAdmin) {
            try {
                await sock.sendMessage(chatId, { delete: message.key });
            } catch {}
        }

        switch (action) {
            case 'delete':
                if (shouldWarn(chatId, senderId, 'badword')) {
                    await sock.sendMessage(chatId, {
                        text: `*${botName}*\n@${senderNumber}, bad words are not allowed!\n${botIsAdmin ? 'Message deleted.' : '⚠️ Make me admin to delete messages.'}`,
                        mentions: [senderId]
                    }, { quoted: fake });
                }
                break;

            case 'kick':
                if (botIsAdmin) {
                    try {
                        await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
                        if (shouldWarn(chatId, senderId, 'badword')) {
                            await sock.sendMessage(chatId, {
                                text: `*${botName}*\n@${senderNumber} removed for using bad words!`,
                                mentions: [senderId]
                            }, { quoted: fake });
                        }
                    } catch {
                        if (shouldWarn(chatId, senderId, 'badword')) {
                            await sock.sendMessage(chatId, {
                                text: `*${botName}*\n@${senderNumber}, bad words not allowed! (Could not remove — check my permissions)`,
                                mentions: [senderId]
                            }, { quoted: fake });
                        }
                    }
                } else {
                    if (shouldWarn(chatId, senderId, 'badword')) {
                        await sock.sendMessage(chatId, {
                            text: `*${botName}*\n@${senderNumber}, bad words not allowed!\n⚠️ Make me admin to remove violators.`,
                            mentions: [senderId]
                        }, { quoted: fake });
                    }
                }
                break;

            case 'warn': {
                const warningCount = db.incrementWarning(chatId, senderId);
                if (warningCount >= maxWarnings && botIsAdmin) {
                    try {
                        await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
                        db.resetWarning(chatId, senderId);
                        await sock.sendMessage(chatId, {
                            text: `*${botName}*\n@${senderNumber} removed after ${maxWarnings} warnings for bad words!`,
                            mentions: [senderId]
                        }, { quoted: fake });
                    } catch {
                        await sock.sendMessage(chatId, {
                            text: `*${botName}*\n@${senderNumber} reached max warnings (${maxWarnings})! Bad words not allowed.`,
                            mentions: [senderId]
                        }, { quoted: fake });
                    }
                } else {
                    await sock.sendMessage(chatId, {
                        text: `*${botName}*\n@${senderNumber} warning ${warningCount}/${maxWarnings} — bad words not allowed!`,
                        mentions: [senderId]
                    }, { quoted: fake });
                }
                break;
            }
        }
    } catch (err) {
        console.error('Error in handleBadwordDetection:', err.message, 'Line:', err.stack?.split('\n')[1]);
    }
}

async function antibadwordCommand(sock, chatId, message, args) {
    try {
        await handleAntiBadwordCommand(sock, chatId, message, args || '');
    } catch (error) {
        console.error('Error in antibadword command:', error.message, 'Line:', error.stack?.split('\n')[1]);
        const botName = getBotName();
        await sock.sendMessage(chatId, { text: `*${botName}*\nError processing command!` });
    }
}

module.exports = {
    handleAntiBadwordCommand,
    handleBadwordDetection,
    antibadwordCommand
};
