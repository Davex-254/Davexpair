const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function teraboxCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();

    const text = message.message?.conversation ||
                 message.message?.extendedTextMessage?.text || '';
    const query = text.split(' ').slice(1).join(' ').trim();

    if (!query) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nUsage: .terabox <link>\nExample: .terabox https://terabox.com/s/xxxxxx`
        }, { quoted: fake });
    }

    if (!query.includes('terabox.com') && !query.includes('1024tera.com') && !query.includes('4funbox.com')) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nThat doesn't look like a Terabox link.`
        }, { quoted: fake });
    }

    try {
        const axios = require('axios');
        const apiUrl = `https://terabox-dl.qtcloud.workers.dev/api?link=${encodeURIComponent(query)}`;
        const res = await axios.get(apiUrl, { timeout: 20000 });
        const data = res.data;

        if (!data || !data.downloadLink) {
            return sock.sendMessage(chatId, {
                text: `*${botName}*\nCould not fetch download link. The file may be private or the link is invalid.`
            }, { quoted: fake });
        }

        await sock.sendMessage(chatId, {
            text: `*${botName} Terabox*\n\n📁 File: ${data.filename || 'Unknown'}\n📦 Size: ${data.size || 'Unknown'}\n\n🔗 Download Link:\n${data.downloadLink}`
        }, { quoted: fake });

    } catch (error) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\nFailed to process Terabox link: ${error.message}`
        }, { quoted: fake });
    }
}

module.exports = teraboxCommand;
