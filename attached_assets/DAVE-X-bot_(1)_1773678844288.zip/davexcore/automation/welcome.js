const { handleWelcome } = require('../../davelib/welcome');
const { isWelcomeOn, getWelcome } = require('../../davelib/index');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { resolvePhoneFromLid, resolveSenderFromGroup, isLidJid, cacheLidPhone } = require('../../davelib/lidResolver');
const store = require('../../davelib/lightweight_store');

// Resolve a display name for a participant JID
async function resolveName(sock, participantJid, groupParticipants = null) {
    if (!participantJid) return 'Member';

    // 1. Try push name from the contact store (correct source — sock.contacts doesn't exist in Baileys v7)
    try {
        const contactInfo = store.contacts?.[participantJid];
        if (contactInfo?.name) return contactInfo.name;
        if (contactInfo?.notify) return contactInfo.notify;
    } catch {}

    const raw = participantJid.split('@')[0].split(':')[0];

    // 2. If not a LID, return phone number directly
    if (!isLidJid(participantJid)) {
        return /^\d{7,15}$/.test(raw) ? raw : 'Member';
    }

    // 3. Try fast LID→phone resolution
    const fast = resolvePhoneFromLid(participantJid, sock);
    if (fast) return fast;

    // 4. Scan group participants for LID match
    if (groupParticipants) {
        for (const p of groupParticipants) {
            const pid  = (p.id  || '').split('@')[0].split(':')[0];
            const pLid = (p.lid || '').split('@')[0].split(':')[0];
            if ((pLid === raw || pid === raw) && pid && !pid.includes('lid') && /^\d{7,15}$/.test(pid)) {
                cacheLidPhone(raw, pid);
                // Also check push name on the resolved participant
                try {
                    const resolved = pid + '@s.whatsapp.net';
                    const c = store.contacts?.[resolved];
                    if (c?.name) return c.name;
                    if (c?.notify) return c.notify;
                } catch {}
                return pid;
            }
        }
    }

    // 5. Async group metadata fallback
    const fromGroup = await resolveSenderFromGroup(participantJid, null, sock).catch(() => null);
    if (fromGroup && /^\d{7,15}$/.test(fromGroup)) return fromGroup;

    return 'Member';
}

async function welcomeCommand(sock, chatId, message, fullArgs) {
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);

    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, {
            text: `┌─ *WELCOME* ─┐\n│\n│ Group command only!\n│\n└─────────────┘`
        }, { quoted: fake });
        return;
    }

    await handleWelcome(sock, chatId, message, fullArgs || '');
}

// Deduplication guard
const recentlyWelcomed = new Map();

async function handleJoinEvent(sock, id, participants) {
    try {
        const isWelcomeEnabled = await isWelcomeOn(id);
        if (!isWelcomeEnabled) return;

        const customMessage = await getWelcome(id);
        const groupMetadata = await sock.groupMetadata(id);
        const groupName = groupMetadata.subject;
        const groupDesc = groupMetadata.desc || 'No description';
        const memberCount = groupMetadata.participants.length;
        const botName = getBotName();

        let ppgroup;
        try {
            ppgroup = await sock.profilePictureUrl(id, 'image');
        } catch {
            ppgroup = 'https://i.ibb.co/Z2Fyf4t/default-avatar.png';
        }

        const now = Date.now();
        for (const [key, ts] of recentlyWelcomed.entries()) {
            if (now - ts > 60000) recentlyWelcomed.delete(key);
        }

        for (const participant of participants) {
            try {
                const participantJid = typeof participant === 'string'
                    ? participant
                    : (participant.id || participant.toString());

                // Dedup
                const dedupKey = `${id}:${participantJid}`;
                if (recentlyWelcomed.has(dedupKey)) continue;
                recentlyWelcomed.set(dedupKey, Date.now());

                const displayName = await resolveName(sock, participantJid, groupMetadata.participants);

                // Determine the right JID and number for @mention in text
                // The @number in text must match the mentionedJid phone to avoid double-@
                const rawPart = participantJid.split('@')[0].split(':')[0];
                let mentionJid;
                let mentionNum;
                if (/^\d{7,15}$/.test(rawPart)) {
                    // Regular phone JID — use as-is
                    mentionNum = rawPart;
                    mentionJid = participantJid;
                } else if (/^\d{7,15}$/.test(displayName)) {
                    // LID JID but we resolved a phone — prefer phone JID for mention
                    mentionNum = displayName;
                    mentionJid = displayName + '@s.whatsapp.net';
                } else {
                    // Unresolved LID — fallback
                    mentionNum = rawPart;
                    mentionJid = participantJid;
                }

                // Profile picture - try with mention JID first
                let avatarUrl;
                try {
                    avatarUrl = await sock.profilePictureUrl(mentionJid, 'image');
                } catch {
                    try {
                        if (mentionJid !== participantJid) {
                            avatarUrl = await sock.profilePictureUrl(participantJid, 'image');
                        }
                    } catch {}
                    if (!avatarUrl) avatarUrl = ppgroup;
                }

                let welcomeText;
                if (customMessage) {
                    welcomeText = customMessage
                        .replace(/@\{user\}/g, `@${mentionNum}`)
                        .replace(/\{user\}/g, `@${mentionNum}`)
                        .replace(/{group}/g, groupName)
                        .replace(/{description}/g, groupDesc)
                        .replace(/{bot}/g, botName)
                        .replace(/{members}/g, String(memberCount));
                } else {
                    welcomeText = `┌─ *WELCOME* ─┐
│
│ @${mentionNum}
│ Welcome to *${groupName}*!
│
│ Members: ${memberCount}
│ Enjoy your stay! 🎉
│
└─────────────┘`;
                }

                await sock.sendMessage(id, {
                    text: welcomeText,
                    contextInfo: {
                        mentionedJid: [mentionJid],
                        externalAdReply: {
                            title: `Welcome, ${displayName}!`,
                            body: botName,
                            thumbnailUrl: avatarUrl || ppgroup,
                            sourceUrl: 'https://whatsapp.com/channel/0029VbApvFQ2Jl84lhONkc3k',
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                });

            } catch (error) {
                const participantJid = typeof participant === 'string'
                    ? participant
                    : (participant.id || participant.toString());
                await sock.sendMessage(id, {
                    text: `┌─ *WELCOME* ─┐\n│\n│ @${participantJid.split('@')[0].split(':')[0]}\n│ Welcome to the group!\n│\n└─────────────┘`,
                    mentions: [participantJid]
                }).catch(() => {});
            }
        }
    } catch (err) {
        console.error('handleJoinEvent error:', err.message);
    }
}

module.exports = { welcomeCommand, handleJoinEvent };
