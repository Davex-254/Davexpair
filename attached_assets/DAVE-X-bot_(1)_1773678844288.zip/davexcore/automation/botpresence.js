const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

/**
 * Bot Presence Commands
 *
 * sendPresenceUpdate(type, toJid):
 *   - 'available' / 'unavailable'  → global (no toJid). Bot appears online/offline to everyone.
 *     Does NOT disconnect WebSocket or stop message processing — purely cosmetic.
 *   - 'composing' / 'recording' / 'paused' → chat-specific (toJid required).
 *     Works for both PM (toJid = sender's JID) and groups (toJid = group JID).
 *
 * WAPresence types: 'unavailable' | 'available' | 'composing' | 'recording' | 'paused'
 */

async function setBotOnlineCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    try {
        await sock.sendPresenceUpdate('available');
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}*\n\n✅ Bot presence set to *Online*\n\n_Other WhatsApp users will now see the bot as online._`
        }, { quoted: fake });
    } catch (err) {
        console.error('[botpresence] setBotOnline error:', err);
        await sock.sendMessage(chatId, { text: `❌ Failed to set online: ${err.message}` }, { quoted: fake });
    }
}

async function setBotOfflineCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    try {
        await sock.sendPresenceUpdate('unavailable');
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}*\n\n🔕 Bot presence set to *Offline*\n\n_Other WhatsApp users will no longer see the bot as online.\nThe bot still processes all messages normally._`
        }, { quoted: fake });
    } catch (err) {
        console.error('[botpresence] setBotOffline error:', err);
        await sock.sendMessage(chatId, { text: `❌ Failed to set offline: ${err.message}` }, { quoted: fake });
    }
}

/**
 * Simulate typing (composing) in the current chat.
 * Works in both PM and group chats — toJid is always chatId.
 * Duration: 1–60 seconds (default 5).
 */
async function setTypingCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    try {
        let secs = parseInt(args[0]) || 5;
        if (secs < 1) secs = 1;
        if (secs > 60) secs = 60;

        await sock.sendPresenceUpdate('composing', chatId);
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}*\n\n✍️ Simulating typing for *${secs}s* in this chat...`
        }, { quoted: fake });

        setTimeout(async () => {
            try { await sock.sendPresenceUpdate('paused', chatId); } catch {}
        }, secs * 1000);
    } catch (err) {
        console.error('[botpresence] typing error:', err);
        await sock.sendMessage(chatId, { text: `❌ Failed: ${err.message}` }, { quoted: fake });
    }
}

/**
 * Simulate recording audio in the current chat.
 * Works in both PM and group chats — toJid is always chatId.
 * Duration: 1–60 seconds (default 5).
 */
async function setRecordingCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    try {
        let secs = parseInt(args[0]) || 5;
        if (secs < 1) secs = 1;
        if (secs > 60) secs = 60;

        await sock.sendPresenceUpdate('recording', chatId);
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}*\n\n🎙️ Simulating voice recording for *${secs}s* in this chat...`
        }, { quoted: fake });

        setTimeout(async () => {
            try { await sock.sendPresenceUpdate('paused', chatId); } catch {}
        }, secs * 1000);
    } catch (err) {
        console.error('[botpresence] recording error:', err);
        await sock.sendMessage(chatId, { text: `❌ Failed: ${err.message}` }, { quoted: fake });
    }
}

/**
 * Immediately stop typing/recording indicator in this chat.
 */
async function stopPresenceCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    try {
        await sock.sendPresenceUpdate('paused', chatId);
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}*\n\n⏹ Typing/recording indicator cleared.`
        }, { quoted: fake });
    } catch (err) {
        console.error('[botpresence] stop error:', err);
        await sock.sendMessage(chatId, { text: `❌ Failed: ${err.message}` }, { quoted: fake });
    }
}

module.exports = {
    setBotOnlineCommand,
    setBotOfflineCommand,
    setTypingCommand,
    setRecordingCommand,
    stopPresenceCommand,
};
