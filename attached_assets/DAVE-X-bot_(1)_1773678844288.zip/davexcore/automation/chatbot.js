const path = require('path');
const fetch = require('node-fetch');
const { loadUserGroupData, saveUserGroupData } = require('../../davelib/index');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

const chatMemory = {
    messages: new Map(),
    userInfo: new Map()
};

function getRandomDelay() {
    return Math.floor(Math.random() * 3000) + 2000;
}

async function showTyping(sock, chatId) {
    try {
        await sock.presenceSubscribe(chatId);
        await sock.sendPresenceUpdate('composing', chatId);
        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));
    } catch (error) {}
}

async function handleChatbotCommand(sock, chatId, message, match) {
    if (!match) {
        await showTyping(sock, chatId);
        return sock.sendMessage(chatId, {
            text: `┌─ *CHATBOT* ─┐
│
│ Commands:
│ .chatbot on
│ .chatbot off
│
│ Enable/disable chatbot in group
│
└─────────────┘`,
            quoted: message
        });
    }

    const data = loadUserGroupData();
    
    const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    
    const senderId = message.key.participant || message.participant || message.pushName || message.key.remoteJid;
    const isOwner = senderId === botNumber || message.key.fromMe;

    if (isOwner) {
        if (match === 'on') {
            await showTyping(sock, chatId);
            if (data.chatbot[chatId]) {
                return sock.sendMessage(chatId, { 
                    text: `┌─ *CHATBOT* ─┐
│
│ Already enabled
│
└─────────────┘`,
                    quoted: message
                });
            }
            data.chatbot[chatId] = true;
            saveUserGroupData(data);
            return sock.sendMessage(chatId, { 
                text: `┌─ *CHATBOT* ─┐
│
│ Chatbot ENABLED
│
└─────────────┘`,
                quoted: message
            });
        }

        if (match === 'off') {
            await showTyping(sock, chatId);
            if (!data.chatbot[chatId]) {
                return sock.sendMessage(chatId, { 
                    text: `┌─ *CHATBOT* ─┐
│
│ Already disabled
│
└─────────────┘`,
                    quoted: message
                });
            }
            data.chatbot[chatId] = false;
            saveUserGroupData(data);
            const { setGroupConfig } = require('../../Database/settingsStore');
            setGroupConfig(chatId, 'chatbot', false);
            return sock.sendMessage(chatId, { 
                text: `┌─ *CHATBOT* ─┐
│
│ Chatbot DISABLED
│
└─────────────┘`,
                quoted: message
            });
        }
    }

    let isAdmin = false;
    if (chatId.endsWith('@g.us')) {
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            isAdmin = groupMetadata.participants.some(p => p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin'));
        } catch (e) {}
    }

    if (!isAdmin && !isOwner) {
        await showTyping(sock, chatId);
        return sock.sendMessage(chatId, {
            text: `┌─ *CHATBOT* ─┐
│
│ Admins only command
│
└─────────────┘`,
            quoted: message
        });
    }

    if (match === 'on') {
        await showTyping(sock, chatId);
        if (data.chatbot[chatId]) {
            return sock.sendMessage(chatId, { 
                text: `┌─ *CHATBOT* ─┐
│
│ Already enabled
│
└─────────────┘`,
                quoted: message
            });
        }
        data.chatbot[chatId] = true;
        saveUserGroupData(data);
        return sock.sendMessage(chatId, { 
            text: `┌─ *CHATBOT* ─┐
│
│ Chatbot ENABLED
│
└─────────────┘`,
            quoted: message
        });
    }

    if (match === 'off') {
        await showTyping(sock, chatId);
        if (!data.chatbot[chatId]) {
            return sock.sendMessage(chatId, { 
                text: `┌─ *CHATBOT* ─┐
│
│ Already disabled
│
└─────────────┘`,
                quoted: message
            });
        }
        data.chatbot[chatId] = false;
        saveUserGroupData(data);
        const { setGroupConfig } = require('../../Database/settingsStore');
        setGroupConfig(chatId, 'chatbot', false);
        return sock.sendMessage(chatId, { 
            text: `┌─ *CHATBOT* ─┐
│
│ Chatbot DISABLED
│
└─────────────┘`,
            quoted: message
        });
    }

    await showTyping(sock, chatId);
    return sock.sendMessage(chatId, { 
        text: `┌─ *CHATBOT* ─┐
│
│ Invalid command
│ Use: .chatbot on/off
│
└─────────────┘`,
        quoted: message
    });
}

async function handleChatbotResponse(sock, chatId, message, userMessage, senderId) {
    try {
        const data = loadUserGroupData();
        if (!data.chatbot[chatId]) return;
    } catch (e) {
        return;
    }

    try {
        if (!sock?.user?.id) return;
        const botId = sock.user.id;
        const botNumber = botId.split(':')[0];
        const botLid = sock.user?.lid;
        const botJids = [
            botId,
            `${botNumber}@s.whatsapp.net`,
            `${botNumber}@whatsapp.net`,
            `${botNumber}@lid`
        ];
        if (botLid) {
            botJids.push(botLid);
            const lidNum = botLid.split(':')[0];
            if (lidNum) botJids.push(`${lidNum}@lid`);
        }

        const senderNum = (senderId || '').split('@')[0].split(':')[0];
        if (senderNum === botNumber) return;

        let isBotMentioned = false;
        let isReplyToBot = false;

        if (message.message?.extendedTextMessage) {
            const mentionedJid = message.message.extendedTextMessage.contextInfo?.mentionedJid || [];
            const quotedParticipant = message.message.extendedTextMessage.contextInfo?.participant;
            
            isBotMentioned = mentionedJid.some(jid => {
                const jidNumber = jid.split('@')[0].split(':')[0];
                return botJids.some(botJid => {
                    const botJidNumber = botJid.split('@')[0].split(':')[0];
                    return jidNumber === botJidNumber;
                });
            });
            
            if (quotedParticipant) {
                const cleanQuoted = quotedParticipant.replace(/[:@].*$/, '');
                isReplyToBot = botJids.some(botJid => {
                    const cleanBot = botJid.replace(/[:@].*$/, '');
                    return cleanBot === cleanQuoted;
                });
            }
        } else if (message.message?.conversation) {
            isBotMentioned = userMessage.includes(`@${botNumber}`);
        }

        if (!isBotMentioned && !isReplyToBot) return;

        let cleanedMessage = userMessage;
        if (isBotMentioned) {
            cleanedMessage = cleanedMessage.replace(new RegExp(`@${botNumber}`, 'g'), '').trim();
        }

        if (!cleanedMessage || cleanedMessage.trim().length === 0) return;

        if (!chatMemory.messages.has(senderId)) {
            chatMemory.messages.set(senderId, []);
            chatMemory.userInfo.set(senderId, {});
        }

        const messages = chatMemory.messages.get(senderId);
        messages.push(cleanedMessage);
        if (messages.length > 10) {
            messages.shift();
        }
        chatMemory.messages.set(senderId, messages);

        try {
            await showTyping(sock, chatId);
        } catch (e) {}

        let response;
        try {
            response = await getAIResponse(cleanedMessage, {
                messages: chatMemory.messages.get(senderId),
                userInfo: chatMemory.userInfo.get(senderId) || {}
            });
        } catch (aiErr) {
            console.error('AI response error:', aiErr.message);
            response = null;
        }

        if (!response || response.trim().length === 0) {
            response = getContextualFallback(cleanedMessage);
        }

        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));

        try {
            await sock.sendMessage(chatId, {
                text: response.substring(0, 1000)
            }, {
                quoted: message
            });
        } catch (sendErr) {
            try {
                await sock.sendMessage(chatId, {
                    text: response.substring(0, 1000)
                });
            } catch (e) {}
        }

    } catch (error) {
        console.error('Chatbot response error:', error.message);
    }
}

function getContextualFallback(message) {
    const lower = message.toLowerCase().trim();
    const words = lower.split(/\s+/);
    
    if (/^(hi|hello|hey|yo|sup|hola|heya)\b/i.test(lower)) {
        const greetings = [
            "Hey! What can I help you with?",
            "Hi there! Need something?",
            "Hello! How can I assist?",
            "Hey! What's up?"
        ];
        return greetings[Math.floor(Math.random() * greetings.length)];
    }
    
    if (/how are you|how r u|howdy|how do you do/i.test(lower)) {
        return "I'm good! What can I do for you?";
    }
    
    if (/bye|goodbye|see you|later|gtg|gotta go/i.test(lower)) {
        return "See you later!";
    }
    
    if (/thanks|thank you|thx|thanx|ty/i.test(lower)) {
        return "You're welcome!";
    }
    
    if (/who are you|what are you|your name/i.test(lower)) {
        return "I'm DAVE-X, your WhatsApp assistant. Ask me anything!";
    }
    
    if (/good morning|morning/i.test(lower)) {
        return "Good morning! How can I help?";
    }
    
    if (/good night|gn|goodnight/i.test(lower)) {
        return "Good night!";
    }

    if (/\?$/.test(lower) || /^(what|who|where|when|why|how|is|are|can|do|does|will|would|should)/i.test(lower)) {
        return "AI service unavailable. Try again later or use .gpt or .gemini";
    }

    const generic = [
        "Interesting. Tell me more.",
        "Got it. Need help with something?",
        "I see. Ask me a question."
    ];
    return generic[Math.floor(Math.random() * generic.length)];
}

async function getAIResponse(userMessage, userContext) {
    const recentMessages = userContext.messages.slice(-5).join('\n');
    const userInfo = userContext.userInfo || {};
    
    let userInfoStr = '';
    if (Object.keys(userInfo).length > 0) {
        userInfoStr = `User info: ${JSON.stringify(userInfo)}`;
    }

    const systemPrompt = `You are DAVE-X, a smart and friendly assistant chatting on WhatsApp. Created by Dave.

CORE RULES:
1. Always respond in clear English
2. Keep responses concise but helpful - 2-4 lines max
3. Be friendly, witty
4. Never mention you're an AI or bot - you're DAVE-X
5. Match the user's language
6. Be knowledgeable and give accurate, helpful answers
7. If someone greets you, greet them back warmly
8. Never repeat the same generic response

ABOUT YOU:
- Name: DAVE-X
- Creator: Dave
- You're intelligent, helpful, and have a good sense of humor

${userInfoStr}
Previous chat: ${recentMessages}`;

    const apis = [
        {
            name: 'BK9 Gemini',
            url: `https://bk9.fun/ai/gemini?q=${encodeURIComponent(userMessage)}&system=${encodeURIComponent(systemPrompt)}`,
            method: 'GET',
            parse: (data) => data?.BK9 || data?.result || data?.response || null
        },
        {
            name: 'GPT-5',
            url: `https://iamtkm.vercel.app/ai/gpt5?apikey=tkm&text=${encodeURIComponent(systemPrompt + '\n\nUser: ' + userMessage)}`,
            method: 'GET',
            parse: (data) => data?.result || data?.response || data?.message || data?.text || null
        },
        {
            name: 'Wolf Gemini',
            url: 'https://apis.xwolf.space/api/ai/gemini',
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: { prompt: systemPrompt + '\n\nUser: ' + userMessage, system: systemPrompt },
            parse: (data) => data?.result || data?.response || data?.message || data?.data?.result || data?.data?.response || data?.candidates?.[0]?.content || null
        }
    ];

    for (const api of apis) {
        try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 12000);

            let response;
            if (api.method === 'POST') {
                response = await fetch(api.url, {
                    method: 'POST',
                    headers: api.headers,
                    body: JSON.stringify(api.body),
                    signal: controller.signal
                });
            } else {
                response = await fetch(api.url, {
                    method: 'GET',
                    signal: controller.signal,
                    headers: { 'Accept': 'application/json' }
                });
            }
            
            clearTimeout(timeout);

            if (!response.ok) continue;

            const data = await response.json();
            let result = api.parse(data);
            
            if (result && typeof result === 'string' && result.trim().length > 5) {
                return result
                    .replace(/^["']|["']$/g, '')
                    .replace(/\\n/g, '\n')
                    .replace(/\\/g, '')
                    .trim();
            }
        } catch (error) {
            continue;
        }
    }

    return null;
}

module.exports = {
    handleChatbotCommand,
    handleChatbotResponse
};