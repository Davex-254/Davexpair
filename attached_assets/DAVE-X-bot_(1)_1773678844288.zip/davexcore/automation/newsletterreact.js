const fs = require('fs');
const path = require('path');
const { getOwnerConfig, setOwnerConfig } = require('../../Database/settingsStore');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { isSudo } = require('../../davelib/index');

const CHANNELS_FILE = path.join(process.cwd(), 'mychannels.json');
const EMOJIS = ['❤️', '💛', '👍', '💜', '😮', '🤍', '💙', '🔥', '🎉', '😂'];

function randomEmoji() {
    return EMOJIS[Math.floor(Math.random() * EMOJIS.length)];
}

function readConfig() {
    try {
        const cfg = getOwnerConfig('newsletterreact');
        return cfg && typeof cfg === 'object'
            ? { enabled: true, ...cfg }
            : { enabled: true };
    } catch { return { enabled: true }; }
}

function writeConfig(cfg) {
    try { setOwnerConfig('newsletterreact', cfg); return true; }
    catch { return false; }
}

function loadChannels() {
    try {
        if (!fs.existsSync(CHANNELS_FILE)) return [];
        const raw = fs.readFileSync(CHANNELS_FILE, 'utf8');
        const data = JSON.parse(raw);
        return Array.isArray(data) ? data : [];
    } catch { return []; }
}

function saveChannels(list) {
    try {
        fs.writeFileSync(CHANNELS_FILE, JSON.stringify(list, null, 2), 'utf8');
        return true;
    } catch { return false; }
}

// ── Dedup guard ───────────────────────────────────────────────────────────────
const _reactedIds = new Set();

// ── Core handler ──────────────────────────────────────────────────────────────
async function handleNewsletterMessage(sock, message) {
    try {
        const cfg = readConfig();
        if (!cfg.enabled) return;

        const remoteJid = message.key?.remoteJid;
        if (!remoteJid?.endsWith('@newsletter')) return;

        const channels = loadChannels();
        if (!channels.includes(remoteJid)) return;

        const serverId = message.key?.server_id;
        if (!serverId) return;

        const reactKey = `${remoteJid}:${serverId}`;
        if (_reactedIds.has(reactKey)) return;
        _reactedIds.add(reactKey);
        if (_reactedIds.size > 200) _reactedIds.clear();

        const emoji = randomEmoji();
        await sock.newsletterReactMessage(remoteJid, String(serverId), emoji);

    } catch {
        // Silent — newsletter react failures are non-critical
    }
}

// ── Command handler ───────────────────────────────────────────────────────────
async function newsletterreactCommand(sock, chatId, msg, args) {
    try {
        const fake     = createFakeContact(msg);
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner  = msg.key.fromMe || (await isSudo(senderId));
        const botName  = getBotName();

        if (!isOwner) {
            await sock.sendMessage(chatId, { text: `✦ Owner only command` }, { quoted: fake });
            return;
        }

        const cfg      = readConfig();
        const channels = loadChannels();
        const cmd      = (args[0] || '').toLowerCase();
        const val      = (args[1] || '').trim();

        if (!cmd) {
            await sock.sendMessage(chatId, {
                text:
                    `✦ *${botName}* | Newsletter React\n\n` +
                    `Status:   ${cfg.enabled ? '✅ ON' : '❌ OFF'}\n` +
                    `Channels: ${channels.length}\n\n` +
                    `*Commands:*\n` +
                    `› .newsletterreact on/off\n` +
                    `› .newsletterreact add <newsletter_jid>\n` +
                    `› .newsletterreact remove <newsletter_jid>\n` +
                    `› .newsletterreact list\n\n` +
                    `_Newsletter JID format: 123456789@newsletter_`
            }, { quoted: fake });
            return;
        }

        if (cmd === 'on') {
            cfg.enabled = true;
            writeConfig(cfg);
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Newsletter React ✅ ON` }, { quoted: fake });
        }
        else if (cmd === 'off') {
            cfg.enabled = false;
            writeConfig(cfg);
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Newsletter React ❌ OFF` }, { quoted: fake });
        }
        else if (cmd === 'add') {
            if (!val) {
                await sock.sendMessage(chatId, { text: `✦ Provide a newsletter JID.\nExample: .newsletterreact add 123456@newsletter` }, { quoted: fake });
                return;
            }
            const jid = val.includes('@newsletter') ? val : `${val}@newsletter`;
            if (channels.includes(jid)) {
                await sock.sendMessage(chatId, { text: `✦ *${botName}* | Already in list: ${jid}` }, { quoted: fake });
                return;
            }
            channels.push(jid);
            saveChannels(channels);
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Added: ${jid}\nTotal: ${channels.length} channels` }, { quoted: fake });
        }
        else if (cmd === 'remove') {
            if (!val) {
                await sock.sendMessage(chatId, { text: `✦ Provide a newsletter JID to remove.` }, { quoted: fake });
                return;
            }
            const jid   = val.includes('@newsletter') ? val : `${val}@newsletter`;
            const index = channels.indexOf(jid);
            if (index === -1) {
                await sock.sendMessage(chatId, { text: `✦ *${botName}* | Not found: ${jid}` }, { quoted: fake });
                return;
            }
            channels.splice(index, 1);
            saveChannels(channels);
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Removed: ${jid}\nRemaining: ${channels.length} channels` }, { quoted: fake });
        }
        else if (cmd === 'list') {
            if (!channels.length) {
                await sock.sendMessage(chatId, { text: `✦ *${botName}* | No channels configured.\nAdd with: .newsletterreact add <jid>` }, { quoted: fake });
                return;
            }
            await sock.sendMessage(chatId, {
                text: `✦ *${botName}* | My Channels (${channels.length})\n\n` + channels.map((c, i) => `${i + 1}. ${c}`).join('\n')
            }, { quoted: fake });
        }
        else {
            await sock.sendMessage(chatId, { text: `✦ Use: .newsletterreact on/off/add/remove/list` }, { quoted: fake });
        }

    } catch (err) {
        console.error('[NewsletterReact cmd] Error:', err.message);
    }
}

module.exports = { handleNewsletterMessage, newsletterreactCommand };
