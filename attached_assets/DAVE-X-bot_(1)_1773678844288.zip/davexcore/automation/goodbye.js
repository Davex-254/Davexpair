const { handleGoodbye } = require('../../davelib/welcome');
const { isGoodByeOn, getGoodbye } = require('../../davelib/index');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { resolvePhoneFromLid, resolveSenderFromGroup, isLidJid, cacheLidPhone } = require('../../davelib/lidResolver');
const store = require('../../davelib/lightweight_store');

// Resolve a display name for a participant JID
async function resolveName(sock, participantJid, groupParticipants = null) {
    if (!participantJid) return 'Member';

    try {
        const contactInfo = store.contacts?.[participantJid];
        if (contactInfo?.name) return contactInfo.name;
        if (contactInfo?.notify) return contactInfo.notify;
    } catch {}

    const raw = participantJid.split('@')[0].split(':')[0];

    if (!isLidJid(participantJid)) {
        return /^\d{7,15}$/.test(raw) ? raw : 'Member';
    }

    const fast = resolvePhoneFromLid(participantJid, sock);
    if (fast) return fast;

    if (groupParticipants) {
        for (const p of groupParticipants) {
            const pid  = (p.id  || '').split('@')[0].split(':')[0];
            const pLid = (p.lid || '').split('@')[0].split(':')[0];
            if ((pLid === raw || pid === raw) && pid && !pid.includes('lid') && /^\d{7,15}$/.test(pid)) {
                cacheLidPhone(raw, pid);
                try {
                    const resolved = pid + '@s.whatsapp.net';
                    const c = store.contacts?.[resolved];
                    if (c?.name) return c.name;
                    if (c?.notify) return c.notify;
                } catch {}
                return pid;
            }
        }
    }

    const fromGroup = await resolveSenderFromGroup(participantJid, null, sock).catch(() => null);
    if (fromGroup && /^\d{7,15}$/.test(fromGroup)) return fromGroup;

    return 'Member';
}

async function goodbyeCommand(sock, chatId, message, fullArgs) {
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);

    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, {
            text: `✦ Group command only`
        }, { quoted: fake });
        return;
    }

    await handleGoodbye(sock, chatId, message, fullArgs || '');
}

function getRandomGoodbyeTemplate(displayName, groupName, memberCount, botName) {
    const templates = [
        `✦ @${displayName} Has run out of data, let's pray for the poor 😢\n\nAnyway Goodbye Hustler 👋`,
        `✦ @${displayName} escaped! 🏃💨\n\nThey couldn't handle the vibes here 😂\n\nRemaining members: ${memberCount}`,
        `✦ @${displayName} went to buy data 💸\n\nWe hope you come back with full 5G! 📶\n\nFrom: *${groupName}*`,
        `✦ @${displayName} got tired of our nonsense 🤪\n\nGoodbye, we'll miss your reactions! 👋`,
        `✦ @${displayName} left the chat...\n\nProbably to touch some grass 🌱\n\nCome back soon!`,
        `✦ @${displayName} said "I'll be back" like Arnold 🦾\n\nWe're waiting... ⏳`,
        `✦ @${displayName} has left the group.\n\nReason: Group too lit 🔥\n\nMembers now: ${memberCount}`,
        `✦ @${displayName} ran away 🏃\n\nGoodbye and good luck out there! 👋`,
        `✦ @${displayName} went to find cheaper data bundles 💰\n\nGoodbye hustler! ✊`,
        `✦ @${displayName} couldn't handle the admin's jokes 😅\n\nWe don't blame you. Bye! 👋`
    ];
    return templates[Math.floor(Math.random() * templates.length)];
}

async function handleLeaveEvent(sock, id, participants) {
    try {
        const isGoodbyeEnabled = await isGoodByeOn(id);
        if (!isGoodbyeEnabled) return;

        const customMessage = await getGoodbye(id);
        const groupMetadata = await sock.groupMetadata(id);
        const groupName = groupMetadata.subject;
        const memberCount = groupMetadata.participants.length;
        const botName = getBotName();

        let ppgroup;
        try {
            ppgroup = await sock.profilePictureUrl(id, 'image');
        } catch {
            ppgroup = 'https://i.ibb.co/Z2Fyf4t/default-avatar.png';
        }

        for (const participant of participants) {
            try {
                const participantJid = typeof participant === 'string'
                    ? participant
                    : (participant.id || participant.toString());

                const displayName = await resolveName(sock, participantJid, groupMetadata.participants);

                // Determine the right JID and number for @mention in text
                // The @number in text must match the mentionedJid phone to avoid double-@
                const rawPart = participantJid.split('@')[0].split(':')[0];
                let mentionJid;
                let mentionNum;
                if (/^\d{7,15}$/.test(rawPart)) {
                    mentionNum = rawPart;
                    mentionJid = participantJid;
                } else if (/^\d{7,15}$/.test(displayName)) {
                    mentionNum = displayName;
                    mentionJid = displayName + '@s.whatsapp.net';
                } else {
                    mentionNum = rawPart;
                    mentionJid = participantJid;
                }

                // Profile picture
                let avatarUrl;
                try {
                    avatarUrl = await sock.profilePictureUrl(mentionJid, 'image');
                } catch {
                    try {
                        if (mentionJid !== participantJid) {
                            avatarUrl = await sock.profilePictureUrl(participantJid, 'image');
                        }
                    } catch {}
                    if (!avatarUrl) avatarUrl = ppgroup;
                }

                let goodbyeText;
                if (customMessage) {
                    goodbyeText = customMessage
                        .replace(/@\{user\}/g, `@${mentionNum}`)
                        .replace(/\{user\}/g, `@${mentionNum}`)
                        .replace(/{group}/g, groupName)
                        .replace(/{bot}/g, botName)
                        .replace(/{members}/g, String(memberCount));
                } else {
                    goodbyeText = getRandomGoodbyeTemplate(mentionNum, groupName, memberCount, botName);
                }

                await sock.sendMessage(id, {
                    text: goodbyeText,
                    contextInfo: {
                        mentionedJid: [mentionJid],
                        externalAdReply: {
                            title: `Goodbye, ${displayName}!`,
                            body: botName,
                            thumbnailUrl: avatarUrl || ppgroup,
                            sourceUrl: 'https://whatsapp.com/channel/0029VbApvFQ2Jl84lhONkc3k',
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                });

            } catch (error) {
                const participantJid = typeof participant === 'string'
                    ? participant
                    : (participant.id || participant.toString());
                const fallbacks = [
                    `✦ @${participantJid.split('@')[0].split(':')[0]} ran out of data 😢\n\nGoodbye! 👋`,
                    `✦ @${participantJid.split('@')[0].split(':')[0]} left the chat 🏃💨`,
                    `✦ @${participantJid.split('@')[0].split(':')[0]} escaped! Goodbye! 👋`
                ];
                await sock.sendMessage(id, {
                    text: fallbacks[Math.floor(Math.random() * fallbacks.length)],
                    mentions: [participantJid]
                }).catch(() => {});
            }
        }
    } catch (err) {
        console.error('handleLeaveEvent error:', err.message);
    }
}

module.exports = { goodbyeCommand, handleLeaveEvent };
