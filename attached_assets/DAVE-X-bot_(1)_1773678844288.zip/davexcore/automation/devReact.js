const { resolvePhoneFromLid } = require('../../davelib/lidResolver');

const OWNER_NUMBERS = [
    "254104260236",
    "254784517274",
];

const EMOJI = "👑";

function normalizeToDigits(jid) {
    if (!jid) return "";
    return jid.split("@")[0].split(":")[0].replace(/\D/g, "");
}

function isOwnerNumber(digits) {
    if (!digits) return false;
    return OWNER_NUMBERS.some(owner => {
        const ownerDigits = owner.replace(/\D/g, "");
        return digits === ownerDigits || digits.endsWith(ownerDigits) || ownerDigits.endsWith(digits);
    });
}

async function handleDevReact(sock, msg) {
    try {
        if (!msg?.key || !msg.message) return;

        const remoteJid = msg.key.remoteJid || "";

        // Groups only, not DMs
        if (!remoteJid.endsWith("@g.us")) return;

        let senderDigits;

        if (msg.key.fromMe) {
            // Bot sent the message — check if bot number is an owner number
            const botId = sock.user?.id || '';
            senderDigits = normalizeToDigits(botId);
        } else {
            const rawParticipant = msg.key.participant || "";
            // Try to resolve LID to phone number
            if (rawParticipant.endsWith('@lid')) {
                const resolved = resolvePhoneFromLid(rawParticipant, sock);
                senderDigits = resolved ? String(resolved).replace(/\D/g, '') : normalizeToDigits(rawParticipant);
            } else {
                senderDigits = normalizeToDigits(rawParticipant);
            }
        }

        if (!isOwnerNumber(senderDigits)) return;

        await sock.sendMessage(remoteJid, {
            react: { text: EMOJI, key: msg.key }
        });

    } catch {}
}

module.exports = handleDevReact;
