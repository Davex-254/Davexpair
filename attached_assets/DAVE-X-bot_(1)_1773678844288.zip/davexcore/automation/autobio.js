const { getOwnerConfig, setOwnerConfig } = require('../../Database/settingsStore');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { isSudo } = require('../../davelib/index');
const settings = require('../../daveset');

const _startTime = Date.now();
let _bioInterval = null;

function readConfig() {
    try {
        const cfg = getOwnerConfig('autobio');
        return cfg && typeof cfg === 'object'
            ? { enabled: false, template: null, ...cfg }
            : { enabled: false, template: null };
    } catch { return { enabled: false, template: null }; }
}

function writeConfig(cfg) {
    try { setOwnerConfig('autobio', cfg); return true; }
    catch { return false; }
}

function formatUptime() {
    const ms      = Date.now() - _startTime;
    const secs    = Math.floor(ms / 1000);
    const mins    = Math.floor(secs / 60);
    const hrs     = Math.floor(mins / 60);
    const days    = Math.floor(hrs / 24);
    const h       = hrs  % 24;
    const m       = mins % 60;
    const s       = secs % 60;

    if (days > 0) return `${days}d ${h}h ${m}m`;
    if (h   > 0) return `${h}h ${m}m ${s}s`;
    return `${m}m ${s}s`;
}

function buildBioText(cfg) {
    const botName = getBotName();
    const version = settings.version || '1.4.1';
    const uptime  = formatUptime();
    const now     = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });

    if (cfg.template) {
        return cfg.template
            .replace('{name}', botName)
            .replace('{version}', version)
            .replace('{uptime}', uptime)
            .replace('{time}', now);
    }

    return `⚡ ${botName} v${version} | Up: ${uptime} | ${now}`;
}

async function runAutoBio(sock) {
    try {
        const cfg = readConfig();
        if (!cfg.enabled) return;
        const text = buildBioText(cfg);
        await sock.updateProfileStatus(text);
    } catch {
        // Silent — profile update failures are non-critical
    }
}

function startAutoBio(sock) {
    // Always clear existing interval before starting a new one
    if (_bioInterval) clearInterval(_bioInterval);

    const cfg = readConfig();
    if (!cfg.enabled) return;

    // First run after 2s, then every 60s
    setTimeout(() => runAutoBio(sock), 2000);
    _bioInterval = setInterval(() => runAutoBio(sock), 60000);
}

function stopAutoBio() {
    if (_bioInterval) {
        clearInterval(_bioInterval);
        _bioInterval = null;
    }
}

async function autobioCommand(sock, chatId, msg, args) {
    try {
        const fake     = createFakeContact(msg);
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner  = msg.key.fromMe || (await isSudo(senderId));
        const botName  = getBotName();

        if (!isOwner) {
            await sock.sendMessage(chatId, { text: `✦ Owner only command` }, { quoted: fake });
            return;
        }

        const cfg = readConfig();
        const cmd = (args[0] || '').toLowerCase();

        if (!cmd) {
            await sock.sendMessage(chatId, {
                text:
                    `✦ *${botName}* | Auto Bio\n\n` +
                    `Status:   ${cfg.enabled ? '✅ ON' : '❌ OFF'}\n` +
                    `Template: ${cfg.template || '(default)'}\n\n` +
                    `*Example bio:*\n_${buildBioText(cfg)}_\n\n` +
                    `*Commands:*\n` +
                    `› .autobio on/off\n` +
                    `› .autobio settemplate <text>\n` +
                    `  Placeholders: {name} {version} {uptime} {time}\n` +
                    `› .autobio reset`
            }, { quoted: fake });
            return;
        }

        if (cmd === 'on') {
            cfg.enabled = true;
            writeConfig(cfg);
            startAutoBio(sock);
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Auto Bio ✅ ON\n_Updates every 60 seconds_` }, { quoted: fake });
        }
        else if (cmd === 'off') {
            cfg.enabled = false;
            writeConfig(cfg);
            stopAutoBio();
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Auto Bio ❌ OFF` }, { quoted: fake });
        }
        else if (cmd === 'settemplate') {
            const tmpl = args.slice(1).join(' ').trim();
            if (!tmpl) {
                await sock.sendMessage(chatId, { text: `✦ Provide a template.\nPlaceholders: {name} {version} {uptime} {time}` }, { quoted: fake });
                return;
            }
            cfg.template = tmpl;
            writeConfig(cfg);
            await sock.sendMessage(chatId, {
                text: `✦ *${botName}* | Template saved:\n_${buildBioText(cfg)}_`
            }, { quoted: fake });
        }
        else if (cmd === 'reset') {
            cfg.template = null;
            writeConfig(cfg);
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Template reset to default` }, { quoted: fake });
        }
        else {
            await sock.sendMessage(chatId, { text: `✦ Use: .autobio on/off/settemplate/reset` }, { quoted: fake });
        }

    } catch (err) {
        console.error('[AutoBio cmd] Error:', err.message);
    }
}

module.exports = { autobioCommand, startAutoBio, stopAutoBio, runAutoBio };
