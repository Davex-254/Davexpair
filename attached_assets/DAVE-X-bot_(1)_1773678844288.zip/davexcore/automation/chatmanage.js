const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const db = require('../../Database/database');

async function isAuthorized(sock, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        if (message.key.fromMe) return true;
        return db.isSudo(senderId);
    } catch {
        return message.key.fromMe;
    }
}

async function pinCommand(sock, chatId, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        if (!await isAuthorized(sock, message)) {
            return sock.sendMessage(chatId, { text: `✦ Owner only command` }, { quoted: fake });
        }

        try {
            await sock.chatModify({ pin: true }, chatId);
            await sock.sendMessage(chatId, { text: `✦ Chat pinned!` }, { quoted: fake });
        } catch (modifyErr) {
            if (modifyErr.message && (modifyErr.message.includes('myAppStateKey') || modifyErr.message.includes('app state'))) {
                await sock.sendMessage(chatId, {
                    text: `✦ Pin failed — app state not synced\nOn WhatsApp Business, send any message first then retry. Or pin the chat manually in WhatsApp.`
                }, { quoted: fake });
            } else {
                throw modifyErr;
            }
        }
    } catch (error) {
        try {
            const fake = createFakeContact(message.key.participant || message.key.remoteJid);
            await sock.sendMessage(chatId, { text: `✦ Pin failed: ${error.message}` }, { quoted: fake });
        } catch {}
    }
}

async function unpinCommand(sock, chatId, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        if (!await isAuthorized(sock, message)) {
            return sock.sendMessage(chatId, { text: `✦ Owner only command` }, { quoted: fake });
        }

        try {
            await sock.chatModify({ pin: false }, chatId);
            await sock.sendMessage(chatId, { text: `✦ Chat unpinned!` }, { quoted: fake });
        } catch (modifyErr) {
            if (modifyErr.message && (modifyErr.message.includes('myAppStateKey') || modifyErr.message.includes('app state'))) {
                await sock.sendMessage(chatId, {
                    text: `✦ Unpin failed — app state not synced\nOn WhatsApp Business, send any message first then retry. Or unpin the chat manually in WhatsApp.`
                }, { quoted: fake });
            } else {
                throw modifyErr;
            }
        }
    } catch (error) {
        try {
            const fake = createFakeContact(message.key.participant || message.key.remoteJid);
            await sock.sendMessage(chatId, { text: `✦ Unpin failed: ${error.message}` }, { quoted: fake });
        } catch {}
    }
}

async function archiveCommand(sock, chatId, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        if (!await isAuthorized(sock, message)) {
            return sock.sendMessage(chatId, { text: `✦ Owner only command` }, { quoted: fake });
        }

        const lastMsg = {
            key: message.key,
            messageTimestamp: message.messageTimestamp || Math.floor(Date.now() / 1000)
        };

        try {
            await sock.chatModify({ archive: true, lastMessages: [lastMsg] }, chatId);
            await sock.sendMessage(chatId, { text: `✦ Chat archived!` }, { quoted: fake });
        } catch (modifyErr) {
            if (modifyErr.message && (modifyErr.message.includes('myAppStateKey') || modifyErr.message.includes('app state'))) {
                await sock.sendMessage(chatId, {
                    text: `✦ Archive failed — app state not synced\nOn WhatsApp Business, send any message first then retry. Or archive the chat manually in WhatsApp.`
                }, { quoted: fake });
            } else {
                throw modifyErr;
            }
        }
    } catch (error) {
        try {
            const fake = createFakeContact(message.key.participant || message.key.remoteJid);
            await sock.sendMessage(chatId, { text: `✦ Archive failed: ${error.message}` }, { quoted: fake });
        } catch {}
    }
}

async function unarchiveCommand(sock, chatId, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        if (!await isAuthorized(sock, message)) {
            return sock.sendMessage(chatId, { text: `✦ Owner only command` }, { quoted: fake });
        }

        const lastMsg = {
            key: message.key,
            messageTimestamp: message.messageTimestamp || Math.floor(Date.now() / 1000)
        };

        try {
            await sock.chatModify({ archive: false, lastMessages: [lastMsg] }, chatId);
            await sock.sendMessage(chatId, { text: `✦ Chat unarchived!` }, { quoted: fake });
        } catch (modifyErr) {
            if (modifyErr.message && (modifyErr.message.includes('myAppStateKey') || modifyErr.message.includes('app state'))) {
                await sock.sendMessage(chatId, {
                    text: `✦ Unarchive failed — app state not synced\nOn WhatsApp Business, send any message first then retry. Or unarchive the chat manually in WhatsApp.`
                }, { quoted: fake });
            } else {
                throw modifyErr;
            }
        }
    } catch (error) {
        try {
            const fake = createFakeContact(message.key.participant || message.key.remoteJid);
            await sock.sendMessage(chatId, { text: `✦ Unarchive failed: ${error.message}` }, { quoted: fake });
        } catch {}
    }
}

async function disappearingCommand(sock, chatId, message, args) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        if (!await isAuthorized(sock, message)) {
            return sock.sendMessage(chatId, { text: `✦ Owner only command` }, { quoted: fake });
        }

        const sub = (args || '').toLowerCase().trim();

        if (!sub) {
            return sock.sendMessage(chatId, {
                text: `✦ *DISAPPEARING*
    
  Commands:
  › on - 24 hours
  › 7d - 7 days
  › 90d - 90 days
  › off - Disable`
            }, { quoted: fake });
        }

        let duration = 0;
        if (sub === 'on' || sub === '24h') {
            duration = 86400;
        } else if (sub === '7d') {
            duration = 604800;
        } else if (sub === '90d') {
            duration = 7776000;
        } else if (sub === 'off') {
            duration = 0;
        } else {
            return sock.sendMessage(chatId, { text: `✦ Use: on, off, 7d, 90d` }, { quoted: fake });
        }

        await sock.sendMessage(chatId, { disappearingMessagesInChat: duration });

        const label = duration === 0 ? 'OFF' : duration === 86400 ? '24 hours' : duration === 604800 ? '7 days' : '90 days';
        await sock.sendMessage(chatId, { text: `✦ Disappearing messages: ${label}` }, { quoted: fake });
    } catch (error) {
        try {
            const fake = createFakeContact(message.key.participant || message.key.remoteJid);
            await sock.sendMessage(chatId, { text: `✦ Failed: ${error.message}` }, { quoted: fake });
        } catch {}
    }
}

module.exports = {
    pinCommand,
    unpinCommand,
    archiveCommand,
    unarchiveCommand,
    disappearingCommand
};