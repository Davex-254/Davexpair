const { getOwnerConfig, setOwnerConfig } = require('../../Database/settingsStore');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { isSudo } = require('../../davelib/index');
const { resolvePhoneFromLid, isLidJid } = require('../../davelib/lidResolver');

const EMOJIS = ['❤️', '💛', '👍', '💜', '😮', '🤍', '💙'];

function randomEmoji() {
    return EMOJIS[Math.floor(Math.random() * EMOJIS.length)];
}

const DEFAULT_CONFIG = {
    viewOn:          true,
    reactOn:         false,
    replyOn:         false,
    replyText:       '👀 Seen your status!',
    reactionEmoji:   '❤️',
    randomReactions: true,
};

function readConfig() {
    try {
        const cfg = getOwnerConfig('autostatus');
        return cfg && typeof cfg === 'object'
            ? { ...DEFAULT_CONFIG, ...cfg }
            : { ...DEFAULT_CONFIG };
    } catch { return { ...DEFAULT_CONFIG }; }
}

function writeConfig(cfg) {
    try { setOwnerConfig('autostatus', cfg); return true; }
    catch { return false; }
}

// Resolve LID → phone JID using Baileys-native mapping first, then our group cache
async function resolveLidToPhone(lid, sock) {
    // 1. Try Baileys' own signalRepository.lidMapping (most accurate — auto-populated)
    try {
        if (sock?.signalRepository?.lidMapping) {
            const pn = await sock.signalRepository.lidMapping.getPNForLID(lid);
            if (pn) return pn;
        }
    } catch {}
    // 2. Fall back to our group participant LID cache
    const resolved = resolvePhoneFromLid(lid, sock);
    if (resolved) return `${resolved}@s.whatsapp.net`;
    return null;
}

async function handleStatusUpdate(sock, statusUpdate) {
    try {
        let mek = statusUpdate?.messages?.[0];
        if (!mek || !mek.message) return;

        // Unwrap ephemeral
        if (Object.keys(mek.message)[0] === 'ephemeralMessage') {
            mek.message = mek.message.ephemeralMessage.message;
        }

        if (mek.key?.remoteJid !== 'status@broadcast') return;

        const cfg = readConfig();

        // Resolve participant: always get a phone JID for receipts/reactions
        const rawJid = mek.key.participant || 'unknown';
        let phoneJid = null;
        if (isLidJid(rawJid)) {
            phoneJid = await resolveLidToPhone(rawJid, sock);
        } else {
            phoneJid = rawJid; // already a phone JID
        }

        const _from = phoneJid || rawJid;

        // Never auto-view/react/reply to own status posts
        if (mek.key.fromMe) return;

        // AUTO VIEW STATUS
        if (cfg.viewOn) {
            // Replace participant with phone JID so WA registers the receipt
            const readKey = phoneJid && !isLidJid(phoneJid)
                ? { ...mek.key, participant: phoneJid }
                : mek.key;
            await sock.readMessages([readKey]);
        }

        // AUTO REACT STATUS
        if (cfg.reactOn && phoneJid && !isLidJid(phoneJid)) {
            const emoji = cfg.randomReactions ? randomEmoji() : cfg.reactionEmoji;
            const reactKey = { ...mek.key, participant: phoneJid };
            await sock.sendMessage(
                'status@broadcast',
                { react: { text: emoji, key: reactKey } },
                { statusJidList: [phoneJid] }
            );
        }

        // AUTO REPLY STATUS
        if (cfg.replyOn && !mek.key.fromMe && phoneJid && !isLidJid(phoneJid)) {
            await sock.sendMessage(
                phoneJid,
                { text: cfg.replyText || DEFAULT_CONFIG.replyText },
                { quoted: mek }
            );
        }

    } catch (err) {
        console.error('[AutoStatus] Error:', err.message);
    }
}

// Command handler
async function autoStatusCommand(sock, chatId, msg, args) {
    try {
        const fake     = createFakeContact(msg);
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner  = msg.key.fromMe || (await isSudo(senderId));
        const botName  = getBotName();

        if (!isOwner) {
            await sock.sendMessage(chatId, { text: `✦ Owner only command` }, { quoted: fake });
            return;
        }

        const cfg = readConfig();

        if (!args?.length) {
            await sock.sendMessage(chatId, {
                text:
                    `✦ *${botName}* | Auto Status\n\n` +
                    `👁️ View:    ${cfg.viewOn   ? '✅ ON' : '❌ OFF'}\n` +
                    `❤️ React:   ${cfg.reactOn  ? '✅ ON' : '❌ OFF'}\n` +
                    `💬 Reply:   ${cfg.replyOn  ? '✅ ON' : '❌ OFF'}\n` +
                    `😀 Emoji:   ${cfg.reactionEmoji}\n` +
                    `🎲 Random:  ${cfg.randomReactions ? '✅ ON' : '❌ OFF'}\n` +
                    `📝 Msg:     ${cfg.replyText}\n\n` +
                    `*Commands:*\n` +
                    `› .autoviewstatus on/off\n` +
                    `› .autoreact on/off\n` +
                    `› .autoreply on/off\n` +
                    `› .autoreply setmsg <text>\n` +
                    `› .autoreact emoji <emoji>\n` +
                    `› .autoreact random on/off`
            }, { quoted: fake });
            return;
        }

        const cmd = (args[0] || '').toLowerCase();
        const sub = (args[1] || '').toLowerCase();

        if (cmd === 'on') {
            cfg.viewOn = true; writeConfig(cfg);
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Auto View ✅ ON` }, { quoted: fake });
        } else if (cmd === 'off') {
            cfg.viewOn = false; writeConfig(cfg);
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Auto View ❌ OFF` }, { quoted: fake });
        } else if (cmd === 'view') {
            cfg.viewOn = sub === 'on'; writeConfig(cfg);
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Auto View ${cfg.viewOn ? '✅ ON' : '❌ OFF'}` }, { quoted: fake });
        } else if (cmd === 'react') {
            if (sub === 'on' || sub === 'off') {
                cfg.reactOn = sub === 'on'; writeConfig(cfg);
                await sock.sendMessage(chatId, { text: `✦ *${botName}* | Auto React ${cfg.reactOn ? '✅ ON' : '❌ OFF'}` }, { quoted: fake });
            } else if (sub === 'emoji') {
                cfg.reactionEmoji = args[2] || '❤️'; writeConfig(cfg);
                await sock.sendMessage(chatId, { text: `✦ *${botName}* | Emoji → ${cfg.reactionEmoji}` }, { quoted: fake });
            } else if (sub === 'random') {
                cfg.randomReactions = (args[2] || '') === 'on'; writeConfig(cfg);
                await sock.sendMessage(chatId, { text: `✦ *${botName}* | Random ${cfg.randomReactions ? '✅ ON' : '❌ OFF'}` }, { quoted: fake });
            } else {
                await sock.sendMessage(chatId, { text: `✦ react on/off | react emoji <e> | react random on/off` }, { quoted: fake });
            }
        } else if (cmd === 'reply') {
            if (sub === 'on' || sub === 'off') {
                cfg.replyOn = sub === 'on'; writeConfig(cfg);
                await sock.sendMessage(chatId, { text: `✦ *${botName}* | Auto Reply ${cfg.replyOn ? '✅ ON' : '❌ OFF'}` }, { quoted: fake });
            } else if (sub === 'setmsg') {
                cfg.replyText = args.slice(2).join(' ').trim() || cfg.replyText; writeConfig(cfg);
                await sock.sendMessage(chatId, { text: `✦ *${botName}* | Reply msg set:\n_${cfg.replyText}_` }, { quoted: fake });
            } else {
                await sock.sendMessage(chatId, { text: `✦ reply on/off | reply setmsg <text>` }, { quoted: fake });
            }
        } else if (cmd === 'reset') {
            writeConfig({ ...DEFAULT_CONFIG });
            await sock.sendMessage(chatId, { text: `✦ *${botName}* | Reset to defaults` }, { quoted: fake });
        } else {
            await sock.sendMessage(chatId, { text: `✦ Unknown. Type *.autoviewstatus* for help.` }, { quoted: fake });
        }
    } catch (err) {
        console.error('[AutoStatus cmd]', err.message);
    }
}

module.exports = { autoStatusCommand, handleStatusUpdate };
