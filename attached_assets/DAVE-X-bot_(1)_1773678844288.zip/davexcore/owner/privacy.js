const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

/**
 * Privacy Commands — Baileys updateXPrivacy wrappers
 *
 * WAPrivacyValue:        'all' | 'contacts' | 'contact_blacklist' | 'none'
 * WAPrivacyOnlineValue:  'all' | 'match_last_seen'
 * WAPrivacyCallValue:    'all' | 'known'
 * WAReadReceiptsValue:   'all' | 'none'
 * WAPrivacyGroupAddValue:'all' | 'contacts' | 'contact_blacklist'
 * WAPrivacyMessagesValue:'all' | 'contacts'
 *
 * fetchPrivacySettings(force) returns: {
 *   blockedByMeList, readreceipts, profile, status, online, last,
 *   groupadd, calladd, linkpreviewsoff, disappearingMode,
 *   defaultDisappearingMode, messages
 * }
 */

const react = (sock, msg, emoji) =>
    sock.sendMessage(msg.key.remoteJid, { react: { text: emoji, key: msg.key } }).catch(() => {});

function reply(sock, chatId, text, fake) {
    return sock.sendMessage(chatId, { text }, { quoted: fake });
}

function invalidOption(sock, chatId, fake, cmd, validList) {
    const botName = getBotName();
    return reply(sock, chatId,
        `✦ *${botName}* — ${cmd}\n\nInvalid option.\nValid values:\n${validList.map(v => `• \`${v}\``).join('\n')}`,
        fake
    );
}

async function showPrivacyCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    try {
        await react(sock, message, '⏳');
        const p = await sock.fetchPrivacySettings(true);
        const lines = [
            `✦ *${botName} — Privacy Settings*\n`,
            `👁 Last Seen:      *${p.last || 'unknown'}*`,
            `🌐 Online:         *${p.online || 'unknown'}*`,
            `📸 Profile Photo:  *${p.profile || 'unknown'}*`,
            `📝 Status:         *${p.status || 'unknown'}*`,
            `📨 Messages:       *${p.messages || 'unknown'}*`,
            `📖 Read Receipts:  *${p.readreceipts || 'unknown'}*`,
            `👥 Group Add:      *${p.groupadd || 'unknown'}*`,
            `📞 Calls:          *${p.calladd || 'unknown'}*`,
            `\n_Use .lastseen / .onlineprivacy / .ppprivacy /\n.statusprivacy / .msgprivacy / .readreceipts /\n.groupsprivacy / .callprivacy to update each setting._`,
        ];
        await react(sock, message, '✅');
        return reply(sock, chatId, lines.join('\n'), fake);
    } catch (err) {
        console.error('[privacy] showPrivacy error:', err);
        await react(sock, message, '❌');
        return reply(sock, chatId, `❌ Failed to fetch privacy settings: ${err.message}`, fake);
    }
}

async function onlinePrivacyCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const valid = ['all', 'match_last_seen'];
    const val = (args[0] || '').toLowerCase().replace(/-/g, '_');
    if (!valid.includes(val)) return invalidOption(sock, chatId, fake, 'Online Privacy', valid);
    try {
        await react(sock, message, '⏳');
        await sock.updateOnlinePrivacy(val);
        await react(sock, message, '✅');
        return reply(sock, chatId,
            `✦ *${botName}*\n\n🌐 Online privacy set to *${val}*\n\n` +
            `• \`all\` — everyone sees you online\n` +
            `• \`match_last_seen\` — same audience as your last seen`,
            fake
        );
    } catch (err) {
        await react(sock, message, '❌');
        return reply(sock, chatId, `❌ Failed: ${err.message}`, fake);
    }
}

async function callPrivacyCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const valid = ['all', 'known'];
    const val = (args[0] || '').toLowerCase();
    if (!valid.includes(val)) return invalidOption(sock, chatId, fake, 'Call Privacy', valid);
    try {
        await react(sock, message, '⏳');
        await sock.updateCallPrivacy(val);
        await react(sock, message, '✅');
        return reply(sock, chatId,
            `✦ *${botName}*\n\n📞 Call privacy set to *${val}*\n\n` +
            `• \`all\` — anyone can call the bot\n` +
            `• \`known\` — only saved contacts`,
            fake
        );
    } catch (err) {
        await react(sock, message, '❌');
        return reply(sock, chatId, `❌ Failed: ${err.message}`, fake);
    }
}

async function readReceiptsCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const valid = ['all', 'none'];
    const val = (args[0] || '').toLowerCase();
    if (!valid.includes(val)) return invalidOption(sock, chatId, fake, 'Read Receipts', valid);
    try {
        await react(sock, message, '⏳');
        await sock.updateReadReceiptsPrivacy(val);
        await react(sock, message, '✅');
        return reply(sock, chatId,
            `✦ *${botName}*\n\n📖 Read receipts set to *${val}*\n\n` +
            `• \`all\` — blue ticks shown to senders\n` +
            `• \`none\` — ticks never turn blue`,
            fake
        );
    } catch (err) {
        await react(sock, message, '❌');
        return reply(sock, chatId, `❌ Failed: ${err.message}`, fake);
    }
}

async function groupsPrivacyCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const valid = ['all', 'contacts', 'contact_blacklist'];
    const val = (args[0] || '').toLowerCase().replace(/-/g, '_');
    if (!valid.includes(val)) return invalidOption(sock, chatId, fake, 'Groups Add Privacy', valid);
    try {
        await react(sock, message, '⏳');
        await sock.updateGroupsAddPrivacy(val);
        await react(sock, message, '✅');
        return reply(sock, chatId,
            `✦ *${botName}*\n\n👥 Group add privacy set to *${val}*\n\n` +
            `• \`all\` — anyone can add the bot to groups\n` +
            `• \`contacts\` — only saved contacts\n` +
            `• \`contact_blacklist\` — everyone except blacklisted`,
            fake
        );
    } catch (err) {
        await react(sock, message, '❌');
        return reply(sock, chatId, `❌ Failed: ${err.message}`, fake);
    }
}

async function statusPrivacyCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const valid = ['all', 'contacts', 'contact_blacklist', 'none'];
    const val = (args[0] || '').toLowerCase().replace(/-/g, '_');
    if (!valid.includes(val)) return invalidOption(sock, chatId, fake, 'Status Privacy', valid);
    try {
        await react(sock, message, '⏳');
        await sock.updateStatusPrivacy(val);
        await react(sock, message, '✅');
        return reply(sock, chatId,
            `✦ *${botName}*\n\n📝 Status privacy set to *${val}*`,
            fake
        );
    } catch (err) {
        await react(sock, message, '❌');
        return reply(sock, chatId, `❌ Failed: ${err.message}`, fake);
    }
}

async function ppPrivacyCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const valid = ['all', 'contacts', 'contact_blacklist', 'none'];
    const val = (args[0] || '').toLowerCase().replace(/-/g, '_');
    if (!valid.includes(val)) return invalidOption(sock, chatId, fake, 'Profile Photo Privacy', valid);
    try {
        await react(sock, message, '⏳');
        await sock.updateProfilePicturePrivacy(val);
        await react(sock, message, '✅');
        return reply(sock, chatId,
            `✦ *${botName}*\n\n📸 Profile photo privacy set to *${val}*`,
            fake
        );
    } catch (err) {
        await react(sock, message, '❌');
        return reply(sock, chatId, `❌ Failed: ${err.message}`, fake);
    }
}

async function msgPrivacyCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const valid = ['all', 'contacts'];
    const val = (args[0] || '').toLowerCase();
    if (!valid.includes(val)) return invalidOption(sock, chatId, fake, 'Messages Privacy', valid);
    try {
        await react(sock, message, '⏳');
        await sock.updateMessagesPrivacy(val);
        await react(sock, message, '✅');
        return reply(sock, chatId,
            `✦ *${botName}*\n\n📨 Messages privacy set to *${val}*\n\n` +
            `• \`all\` — anyone can message the bot\n` +
            `• \`contacts\` — only saved contacts`,
            fake
        );
    } catch (err) {
        await react(sock, message, '❌');
        return reply(sock, chatId, `❌ Failed: ${err.message}`, fake);
    }
}

async function linkPreviewsPrivacyCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const val = (args[0] || '').toLowerCase();
    if (!['on', 'off'].includes(val)) {
        return reply(sock, chatId,
            `✦ *${botName}* — Link Preview Privacy\n\nUsage:\n• \`.linkpreviewsprivacy off\` — disable link previews globally\n• \`.linkpreviewsprivacy on\` — enable link previews globally`,
            fake
        );
    }
    try {
        await react(sock, message, '⏳');
        const isDisabled = val === 'off';
        await sock.updateDisableLinkPreviewsPrivacy(isDisabled);
        await react(sock, message, '✅');
        return reply(sock, chatId,
            `✦ *${botName}*\n\n🔗 Link previews: *${val === 'off' ? 'DISABLED' : 'ENABLED'}*\n\n_${val === 'off' ? 'No link cards will be generated when the bot sends links.' : 'Link cards will be shown when the bot sends links.'}_`,
            fake
        );
    } catch (err) {
        await react(sock, message, '❌');
        return reply(sock, chatId, `❌ Failed: ${err.message}`, fake);
    }
}

module.exports = {
    showPrivacyCommand,
    onlinePrivacyCommand,
    callPrivacyCommand,
    readReceiptsCommand,
    groupsPrivacyCommand,
    statusPrivacyCommand,
    ppPrivacyCommand,
    msgPrivacyCommand,
    linkPreviewsPrivacyCommand,
};
