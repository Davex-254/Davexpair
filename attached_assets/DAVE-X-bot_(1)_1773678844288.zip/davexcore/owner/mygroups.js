const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function mygroupsCommand(sock, chatId, message) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;

    const isOwner = message.key.fromMe || db.isSudo(senderId);
    if (!isOwner) {
        return sock.sendMessage(chatId, { text: `✦ *${botName}* | Owner only command.` }, { quoted: fake });
    }

    try {
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });
        const groups = await sock.groupFetchAllParticipating();
        const groupList = Object.values(groups);

        if (!groupList.length) {
            return sock.sendMessage(chatId, {
                text: `✦ *${botName}* | Bot is not in any groups.`
            }, { quoted: fake });
        }

        // Sort by member count (most members first)
        groupList.sort((a, b) => (b.participants?.length || 0) - (a.participants?.length || 0));

        const lines = groupList.slice(0, 50).map((g, i) => {
            const name = g.subject || 'Unknown Group';
            const count = g.participants?.length || 0;
            return `${i + 1}. *${name}*\n   👥 ${count} members`;
        });

        const text = `✦ *${botName}* | My Groups\n\n📋 Total: *${groupList.length}*\n\n${lines.join('\n\n')}`;
        await sock.sendMessage(chatId, { text }, { quoted: fake });

    } catch (err) {
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}* | ❌ Failed to fetch groups: ${err.message}`
        }, { quoted: fake });
    }
}

module.exports = mygroupsCommand;
