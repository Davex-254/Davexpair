const fs = require('fs');
const path = require('path');
const { createFakeContact } = require('../../davelib/fakeContact');

const CHANNELS_FILE = path.join(__dirname, '../../storage/followed_channels.json');

function loadChannels() {
    try {
        if (fs.existsSync(CHANNELS_FILE)) {
            return JSON.parse(fs.readFileSync(CHANNELS_FILE, 'utf-8'));
        }
    } catch (e) {}
    return {};
}

function saveChannels(data) {
    try {
        fs.mkdirSync(path.dirname(CHANNELS_FILE), { recursive: true });
        fs.writeFileSync(CHANNELS_FILE, JSON.stringify(data, null, 2));
    } catch (e) {}
}

function trackChannel(jid, name) {
    const channels = loadChannels();
    channels[jid] = { name: name || jid, jid, addedAt: Date.now() };
    saveChannels(channels);
}

function untrackChannel(jid) {
    const channels = loadChannels();
    delete channels[jid];
    saveChannels(channels);
}

async function mychannelsCommand(sock, chatId, message, args) {
    const fkontak = createFakeContact(message);
    const sub = (args[0] || '').toLowerCase();

    try {
        if (!sub || sub === 'list') {
            const channels = loadChannels();
            const list = Object.values(channels);
            if (list.length === 0) {
                await sock.sendMessage(chatId, {
                    text: `✦ *MY CHANNELS*\n\nNo channels tracked yet.\n\nUse *.mychannels follow <link>* to follow and track a channel.`
                }, { quoted: fkontak });
                return;
            }
            let text = `✦ *MY CHANNELS* (${list.length})\n\n`;
            list.forEach((ch, i) => {
                text += `*${i + 1}.* ${ch.name}\n   \`${ch.jid}\`\n`;
            });
            text += `\n*Unfollow:* .mychannels unfollow <number>`;
            await sock.sendMessage(chatId, { text }, { quoted: fkontak });
            return;
        }

        if (sub === 'follow') {
            const input = args[1];
            if (!input) {
                await sock.sendMessage(chatId, {
                    text: `✦ Usage: *.mychannels follow <channel link or JID>*`
                }, { quoted: fkontak });
                return;
            }

            let jid = input;
            if (input.includes('whatsapp.com/channel/')) {
                const code = input.split('/channel/')[1]?.split(/[?#]/)[0]?.trim();
                if (!code) {
                    await sock.sendMessage(chatId, { text: `✦ Invalid channel link` }, { quoted: fkontak });
                    return;
                }
                try {
                    const meta = await sock.newsletterMetadata('invite', code);
                    jid = meta?.id || `${code}@newsletter`;
                    const name = meta?.name || code;
                    await sock.newsletterFollow(jid);
                    trackChannel(jid, name);
                    await sock.sendMessage(chatId, {
                        text: `✦ ✅ *Followed channel*\n\n  Name: ${name}\n  JID: ${jid}`
                    }, { quoted: fkontak });
                } catch (e) {
                    await sock.sendMessage(chatId, { text: `✦ Failed to follow: ${e.message}` }, { quoted: fkontak });
                }
                return;
            }

            if (input.endsWith('@newsletter')) {
                try {
                    const meta = await sock.newsletterMetadata('jid', input).catch(() => null);
                    const name = meta?.name || input;
                    await sock.newsletterFollow(input);
                    trackChannel(input, name);
                    await sock.sendMessage(chatId, {
                        text: `✦ ✅ *Followed channel*\n\n  Name: ${name}\n  JID: ${input}`
                    }, { quoted: fkontak });
                } catch (e) {
                    await sock.sendMessage(chatId, { text: `✦ Failed to follow: ${e.message}` }, { quoted: fkontak });
                }
                return;
            }

            await sock.sendMessage(chatId, {
                text: `✦ Invalid input. Provide a WhatsApp channel link or a JID ending in @newsletter`
            }, { quoted: fkontak });
            return;
        }

        if (sub === 'unfollow') {
            const channels = loadChannels();
            const list = Object.values(channels);
            const indexInput = parseInt(args[1]);

            if (!isNaN(indexInput) && indexInput >= 1 && indexInput <= list.length) {
                const ch = list[indexInput - 1];
                try {
                    await sock.newsletterUnfollow(ch.jid);
                } catch (e) {}
                untrackChannel(ch.jid);
                await sock.sendMessage(chatId, {
                    text: `✦ Unfollowed *${ch.name}*`
                }, { quoted: fkontak });
                return;
            }

            const jidInput = args[1];
            if (jidInput && channels[jidInput]) {
                try { await sock.newsletterUnfollow(jidInput); } catch (e) {}
                untrackChannel(jidInput);
                await sock.sendMessage(chatId, { text: `✦ Unfollowed channel` }, { quoted: fkontak });
                return;
            }

            await sock.sendMessage(chatId, {
                text: `✦ Usage:\n*.mychannels unfollow <number>* — from the list\n*.mychannels unfollow <jid>* — by JID`
            }, { quoted: fkontak });
            return;
        }

        if (sub === 'mute' || sub === 'unmute') {
            const channels = loadChannels();
            const list = Object.values(channels);
            const idx = parseInt(args[1]);
            let ch;
            if (!isNaN(idx) && idx >= 1 && idx <= list.length) {
                ch = list[idx - 1];
            } else if (args[1]?.endsWith('@newsletter') && channels[args[1]]) {
                ch = channels[args[1]];
            }
            if (!ch) {
                await sock.sendMessage(chatId, { text: `✦ Channel not found. Use *.mychannels list* first.` }, { quoted: fkontak });
                return;
            }
            try {
                if (sub === 'mute') {
                    await sock.newsletterMute(ch.jid);
                    await sock.sendMessage(chatId, { text: `✦ Muted *${ch.name}*` }, { quoted: fkontak });
                } else {
                    await sock.newsletterUnmute(ch.jid);
                    await sock.sendMessage(chatId, { text: `✦ Unmuted *${ch.name}*` }, { quoted: fkontak });
                }
            } catch (e) {
                await sock.sendMessage(chatId, { text: `✦ Failed: ${e.message}` }, { quoted: fkontak });
            }
            return;
        }

        await sock.sendMessage(chatId, {
            text: `✦ *MYCHANNELS — Commands*\n\n*.mychannels* — list tracked channels\n*.mychannels follow <link>* — follow a channel\n*.mychannels unfollow <number>* — unfollow by list number\n*.mychannels mute <number>* — mute channel\n*.mychannels unmute <number>* — unmute channel`
        }, { quoted: fkontak });

    } catch (error) {
        console.error('mychannels error:', error.message);
        await sock.sendMessage(chatId, { text: `✦ Error: ${error.message}` }, { quoted: fkontak });
    }
}

module.exports = { mychannelsCommand, trackChannel };
