const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { sendButtons } = require('gifted-btns');

async function channelidCommand(sock, chatId, message, fullArgs) {
    const fake = createFakeContact(message);
    const botName = getBotName();

    const url = (fullArgs?.trim()) ||
        (message.message?.conversation || message.message?.extendedTextMessage?.text || '')
            .split(' ').slice(1).join(' ').trim();

    if (!url) {
        return sock.sendMessage(chatId, {
            text: `┌─ *${botName} Channel ID* ─┐\n│\n│ Paste a WhatsApp channel link:\n│ .channelid <link>\n│\n│ Example:\n│ .channelid https://whatsapp.com/channel/XXXXX\n│\n└─────────────────────┘`
        }, { quoted: fake });
    }

    if (!url.includes('whatsapp.com/channel/') && !url.endsWith('@newsletter')) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Invalid input. Paste a WhatsApp channel link or newsletter JID.`
        }, { quoted: fake });
    }

    await sock.sendMessage(chatId, { react: { text: '🔍', key: message.key } });

    try {
        let meta = null;

        if (url.includes('whatsapp.com/channel/')) {
            const channelCode = url.split('/channel/')[1]?.split('?')[0]?.trim();
            if (!channelCode) throw new Error('Could not parse channel code from link.');
            try {
                meta = await sock.newsletterMetadata('invite', channelCode);
            } catch {
                meta = { id: `${channelCode}@newsletter`, name: 'Name unavailable' };
            }
        } else {
            try {
                meta = await sock.newsletterMetadata('jid', url);
            } catch {
                meta = { id: url, name: 'Name unavailable' };
            }
        }

        const jid = meta?.id || url;
        const name = meta?.name || 'Unknown';
        const descLine = meta?.description ? `\n│ 📝 ${meta.description}` : '';
        const subsLine = meta?.subscribers ? `\n│ 👥 Subscribers: ${meta.subscribers.toLocaleString()}` : '';
        const verifiedLine = meta?.verification === 'VERIFIED' ? '\n│ ✅ Verified Channel' : '';
        const inviteCode = meta?.invite || null;
        const channelLink = inviteCode ? `https://whatsapp.com/channel/${inviteCode}` : null;

        const infoCard = `┌─ *${botName} Channel Info* ─┐
│
│ 📛 *${name}*${descLine}${subsLine}${verifiedLine}
│ 🆔 *JID:* ${jid}
│
└─────────────────────┘`;

        const buttons = [
            {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Copy JID',
                    copy_code: jid
                })
            }
        ];

        if (channelLink) {
            buttons.push({
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Open Channel',
                    url: channelLink,
                    merchant_url: channelLink
                })
            });
        }

        try {
            await sendButtons(sock, chatId, {
                text: infoCard,
                footer: botName,
                buttons
            });
        } catch {
            await sock.sendMessage(chatId, { text: infoCard }, { quoted: fake });
            await sock.sendMessage(chatId, { text: jid }, { quoted: fake });
        }

        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('[CHANNELID]', error.message);
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Failed to fetch channel info: ${error.message}`
        }, { quoted: fake });
    }
}

module.exports = channelidCommand;
