const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function bioCommand(sock, chatId, message, args, fullArgs) {
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const botName = getBotName();

    const isOwner = message.key.fromMe || db.isSudo(senderId);
    if (!isOwner) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Only the bot owner can change the bio.`
        }, { quoted: fake });
        return;
    }

    const clearKeywords = ['remove', 'reset', 'clear', 'none', 'delete'];
    const firstWord = (args[0] || '').toLowerCase();

    if (clearKeywords.includes(firstWord) && args.length <= 1) {
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });
        try {
            await sock.updateProfileStatus('');
            await sock.sendMessage(chatId, {
                text: `*${botName}*\n✅ Bio has been cleared.`
            }, { quoted: fake });
        } catch (e) {
            await sock.sendMessage(chatId, {
                text: `*${botName}*\n❌ Failed to clear bio: ${e.message}`
            }, { quoted: fake });
        }
        return;
    }

    let bioText = fullArgs || '';
    if (firstWord === 'set') {
        bioText = args.slice(1).join(' ').trim();
    }

    if (!bioText.trim()) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n✦ *SETBIO*\n\nUsage:\n*.setbio* <your bio text>\n*.removebio* — clear bio\n\nExample:\n*.setbio* I am DAVE-X bot 🤖`
        }, { quoted: fake });
        return;
    }

    await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });
    try {
        await sock.updateProfileStatus(bioText.trim());
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n✅ Bio updated:\n_${bioText.trim()}_`
        }, { quoted: fake });
    } catch (e) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Failed to update bio: ${e.message}`
        }, { quoted: fake });
    }
}

module.exports = bioCommand;
