const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const db = require('../../Database/database');

const HELP_TEXT = (botName, prefix) => `*${botName} BUSINESS PROFILE*\n\n` +
    `*Commands:*\n` +
    `${prefix}bizprofile — Show this help\n` +
    `${prefix}bizprofile address <text> — Set business address\n` +
    `${prefix}bizprofile email <email> — Set business email\n` +
    `${prefix}bizprofile description <text> — Set business description\n` +
    `${prefix}bizprofile website <url> — Set business website\n` +
    `${prefix}bizprofile catalog — View your product catalog\n` +
    `${prefix}bizprofile collections — View your collections\n\n` +
    `ℹ️ Address, email, description and website require a WhatsApp Business account.`;

async function bizprofileCommand(sock, chatId, message, fullArgs) {
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const botName = getBotName();

    const isOwner = message.key.fromMe || db.isSudo(senderId);
    if (!isOwner) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Owner only command!`
        }, { quoted: fake });
    }

    const args = (fullArgs || '').trim();
    const sub = args.toLowerCase();

    if (!args) {
        return sock.sendMessage(chatId, {
            text: HELP_TEXT(botName, '')
        }, { quoted: fake });
    }

    if (sub === 'catalog') {
        try {
            const catalog = await sock.getCatalog({ limit: 10 });
            if (!catalog || !catalog.products || catalog.products.length === 0) {
                return sock.sendMessage(chatId, {
                    text: `*${botName}*\nNo products found in your catalog.\n\nThis feature requires a WhatsApp Business account with products set up.`
                }, { quoted: fake });
            }
            let text = `*${botName} CATALOG*\n\n`;
            for (const p of catalog.products) {
                text += `▸ *${p.title || 'Untitled'}*\n`;
                if (p.description) text += `  ${p.description}\n`;
                if (p.price) text += `  Price: ${p.currency || ''} ${p.price}\n`;
                text += '\n';
            }
            return sock.sendMessage(chatId, { text }, { quoted: fake });
        } catch (err) {
            return sock.sendMessage(chatId, {
                text: `*${botName}*\n❌ Could not fetch catalog.\nThis feature requires a WhatsApp Business account.\n\nError: ${err.message}`
            }, { quoted: fake });
        }
    }

    if (sub === 'collections') {
        try {
            const result = await sock.getCollections();
            if (!result || !result.collections || result.collections.length === 0) {
                return sock.sendMessage(chatId, {
                    text: `*${botName}*\nNo collections found.\n\nThis feature requires a WhatsApp Business account.`
                }, { quoted: fake });
            }
            let text = `*${botName} COLLECTIONS*\n\n`;
            for (const c of result.collections) {
                text += `▸ *${c.name || 'Unnamed'}* (${c.itemCount || 0} items)\n`;
            }
            return sock.sendMessage(chatId, { text }, { quoted: fake });
        } catch (err) {
            return sock.sendMessage(chatId, {
                text: `*${botName}*\n❌ Could not fetch collections.\nThis feature requires a WhatsApp Business account.\n\nError: ${err.message}`
            }, { quoted: fake });
        }
    }

    const spaceIdx = args.indexOf(' ');
    if (spaceIdx === -1) {
        return sock.sendMessage(chatId, {
            text: HELP_TEXT(botName, '')
        }, { quoted: fake });
    }

    const field = args.slice(0, spaceIdx).toLowerCase();
    const value = args.slice(spaceIdx + 1).trim();

    if (!value) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Please provide a value after \`${field}\`.`
        }, { quoted: fake });
    }

    const profileUpdate = {};

    if (field === 'address') {
        profileUpdate.address = value;
    } else if (field === 'email') {
        profileUpdate.email = value;
    } else if (field === 'description') {
        profileUpdate.description = value;
    } else if (field === 'website') {
        const url = value.startsWith('http') ? value : `https://${value}`;
        profileUpdate.websites = [url];
    } else {
        return sock.sendMessage(chatId, {
            text: HELP_TEXT(botName, '')
        }, { quoted: fake });
    }

    try {
        await sock.updateBussinesProfile(profileUpdate);
        const fieldLabel = field === 'website' ? 'website' : field;
        return sock.sendMessage(chatId, {
            text: `*${botName}*\n✅ Business ${fieldLabel} updated!\n\nValue: ${value}`
        }, { quoted: fake });
    } catch (err) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Failed to update business ${field}.\nNote: This requires a WhatsApp Business account.\n\nError: ${err.message}`
        }, { quoted: fake });
    }
}

module.exports = { bizprofileCommand };
