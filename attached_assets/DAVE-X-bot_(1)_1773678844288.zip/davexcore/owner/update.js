const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const https = require('https');
const http = require('http');
const settings = require('../../daveset');
const isOwnerOrSudo = require('../../davelib/isOwner');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

// ─── GitLab helpers ────────────────────────────────────────────────────────
function getGitLabConfig() {
    const project = process.env.GITLAB_PROJECT || settings.gitlabProject || '';
    const branch  = settings.gitlabBranch || 'main';
    const token   = process.env.GITLAB_TOKEN || '';
    const encoded = encodeURIComponent(project);
    return { project, branch, token, encoded };
}

function gitlabHeaders(token) {
    const h = { 'User-Agent': 'DAVE-X-Updater/1.4.1' };
    if (token) h['PRIVATE-TOKEN'] = token;
    return h;
}

async function fetchGitLabCommit() {
    const { encoded, branch, token } = getGitLabConfig();
    if (!encoded) return null;
    const url = `https://gitlab.com/api/v4/projects/${encoded}/repository/commits?ref_name=${branch}&per_page=1`;
    return new Promise((resolve) => {
        const req = https.get(url, { headers: gitlabHeaders(token) }, res => {
            let body = '';
            res.on('data', d => body += d);
            res.on('end', () => {
                try {
                    const data = JSON.parse(body);
                    if (Array.isArray(data) && data[0]) {
                        resolve({ sha: data[0].id, message: data[0].title || 'New update' });
                    } else {
                        resolve(null);
                    }
                } catch { resolve(null); }
            });
        });
        req.on('error', () => resolve(null));
        req.setTimeout(15000, () => { req.destroy(); resolve(null); });
    });
}

// ─── Utilities ─────────────────────────────────────────────────────────────
function run(cmd) {
    return new Promise((resolve, reject) => {
        exec(cmd, { windowsHide: true }, (err, stdout, stderr) => {
            if (err) return reject(new Error(stderr || stdout || err.message));
            resolve(stdout.toString().trim());
        });
    });
}

const SKIP_DIRS = new Set(['.git', 'tmp', 'temp', 'attached_assets']);

const PROTECTED_FILES = new Set([
    '.env', 'creds.json', 'login.json', 'sessionErrorCount.json',
    'baileys_store.json', '.migration_status.json', 'package-lock.json', 'settings.js'
]);

const PROTECTED_DIR_PREFIXES = [
    'storage/', 'sessions/', 'backups/', 'Database/', 'database/',
    'session/', 'data/', 'auth_info/', 'auth_info_baileys/', '.local/'
];

function isProtected(rel) {
    if (PROTECTED_FILES.has(rel)) return true;
    return PROTECTED_DIR_PREFIXES.some(p => rel.startsWith(p));
}

function fileHash(fp) {
    try { return crypto.createHash('md5').update(fs.readFileSync(fp)).digest('hex'); } catch { return null; }
}

function backupProtected() {
    const backups = {};
    for (const f of PROTECTED_FILES) {
        const fp = path.join(process.cwd(), f);
        if (fs.existsSync(fp)) try { backups[f] = fs.readFileSync(fp); } catch {}
    }
    const dbFile = path.join(process.cwd(), 'storage', 'davex.db');
    if (fs.existsSync(dbFile)) try { backups['storage/davex.db'] = fs.readFileSync(dbFile); } catch {}
    const credsFile = path.join(process.cwd(), 'session', 'creds.json');
    if (fs.existsSync(credsFile)) try { backups['session/creds.json'] = fs.readFileSync(credsFile); } catch {}
    return backups;
}

function restoreProtected(backups) {
    for (const [file, content] of Object.entries(backups)) {
        const fp = path.join(process.cwd(), file);
        try {
            fs.mkdirSync(path.dirname(fp), { recursive: true });
            fs.writeFileSync(fp, content);
        } catch {}
    }
}

// ─── Download (supports custom headers, follows redirects) ─────────────────
function downloadFile(url, dest, headers = {}, visited = new Set()) {
    return new Promise((resolve, reject) => {
        if (visited.has(url) || visited.size > 8) return reject(new Error('Too many redirects'));
        visited.add(url);
        const client = url.startsWith('https://') ? https : http;
        const req = client.get(url, { headers: { 'User-Agent': 'DAVE-X-Updater/1.4.1', ...headers } }, res => {
            if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
                const next = new URL(res.headers.location, url).toString();
                res.resume();
                return downloadFile(next, dest, headers, visited).then(resolve).catch(reject);
            }
            if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
            const file = fs.createWriteStream(dest);
            res.pipe(file);
            file.on('finish', () => file.close(resolve));
            file.on('error', err => { try { fs.unlinkSync(dest); } catch {} reject(err); });
        });
        req.on('error', err => { try { fs.unlinkSync(dest); } catch {} reject(err); });
        req.setTimeout(120000, () => { req.destroy(); reject(new Error('Download timeout')); });
    });
}

// ─── Extract ───────────────────────────────────────────────────────────────
async function extractZip(zipPath, outDir) {
    for (const tool of ['unzip', '7z e', 'busybox unzip']) {
        try {
            await run(`command -v ${tool.split(' ')[0]}`);
            if (tool === '7z e') {
                await run(`7z e -y '${zipPath}' -o'${outDir}'`);
            } else {
                await run(`${tool} -o '${zipPath}' -d '${outDir}'`);
            }
            return;
        } catch {}
    }
    throw new Error('No zip extraction tool available (unzip/7z)');
}

function smartCopy(src, dest, skipTop = [], rel = '', stats = { updated: 0, skipped: 0, added: 0 }) {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
        if (skipTop.includes(entry) && rel === '') continue;
        const s = path.join(src, entry);
        const d = path.join(dest, entry);
        const r = rel ? `${rel}/${entry}` : entry;
        if (fs.lstatSync(s).isDirectory()) {
            if (SKIP_DIRS.has(entry)) continue;
            smartCopy(s, d, skipTop, r, stats);
        } else {
            if (isProtected(r)) { stats.skipped++; continue; }
            if (fs.existsSync(d) && fileHash(s) === fileHash(d)) { stats.skipped++; continue; }
            fs.mkdirSync(path.dirname(d), { recursive: true });
            fs.copyFileSync(s, d);
            fs.existsSync(d) ? stats.updated++ : stats.added++;
        }
    }
    return stats;
}

// ─── Update via GitLab archive ─────────────────────────────────────────────
async function updateViaGitLab() {
    const { encoded, branch, token } = getGitLabConfig();
    if (!encoded) throw new Error('GitLab project not configured in daveset.js');

    const tmpDir = path.join(process.cwd(), 'tmp');
    fs.mkdirSync(tmpDir, { recursive: true });
    const zipPath  = path.join(tmpDir, 'gitlab_update.zip');
    const extractTo = path.join(tmpDir, 'gitlab_extract');

    // Build archive URL (never logged)
    const archiveUrl = `https://gitlab.com/api/v4/projects/${encoded}/repository/archive.zip?sha=${branch}`;
    const headers = gitlabHeaders(token);

    const backups = backupProtected();

    await downloadFile(archiveUrl, zipPath, headers);

    fs.rmSync(extractTo, { recursive: true, force: true });
    await extractZip(zipPath, extractTo);

    const entries = fs.readdirSync(extractTo);
    const root = entries.length === 1 && fs.lstatSync(path.join(extractTo, entries[0])).isDirectory()
        ? path.join(extractTo, entries[0])
        : extractTo;

    const skipTop = ['tmp', 'temp', 'storage', 'sessions', 'session', 'backups', 'Database', 'database', '.env', '.git'];
    const stats = smartCopy(root, process.cwd(), skipTop);

    restoreProtected(backups);

    try { fs.rmSync(extractTo, { recursive: true, force: true }); } catch {}
    try { fs.unlinkSync(zipPath); } catch {}

    return stats;
}

// ─── Fallback: update via ZIP URL (daveset.updateZipUrl) ──────────────────
async function updateViaZip(zipUrl) {
    if (!zipUrl) throw new Error('No ZIP URL configured.');
    const tmpDir = path.join(process.cwd(), 'tmp');
    fs.mkdirSync(tmpDir, { recursive: true });
    const zipPath   = path.join(tmpDir, 'update.zip');
    const extractTo = path.join(tmpDir, 'update_extract');
    await downloadFile(zipUrl, zipPath);
    fs.rmSync(extractTo, { recursive: true, force: true });
    await extractZip(zipPath, extractTo);
    const entries = fs.readdirSync(extractTo);
    const root = entries.length === 1 && fs.lstatSync(path.join(extractTo, entries[0])).isDirectory()
        ? path.join(extractTo, entries[0])
        : extractTo;
    const skipTop = ['tmp', 'temp', 'storage', 'sessions', 'session', 'backups', 'Database', 'database'];
    const backups = backupProtected();
    const stats = smartCopy(root, process.cwd(), skipTop);
    restoreProtected(backups);
    try { fs.rmSync(extractTo, { recursive: true, force: true }); } catch {}
    try { fs.unlinkSync(zipPath); } catch {}
    return stats;
}

// ─── Main command ──────────────────────────────────────────────────────────
async function updateCommand(sock, chatId, message) {
    const fakeContact = createFakeContact(message);
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    const isOwner  = await isOwnerOrSudo(senderId, sock, chatId);

    if (!message.key.fromMe && !isOwner) {
        return sock.sendMessage(chatId, {
            text: `*${botName} UPDATE*\n\nOwner only command.`
        }, { quoted: fakeContact });
    }

    let statusMsg;
    try {
        statusMsg = await sock.sendMessage(chatId, {
            text: `*${botName} UPDATE*\n\nChecking for updates...`
        }, { quoted: fakeContact });

        // Check GitLab for latest commit
        const latest = await fetchGitLabCommit();

        // Load last known commit hash
        const commitFile = path.join(process.cwd(), 'storage', 'last_commit.txt');
        const lastKnown  = fs.existsSync(commitFile) ? fs.readFileSync(commitFile, 'utf8').trim() : null;

        if (latest && lastKnown && latest.sha === lastKnown) {
            await sock.sendMessage(chatId, {
                text: `*${botName} UPDATE*\n\n✅ Already up to date.`,
                edit: statusMsg.key
            });
            return;
        }

        // Download and apply update
        await sock.sendMessage(chatId, {
            text: `*${botName} UPDATE*\n\nDownloading update...`,
            edit: statusMsg.key
        });

        let stats;
        const { project } = getGitLabConfig();
        if (project) {
            stats = await updateViaGitLab();
        } else {
            stats = await updateViaZip(settings.updateZipUrl || process.env.UPDATE_ZIP_URL);
        }

        // Save new commit hash
        if (latest) {
            try { fs.writeFileSync(commitFile, latest.sha, 'utf8'); } catch {}
        }

        await sock.sendMessage(chatId, {
            text: `*${botName} UPDATE*\n\n✅ Updated successfully!\n` +
                  `Files: ${stats.updated} updated, ${stats.added} added, ${stats.skipped} skipped\n\n` +
                  `Restarting...`,
            edit: statusMsg.key
        });

        setTimeout(() => process.exit(0), 1500);

    } catch (err) {
        const msg = `*${botName} UPDATE*\n\n❌ Update failed.\nTry again later.`;
        if (statusMsg?.key) {
            await sock.sendMessage(chatId, { text: msg, edit: statusMsg.key }).catch(() => {});
        } else {
            await sock.sendMessage(chatId, { text: msg }, { quoted: fakeContact }).catch(() => {});
        }
        // Log error without exposing repo URLs or tokens
        console.error('[UPDATE] Failed:', err.message?.replace(/https?:\/\/[^\s]+/g, '[URL]'));
    }
}

module.exports = updateCommand;
