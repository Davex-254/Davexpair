const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { sendButtons } = require('gifted-btns');
const db = require('../../Database/database');

const PAIR_SITE = 'https://davexx-sessionpair.onrender.com/code';

async function pairCommand(sock, chatId, q, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        const isOwner = message.key.fromMe || db.isSudo(senderId);
        if (!isOwner) {
            return sock.sendMessage(chatId, {
                text: `*${botName}*\nOwner only command!`
            }, { quoted: fake });
        }

        if (!q) {
            return sock.sendMessage(chatId, {
                text: `┌─ *${botName} Pair* ─┐\n│\n│ Usage: .pair <phone number>\n│ Example: .pair 254712345678\n│\n└─────────────────────┘`
            }, { quoted: fake });
        }

        const phoneNumber = q.replace(/[^0-9]/g, '');

        if (phoneNumber.length < 10 || phoneNumber.length > 15) {
            return sock.sendMessage(chatId, {
                text: `*${botName}*\nInvalid number. Include country code, e.g. 254712345678`
            }, { quoted: fake });
        }

        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        let code = null;
        let lastErr = null;

        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                const res = await fetch(`${PAIR_SITE}?number=${phoneNumber}`, {
                    signal: AbortSignal.timeout(20000)
                });
                const data = await res.json();
                const c = data?.code?.toString()?.trim();

                if (c && c !== 'Service Currently Unavailable' && c !== 'Please provide a phone number') {
                    code = c;
                    break;
                }
                lastErr = c || 'Empty response from pair site';
            } catch (err) {
                lastErr = err.message;
                if (attempt < 3) await new Promise(r => setTimeout(r, 3000));
            }
        }

        if (!code) {
            await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
            return sock.sendMessage(chatId, {
                text: `*${botName}*\nFailed to get pair code: ${lastErr}\n\nThe pair site may be offline — try again shortly.`
            }, { quoted: fake });
        }

        const card = `┌─ *${botName} Pair Code* ─┐\n│\n│ Number: +${phoneNumber}\n│\n│ *${code}*\n│\n│ Enter this on the target device.\n│\n└─────────────────────┘`;

        const buttons = [
            {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Copy Code',
                    copy_code: code
                })
            }
        ];

        try {
            await sendButtons(sock, chatId, { text: card, footer: botName, buttons });
        } catch {
            await sock.sendMessage(chatId, { text: card }, { quoted: fake });
        }

        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('[PAIR]', error.message);
    }
}

module.exports = pairCommand;