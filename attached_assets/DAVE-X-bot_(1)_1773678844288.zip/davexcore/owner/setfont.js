const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { getBotFont, setBotFont } = require('../../davelib/botConfig');
const { FONT_STYLES, applyBotFont, getStyleList } = require('../../davelib/fontStyles');

async function setfontCommand(sock, chatId, message, args, fullArgs) {
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const botName = getBotName();

    if (!message.key.fromMe) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Only the bot owner can change the font style.`
        }, { quoted: fake });
        return;
    }

    const sub = (args[0] || '').toLowerCase().trim();

    // Show font list
    if (!sub || sub === 'list' || sub === 'styles' || sub === 'help') {
        const currentFont = getBotFont();
        const styles = getStyleList();
        let text = `*${botName} — FONT STYLES*\n\n`;
        text += `Current style: *${FONT_STYLES[currentFont]?.name || 'Default'}*\n\n`;
        text += `*Available Styles:*\n`;
        text += `━━━━━━━━━━━━━━━━━━━━\n`;
        for (const s of styles) {
            const isCurrent = s.key === currentFont;
            text += `${isCurrent ? '✅' : '▸'} *${s.key}*\n`;
            text += `   ${s.name} — ${s.description}\n`;
            text += `   Preview: ${s.preview}\n`;
        }
        text += `━━━━━━━━━━━━━━━━━━━━\n`;
        text += `\nUsage: .setfont <style>\n`;
        text += `Example: .setfont sans_bold\n`;
        text += `Reset: .setfont none`;
        await sock.sendMessage(chatId, { text }, { quoted: fake });
        return;
    }

    // Preview a specific style
    if (sub === 'preview' && args[1]) {
        const styleName = args[1].toLowerCase();
        if (!FONT_STYLES[styleName]) {
            await sock.sendMessage(chatId, {
                text: `*${botName}*\n❌ Unknown style: "${styleName}"\nUse .setfont list to see all styles.`
            }, { quoted: fake });
            return;
        }
        const style = FONT_STYLES[styleName];
        const sampleText = `This is a preview of ${style.name} style.\nThe bot would respond like this!`;
        const converted = applyBotFont(sampleText, styleName);
        await sock.sendMessage(chatId, {
            text: `*${botName} — PREVIEW: ${style.name}*\n\n${converted}\n\nSet it with: .setfont ${styleName}`
        }, { quoted: fake });
        return;
    }

    // Set a style
    const styleName = sub;
    if (!FONT_STYLES[styleName]) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Unknown style: "${styleName}"\n\nUse .setfont list to see all available styles.`
        }, { quoted: fake });
        return;
    }

    setBotFont(styleName);
    const style = FONT_STYLES[styleName];
    const confirmText = styleName === 'none'
        ? `✅ Font style reset to default.`
        : `✅ Font style set to *${style.name}*!\n\nPreview: ${style.preview}\n\nAll bot responses will now use this style.`;

    await sock.sendMessage(chatId, {
        text: `*${botName}*\n${confirmText}`
    }, { quoted: fake });
}

module.exports = setfontCommand;
