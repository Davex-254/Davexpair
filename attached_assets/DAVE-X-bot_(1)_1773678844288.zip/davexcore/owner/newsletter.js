const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

function resolveNewsletterInput(input) {
    if (!input) return null;
    if (input.endsWith('@newsletter')) return { type: 'jid', value: input };
    if (input.includes('whatsapp.com/channel/')) {
        const code = input.split('/channel/')[1]?.split('?')[0]?.trim();
        if (code) return { type: 'invite', value: code };
    }
    if (/^[a-zA-Z0-9_-]{20,}$/.test(input)) return { type: 'invite', value: input };
    return null;
}

async function resolveJid(sock, input) {
    const ref = resolveNewsletterInput(input);
    if (!ref) return null;
    if (ref.type === 'jid') return ref.value;
    const meta = await sock.newsletterMetadata('invite', ref.value);
    return meta?.id || null;
}

async function newsletterCommand(sock, chatId, message, args, senderId) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const sub = (args[0] || '').toLowerCase();

    const HELP = `┌─ *${botName} NEWSLETTER* ─┐
│
│ *Channel Management:*
│ .newsletter info <link/jid>
│ .newsletter create <name>
│ .newsletter create <name> | <desc>
│ .newsletter setname <jid> <name>
│ .newsletter setdesc <jid> <desc>
│ .newsletter setpic <jid>  ← reply to image
│ .newsletter removepic <jid>
│ .newsletter delete <jid>
│
│ *Posts:*
│ .newsletter post <jid> <text>
│ .newsletter react <jid> <serverid> <emoji>
│ .newsletter fetchposts <jid> <count>
│
│ *Subscriptions:*
│ .newsletter follow <link/jid>
│ .newsletter unfollow <jid>
│ .newsletter mute <jid>
│ .newsletter unmute <jid>
│ .newsletter subscribe <jid>
│
│ *Admin Management:*
│ .newsletter admins <jid>
│ .newsletter removeadmin <jid> <userjid>
│ .newsletter changeowner <jid> <newjid>
│
│ *Stats:*
│ .newsletter subs <link/jid>
│
└─────────────────────┘`;

    try {
        if (!sub || sub === 'help') {
            return sock.sendMessage(chatId, { text: HELP }, { quoted: fake });
        }

        if (sub === 'info') {
            const input = args[1];
            if (!input) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter info <link or jid>` }, { quoted: fake });
            const ref = resolveNewsletterInput(input);
            if (!ref) return sock.sendMessage(chatId, { text: `*${botName}*\nInvalid channel link or JID.` }, { quoted: fake });
            await sock.sendMessage(chatId, { react: { text: '🔍', key: message.key } });
            const meta = await sock.newsletterMetadata(ref.type, ref.value);
            if (!meta) return sock.sendMessage(chatId, { text: `*${botName}*\nChannel not found.` }, { quoted: fake });
            const verified = meta.verification === 'VERIFIED' ? '✅ Verified' : '❌ Unverified';
            const subs = meta.subscribers?.toLocaleString() || 'N/A';
            const desc = meta.description ? `\n│ 📝 *Desc:* ${meta.description}` : '';
            const invite = meta.invite ? `\n│ 🔗 https://whatsapp.com/channel/${meta.invite}` : '';
            const mute = meta.mute_state ? `\n│ 🔔 Mute: ${meta.mute_state}` : '';
            const created = meta.creation_time ? `\n│ 📅 Created: ${new Date(meta.creation_time * 1000).toDateString()}` : '';
            const info = `┌─ *Channel Info* ─┐
│
│ 📛 *Name:* ${meta.name}${desc}
│ 👥 *Subscribers:* ${subs}
│ ${verified}${invite}${mute}${created}
│ 🆔 *JID:* ${meta.id}
│
└─────────────────────┘`;
            await sock.sendMessage(chatId, { text: info }, { quoted: fake });
            await sock.sendMessage(chatId, { text: meta.id }, { quoted: fake });
            return;
        }

        if (sub === 'create') {
            const rest = args.slice(1).join(' ').trim();
            if (!rest) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter create <name>\nOr: .newsletter create <name> | <description>` }, { quoted: fake });
            let name, description;
            if (rest.includes('|')) {
                [name, ...description] = rest.split('|');
                name = name.trim();
                description = description.join('|').trim();
            } else {
                name = rest;
                description = undefined;
            }
            await sock.sendMessage(chatId, { react: { text: '🔄', key: message.key } });
            const meta = await sock.newsletterCreate(name, description);
            const text = `┌─ *Channel Created!* ─┐
│
│ 📛 *Name:* ${meta.name}
│ 🆔 *JID:* ${meta.id}
│ 🔗 *Link:* https://whatsapp.com/channel/${meta.invite}
│
└─────────────────────┘`;
            await sock.sendMessage(chatId, { text }, { quoted: fake });
            await sock.sendMessage(chatId, { text: meta.id }, { quoted: fake });
            await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });
            return;
        }

        if (sub === 'post') {
            const jid = args[1];
            const text = args.slice(2).join(' ').trim();
            if (!jid || !text) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter post <jid> <text content>` }, { quoted: fake });
            if (!jid.endsWith('@newsletter')) return sock.sendMessage(chatId, { text: `*${botName}*\nProvide a valid newsletter JID (ends with @newsletter)` }, { quoted: fake });
            await sock.sendMessage(jid, { text });
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Post sent to channel.` }, { quoted: fake });
            return;
        }

        if (sub === 'react') {
            const jid = args[1];
            const serverId = args[2];
            const emoji = args[3] || '';
            if (!jid || !serverId) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter react <jid> <server-id> <emoji>\nLeave emoji empty to remove reaction.` }, { quoted: fake });
            await sock.newsletterReactMessage(jid, serverId, emoji || undefined);
            await sock.sendMessage(chatId, { text: `*${botName}*\n${emoji ? `✅ Reacted with ${emoji}` : '✅ Reaction removed'}` }, { quoted: fake });
            return;
        }

        if (sub === 'fetchposts' || sub === 'posts') {
            const jid = args[1];
            const count = parseInt(args[2]) || 10;
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter fetchposts <jid> [count]` }, { quoted: fake });
            await sock.sendMessage(chatId, { react: { text: '🔍', key: message.key } });
            const result = await sock.newsletterFetchMessages(jid, Math.min(count, 50), 0, 0);
            await sock.sendMessage(chatId, {
                text: `*${botName}*\n📋 Fetched ${count} posts from:\n${jid}\n\n_Raw result logged to console._`
            }, { quoted: fake });
            console.log('[NEWSLETTER POSTS]', JSON.stringify(result, null, 2));
            return;
        }

        if (sub === 'subscribe') {
            const jid = args[1];
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter subscribe <jid>` }, { quoted: fake });
            const result = await sock.subscribeNewsletterUpdates(jid);
            await sock.sendMessage(chatId, {
                text: `*${botName}*\n✅ Subscribed to live updates.\n${result?.duration ? `Duration: ${result.duration}s` : ''}`
            }, { quoted: fake });
            return;
        }

        if (sub === 'setpic') {
            const jid = args[1];
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter setpic <jid>\n_Reply to an image message._` }, { quoted: fake });
            const quotedImg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;
            if (!quotedImg) return sock.sendMessage(chatId, { text: `*${botName}*\nReply to an image to set as channel picture.` }, { quoted: fake });
            const { downloadMediaMessage } = require('@whiskeysockets/baileys');
            const buffer = await downloadMediaMessage({ message: { imageMessage: quotedImg } }, 'buffer', {});
            await sock.newsletterUpdatePicture(jid, buffer);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Channel picture updated.` }, { quoted: fake });
            return;
        }

        if (sub === 'removepic') {
            const jid = args[1];
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter removepic <jid>` }, { quoted: fake });
            await sock.newsletterRemovePicture(jid);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Channel picture removed.` }, { quoted: fake });
            return;
        }

        if (sub === 'follow') {
            const input = args[1];
            if (!input) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter follow <link or jid>` }, { quoted: fake });
            const jid = await resolveJid(sock, input);
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nInvalid channel link or JID.` }, { quoted: fake });
            await sock.sendMessage(chatId, { react: { text: '🔄', key: message.key } });
            await sock.newsletterFollow(jid);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Now following:\n${jid}` }, { quoted: fake });
            await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });
            return;
        }

        if (sub === 'unfollow') {
            const input = args[1];
            if (!input) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter unfollow <jid>` }, { quoted: fake });
            const jid = await resolveJid(sock, input);
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nInvalid channel link or JID.` }, { quoted: fake });
            await sock.newsletterUnfollow(jid);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Unfollowed:\n${jid}` }, { quoted: fake });
            return;
        }

        if (sub === 'mute') {
            const input = args[1];
            if (!input) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter mute <jid>` }, { quoted: fake });
            const jid = await resolveJid(sock, input);
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nInvalid channel link or JID.` }, { quoted: fake });
            await sock.newsletterMute(jid);
            await sock.sendMessage(chatId, { text: `*${botName}*\n🔕 Muted:\n${jid}` }, { quoted: fake });
            return;
        }

        if (sub === 'unmute') {
            const input = args[1];
            if (!input) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter unmute <jid>` }, { quoted: fake });
            const jid = await resolveJid(sock, input);
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nInvalid channel link or JID.` }, { quoted: fake });
            await sock.newsletterUnmute(jid);
            await sock.sendMessage(chatId, { text: `*${botName}*\n🔔 Unmuted:\n${jid}` }, { quoted: fake });
            return;
        }

        if (sub === 'setname') {
            const jid = args[1];
            const name = args.slice(2).join(' ').trim();
            if (!jid || !name) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter setname <jid> <new name>` }, { quoted: fake });
            await sock.newsletterUpdateName(jid, name);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Channel name updated to: *${name}*` }, { quoted: fake });
            return;
        }

        if (sub === 'setdesc') {
            const jid = args[1];
            const desc = args.slice(2).join(' ').trim();
            if (!jid || !desc) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter setdesc <jid> <description>` }, { quoted: fake });
            await sock.newsletterUpdateDescription(jid, desc);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Channel description updated.` }, { quoted: fake });
            return;
        }

        if (sub === 'subs' || sub === 'subscribers') {
            const input = args[1];
            if (!input) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter subs <link or jid>` }, { quoted: fake });
            await sock.sendMessage(chatId, { react: { text: '🔍', key: message.key } });
            const jid = await resolveJid(sock, input);
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nInvalid channel link or JID.` }, { quoted: fake });
            const result = await sock.newsletterSubscribers(jid);
            const count = result?.subscribers?.toLocaleString() || 'N/A';
            await sock.sendMessage(chatId, { text: `*${botName}*\n👥 *Subscribers:* ${count}\n${jid}` }, { quoted: fake });
            return;
        }

        if (sub === 'admins') {
            const jid = args[1];
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter admins <jid>` }, { quoted: fake });
            const count = await sock.newsletterAdminCount(jid);
            await sock.sendMessage(chatId, { text: `*${botName}*\n👑 *Admins:* ${count}\n${jid}` }, { quoted: fake });
            return;
        }

        if (sub === 'removeadmin' || sub === 'demote') {
            const jid = args[1];
            const userJid = args[2];
            if (!jid || !userJid) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter removeadmin <jid> <user-jid>` }, { quoted: fake });
            await sock.newsletterDemote(jid, userJid);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Admin removed:\n${userJid}` }, { quoted: fake });
            return;
        }

        if (sub === 'changeowner') {
            const jid = args[1];
            const newOwner = args[2];
            if (!jid || !newOwner) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter changeowner <jid> <new-owner-jid>` }, { quoted: fake });
            await sock.newsletterChangeOwner(jid, newOwner);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Channel ownership transferred to:\n${newOwner}` }, { quoted: fake });
            return;
        }

        if (sub === 'delete') {
            const jid = args[1];
            if (!jid) return sock.sendMessage(chatId, { text: `*${botName}*\nUsage: .newsletter delete <jid>` }, { quoted: fake });
            await sock.newsletterDelete(jid);
            await sock.sendMessage(chatId, { text: `*${botName}*\n🗑️ Channel deleted:\n${jid}` }, { quoted: fake });
            return;
        }

        await sock.sendMessage(chatId, { text: HELP }, { quoted: fake });

    } catch (err) {
        console.error('[NEWSLETTER]', err.message);
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Error: ${err.message}`
        }, { quoted: fake });
    }
}

module.exports = { newsletterCommand };
