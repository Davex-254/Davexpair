const isAdmin = require('../../davelib/isAdmin');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
async function hijackCommand(sock, chatId, message, senderId) {
    try {
        const fake = createFakeContact(message);

        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { text: '❌ This command can only be used in groups!' }, { quoted: fake });
            return;
        }

        const adminStatus = await isAdmin(sock, chatId, senderId);
        if (!adminStatus.isBotAdmin) {
            await sock.sendMessage(chatId, { text: '❌ Bot must be an admin to hijack the group!' }, { quoted: fake });
            return;
        }

        await sock.sendMessage(chatId, { text: '🔄 Starting group hijack...' }, { quoted: fake });

        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participants = groupMetadata.participants;
            // Bot phone number only (no @suffix) — safe against LID vs s.whatsapp.net mismatch
            const botPhone = sock.user.id.split(':')[0].split('@')[0];

            const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');
            // Exclude bot by comparing phone number portion only
            const nonBotAdmins = admins.filter(a => {
                const aPhone = (a.id || '').split('@')[0].split(':')[0];
                return aPhone !== botPhone;
            });

            let demotedCount = 0;
            for (const admin of nonBotAdmins) {
                try {
                    // Normalize LID to phone JID for groupParticipantsUpdate
                    let targetJid = admin.id;
                    if (targetJid.endsWith('@lid')) {
                        const phone = targetJid.split('@')[0];
                        targetJid = phone + '@s.whatsapp.net';
                    }
                    await sock.groupParticipantsUpdate(chatId, [targetJid], 'demote');
                    demotedCount++;
                    console.log(`[HIJACK] Demoted ${targetJid}`);
                    await new Promise(resolve => setTimeout(resolve, 600));
                } catch (e) {
                    console.log(`[HIJACK] Failed to demote ${admin.id}: ${e.message}`);
                }
            }

            const ownerId = message.key.participant || senderId;
            const ownerPhone = ownerId.split('@')[0].split(':')[0];
            const ownerIsBot = ownerPhone === botPhone;
            if (!ownerIsBot) {
                try {
                    // Normalize owner JID too
                    let ownerJid = ownerId;
                    if (ownerJid.endsWith('@lid')) ownerJid = ownerPhone + '@s.whatsapp.net';
                    await sock.groupParticipantsUpdate(chatId, [ownerJid], 'promote');
                    console.log(`[HIJACK] Promoted owner ${ownerJid}`);
                } catch (e) {
                    console.log(`[HIJACK] Owner already admin or failed: ${e.message}`);
                }
            }

            await sock.sendMessage(chatId, {
                text: `*Group Hijack Complete*\n\nDemoted: ${demotedCount} admin(s)\nYou are now the only admin\n\nUse this power responsibly!`
            }, { quoted: fake });

        } catch (error) {
            console.error('Hijack operation error:', error);
            await sock.sendMessage(chatId, { text: `❌ Hijack failed: ${error.message}` }, { quoted: fake });
        }

    } catch (error) {
        console.error('Error in hijack command:', error);
    }
}

module.exports = hijackCommand;
