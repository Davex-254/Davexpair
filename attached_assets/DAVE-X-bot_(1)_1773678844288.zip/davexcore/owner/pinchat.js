const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function pinchatCommand(sock, chatId, message, args) {
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);
    const botName = getBotName();

    if (!message.key.fromMe) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Only the bot owner can pin chats.`
        }, { quoted: fake });
        return;
    }

    const sub = args[0]?.toLowerCase();
    const target = args[1] || chatId;
    const jid = target.includes('@') ? target : `${target.replace(/[^0-9]/g, '')}@s.whatsapp.net`;

    try {
        await sock.sendMessage(chatId, { react: { text: '⏳', key: message.key } });

        if (sub === 'off' || sub === 'unpin' || sub === 'remove') {
            await sock.chatModify({ pin: false }, jid);
            await sock.sendMessage(chatId, {
                text: `*${botName}*\n✅ Chat unpinned.`
            }, { quoted: fake });
        } else {
            await sock.chatModify({ pin: true }, jid);
            await sock.sendMessage(chatId, {
                text: `*${botName}*\n✅ Chat pinned to top.`
            }, { quoted: fake });
        }
    } catch (e) {
        await sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Failed: ${e.message}`
        }, { quoted: fake });
    }
}

async function unpinchatCommand(sock, chatId, message, args) {
    return pinchatCommand(sock, chatId, message, ['off', ...(args || [])]);
}

module.exports = { pinchatCommand, unpinchatCommand };
