const db = require('../../Database/database');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

async function savecontactCommand(sock, chatId, message, args) {
    const fake = createFakeContact(message);
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;

    const isOwner = message.key.fromMe || db.isSudo(senderId);
    if (!isOwner) {
        return sock.sendMessage(chatId, { text: `✦ *${botName}* | Owner only command.` }, { quoted: fake });
    }

    // Resolve target: reply or number from args
    const ctxInfo = message.message?.extendedTextMessage?.contextInfo || {};
    const quotedParticipant = ctxInfo.participant || null;
    const mentionedJids = ctxInfo.mentionedJid || [];
    const argNumber = (args || '').replace(/[^0-9]/g, '');

    let targetJid = null;
    let displayName = 'Contact';

    if (quotedParticipant) {
        targetJid = quotedParticipant;
    } else if (mentionedJids.length > 0) {
        targetJid = mentionedJids[0];
    } else if (argNumber.length >= 7 && argNumber.length <= 15) {
        targetJid = `${argNumber}@s.whatsapp.net`;
    }

    if (!targetJid) {
        return sock.sendMessage(chatId, {
            text: `✦ *${botName}* | Usage:\n*.savecontact* 254712345678\n*.savecontact* @mention\n*(reply)* .savecontact`
        }, { quoted: fake });
    }

    const number = targetJid.split('@')[0].split(':')[0];

    // Try to get name from contacts
    try {
        const contactInfo = sock.contacts?.[targetJid];
        if (contactInfo?.name) displayName = contactInfo.name;
        else if (contactInfo?.notify) displayName = contactInfo.notify;
        else displayName = `+${number}`;
    } catch {}

    // Send as a vCard contact
    const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${displayName}\nTEL;type=CELL;type=VOICE;waid=${number}:+${number}\nEND:VCARD`;

    try {
        await sock.sendMessage(chatId, {
            contacts: {
                displayName,
                contacts: [{ vcard }]
            }
        }, { quoted: fake });
    } catch (err) {
        await sock.sendMessage(chatId, {
            text: `✦ *${botName}* | ❌ Failed to send contact: ${err.message}`
        }, { quoted: fake });
    }
}

module.exports = savecontactCommand;
