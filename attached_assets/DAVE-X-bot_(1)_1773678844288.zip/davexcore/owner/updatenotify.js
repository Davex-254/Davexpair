const https = require('https');
const fs = require('fs');
const path = require('path');
const { getOwnerConfig, setOwnerConfig } = require('../../Database/settingsStore');
const { getBotName } = require('../../davelib/fakeContact');
const settings = require('../../daveset');

const LAST_COMMIT_FILE = path.join(process.cwd(), 'storage', 'last_commit.txt');
const CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6 hours

function getGitLabConfig() {
    const project = process.env.GITLAB_PROJECT || settings.gitlabProject || '';
    const branch  = settings.gitlabBranch || 'main';
    const token   = process.env.GITLAB_TOKEN || '';
    const encoded = encodeURIComponent(project);
    return { project, branch, token, encoded };
}

function gitlabHeaders(token) {
    const h = { 'User-Agent': 'DAVE-X-Bot/1.4.1', 'Accept': 'application/json' };
    if (token) h['PRIVATE-TOKEN'] = token;
    return h;
}

function getLastCommit() {
    try {
        if (fs.existsSync(LAST_COMMIT_FILE)) return fs.readFileSync(LAST_COMMIT_FILE, 'utf8').trim();
    } catch {}
    return null;
}

function saveLastCommit(sha) {
    try { fs.writeFileSync(LAST_COMMIT_FILE, sha, 'utf8'); } catch {}
}

async function fetchLatestCommit() {
    const { encoded, branch, token } = getGitLabConfig();
    if (!encoded) return null;

    const url = `https://gitlab.com/api/v4/projects/${encoded}/repository/commits?ref_name=${branch}&per_page=1`;

    return new Promise((resolve) => {
        const req = https.get(url, { headers: gitlabHeaders(token) }, res => {
            let body = '';
            res.on('data', d => body += d);
            res.on('end', () => {
                try {
                    const data = JSON.parse(body);
                    if (Array.isArray(data) && data[0]) {
                        resolve({
                            sha: data[0].id,
                            message: (data[0].title || data[0].message || 'New update').split('\n')[0],
                            date: data[0].committed_date || ''
                        });
                    } else {
                        resolve(null);
                    }
                } catch { resolve(null); }
            });
        });
        req.on('error', () => resolve(null));
        req.setTimeout(15000, () => { req.destroy(); resolve(null); });
    });
}

async function checkForUpdates(sock) {
    try {
        // Always on — update notifications cannot be disabled
        const latest = await fetchLatestCommit();
        if (!latest) return;

        const lastKnown = getLastCommit();
        if (!lastKnown) {
            saveLastCommit(latest.sha);
            return;
        }

        // Only notify if there is an actual new commit
        if (latest.sha === lastKnown) return;

        saveLastCommit(latest.sha);

        const botName = getBotName();
        const currentVersion = settings.version || '1.4.1';
        const ownerJid = sock.user?.id?.split(':')[0] + '@s.whatsapp.net';
        const shortSha = latest.sha.substring(0, 8);
        const commitDate = latest.date ? new Date(latest.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '';

        const updateMsg =
            `✦ *${botName} — New Version Available!*\n\n` +
            `🔢 *Current version:* v${currentVersion}\n` +
            `📦 *New update pushed to repo*\n\n` +
            `🔖 *Commit:* \`${shortSha}\`` + (commitDate ? `  _(${commitDate})_` : '') + `\n` +
            `📝 "${latest.message}"\n\n` +
            `*To update:*\n` +
            `› Type *.update* to auto-install the latest version`;

        await sock.sendMessage(ownerJid, { text: updateMsg });

    } catch {
        // Silent — never expose repo path or token in logs
    }
}

function startUpdateChecker(sock) {
    // First check after 45 seconds (let bot fully connect)
    setTimeout(() => checkForUpdates(sock), 45000);
    // Then every 6 hours
    setInterval(() => checkForUpdates(sock), CHECK_INTERVAL_MS);
}

async function updatenotifyCommand(sock, chatId, message, args) {
    const db = require('../../Database/database');
    const { createFakeContact } = require('../../davelib/fakeContact');
    const fake = createFakeContact(message);
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;

    const isOwner = message.key.fromMe || db.isSudo(senderId);
    if (!isOwner) {
        return sock.sendMessage(chatId, { text: `✦ *${botName}* | Owner only command.` }, { quoted: fake });
    }

    const sub = (args || '').trim().toLowerCase();
    const currentVersion = settings.version || '1.4.1';

    if (sub === 'check') {
        await sock.sendMessage(chatId, { react: { text: '🔍', key: message.key } });
        const latest = await fetchLatestCommit();
        const lastKnown = getLastCommit();
        if (!latest) {
            return sock.sendMessage(chatId, { text: `✦ *${botName}* | ❌ Couldn't reach update server.` }, { quoted: fake });
        }
        const upToDate = latest.sha === lastKnown;
        const shortSha = latest.sha.substring(0, 8);
        const statusLine = upToDate ? '✅ Up to date' : '⚠️ New version available!';
        return sock.sendMessage(chatId, {
            text: `✦ *${botName}* | Update Check\n\n${statusLine}\n🔢 Current: v${currentVersion}\n🔖 Latest commit: \`${shortSha}\`\n📝 "${latest.message}"`
        }, { quoted: fake });
    }

    await sock.sendMessage(chatId, {
        text: `✦ *${botName}* | Update Notifications\n\nStatus: ✅ Always ON\n🔢 Version: v${currentVersion}\n\nCommand:\n› .updatenotify check`
    }, { quoted: fake });
}

module.exports = { startUpdateChecker, updatenotifyCommand };
