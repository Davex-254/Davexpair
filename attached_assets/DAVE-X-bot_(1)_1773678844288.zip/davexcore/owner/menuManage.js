const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const { setMenuImage, getMenuImage, setMenuVideo, getMenuVideo } = require('../../davelib/botConfig');
const { getOwnerConfig, setOwnerConfig } = require('../../Database/settingsStore');

const MENU_STYLES = {
    '1': 'Document (large thumbnail)',
    '2': 'Plain Text',
    '3': 'Text + Ad Reply',
    '4': 'Image + Caption',
    '5': 'Interactive Flow',
    '6': 'Payment Style',
    '7': 'Video/GIF + Caption',
};

const DEFAULT_SETTINGS = {
    menuStyle: '2',
    showMemory: true,
    showUptime: true,
    showProgressBar: true,
};

function loadSettings() {
    try {
        const config = getOwnerConfig('menuSettings');
        if (config && typeof config === 'object') {
            return { ...DEFAULT_SETTINGS, ...config };
        }
    } catch {}
    return { ...DEFAULT_SETTINGS };
}

function saveSettings(settings) {
    try {
        setOwnerConfig('menuSettings', settings);
    } catch {}
}

function getMenuSettings() { return loadSettings(); }
function getMenuStyle()     { return loadSettings().menuStyle; }

function setMenuStyle(style) {
    if (!MENU_STYLES[style]) return false;
    const s = loadSettings();
    s.menuStyle = style;
    saveSettings(s);
    return true;
}

function toggleMenuSetting(key) {
    const s = loadSettings();
    if (typeof s[key] !== 'boolean') return false;
    s[key] = !s[key];
    saveSettings(s);
    return s[key];
}

function setMenuSettings(newSettings) {
    const s = { ...loadSettings(), ...newSettings };
    saveSettings(s);
    return s;
}

async function menuManageCommand(sock, chatId, message, args) {
    const senderId = message.key.participant || message.key.remoteJid;
    const fakeContact = createFakeContact(senderId);
    const botName = getBotName();

    if (args.length === 0) {
        const settings = getMenuSettings();
        const currentImage = getMenuImage() || '(none)';
        const currentVideo = getMenuVideo() || '(none)';

        let msg = `╭─❖ *MENU SETTINGS* ❖─╮\n`;
        msg += `│ Style   : ${settings.menuStyle} — ${MENU_STYLES[settings.menuStyle]}\n`;
        msg += `│ Memory  : ${settings.showMemory ? 'ON' : 'OFF'}\n`;
        msg += `│ Uptime  : ${settings.showUptime ? 'ON' : 'OFF'}\n`;
        msg += `│ Bar     : ${settings.showProgressBar ? 'ON' : 'OFF'}\n`;
        msg += `│ Image   : ${currentImage.length > 30 ? currentImage.slice(0, 30) + '…' : currentImage}\n`;
        msg += `│ Video   : ${currentVideo.length > 30 ? currentVideo.slice(0, 30) + '…' : currentVideo}\n`;
        msg += `╰─────────────────────╯\n\n`;
        msg += `*Styles:*\n`;
        for (const [k, v] of Object.entries(MENU_STYLES)) msg += `${k} › ${v}\n`;
        msg += `\n*Commands:*\n`;
        msg += `✧ .menuset style <1-7>\n`;
        msg += `✧ .menuset memory\n`;
        msg += `✧ .menuset uptime\n`;
        msg += `✧ .menuset progress\n`;
        msg += `✧ .menuset image <url>\n`;
        msg += `✧ .menuset video <url>\n`;
        msg += `✧ .menuset resetimage\n`;
        msg += `✧ .menuset resetvideo`;
        await sock.sendMessage(chatId, { text: msg }, { quoted: fakeContact });
        return;
    }

    const action = args[0].toLowerCase();

    try {
        if (action === 'style') {
            const style = args[1];
            if (!style || !MENU_STYLES[style]) {
                await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Use: .menuset style <1-7>` }, { quoted: fakeContact });
                return;
            }
            if (setMenuStyle(style)) {
                await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Style ${style}: ${MENU_STYLES[style]}` }, { quoted: fakeContact });
            }
            return;
        }

        if (action === 'image') {
            const url = args[1];
            if (!url) {
                await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Provide an image URL.\nUsage: .menuset image <url>` }, { quoted: fakeContact });
                return;
            }
            setMenuImage(url);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Menu image set.` }, { quoted: fakeContact });
            return;
        }

        if (action === 'video') {
            const url = args[1];
            if (!url) {
                await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Provide a video/GIF URL.\nUsage: .menuset video <url>` }, { quoted: fakeContact });
                return;
            }
            setMenuVideo(url);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Menu video set. Use style 7 to activate it.` }, { quoted: fakeContact });
            return;
        }

        if (action === 'resetimage') {
            setMenuImage('');
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Menu image cleared.` }, { quoted: fakeContact });
            return;
        }

        if (action === 'resetvideo') {
            setMenuVideo('');
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ Menu video cleared.` }, { quoted: fakeContact });
            return;
        }

        const toggleMap = {
            'memory': 'showMemory',
            'uptime': 'showUptime',
            'progress': 'showProgressBar',
        };

        const settingKey = toggleMap[action];
        if (settingKey) {
            const newVal = toggleMenuSetting(settingKey);
            await sock.sendMessage(chatId, { text: `*${botName}*\n✅ ${action}: ${newVal ? 'ON' : 'OFF'}` }, { quoted: fakeContact });
            return;
        }

        await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Unknown option. Send .menuset to see all options.` }, { quoted: fakeContact });

    } catch (err) {
        await sock.sendMessage(chatId, { text: `*${botName}*\n❌ Error: ${err.message}` }, { quoted: fakeContact });
    }
}

module.exports = {
    menuManageCommand,
    MENU_STYLES,
    getMenuSettings,
    getMenuStyle,
    setMenuStyle,
    toggleMenuSetting,
    setMenuSettings,
};
