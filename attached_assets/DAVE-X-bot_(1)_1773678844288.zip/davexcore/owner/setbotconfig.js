const { getBotName, setBotName, getMenuImage, setMenuImage, getConfig, updateConfig } = require('../../davelib/botConfig');
const { createFakeContact } = require('../../davelib/fakeContact');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

async function setbotconfigCommand(sock, chatId, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        if (!message.key.fromMe) {
            await sock.sendMessage(chatId, { 
                text: `┌─ *${botName}* ─┐\n│\n│ ✦ This magic is only for the owner!\n│\n└─────────────┘` 
            }, { quoted: fake });
            return;
        }

        const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
        const args = text.trim().split(' ').slice(1);
        const action = args[0]?.toLowerCase();

        if (!action) {
            const config = getConfig();
            const usage = `┌─ *${botName} CONFIG* ─┐
│
│ ✦ Current Settings:
│ • Bot Name: ${config.botName}
│ • Menu Image: ${config.menuImage ? '✓ Set' : '✗ Not set'}
│ • Antidelete Private: ${config.antideletePrivate ? '✓ ON' : '✗ OFF'}
│
│ ✦ Available Spells:
│ • .setbotname <name> - Change bot's name
│ • .setmenuimage - Set menu image (reply to image)
│ • .botconfig get - View full configuration
│
│ ✦ Example:
│ .setbotname MyAwesomeBot
│
└────────────────────┘`;
            await sock.sendMessage(chatId, { text: usage }, { quoted: fake });
            return;
        }

        if (action === 'get') {
            const config = getConfig();
            const statusText = `┌─ *${botName} CONFIG* ─┐
│
│ ✦ Current Configuration:
│ • Bot Name: ${config.botName}
│ • Owner Name: ${config.ownerName || 'Not set'}
│ • Menu Image: ${config.menuImage ? '✓ Set' : '✗ Not set'}
│ • Antidelete Private: ${config.antideletePrivate ? '✓ ON' : '✗ OFF'}
│
└────────────────────┘`;
            await sock.sendMessage(chatId, { text: statusText }, { quoted: fake });
        }
    } catch (error) {
        console.error('Error in setbotconfig command:', error.message, 'Line:', error.stack?.split('\n')[1]);
        await sock.sendMessage(chatId, { 
            text: `┌─ *${botName}* ─┐\n│\n│ ✦ Oops! Magic fizzled: ${error.message}\n│\n└─────────────┘` 
        }, { quoted: fake });
    }
}

async function setbotnameCommand(sock, chatId, message, fullArgs) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const fake = createFakeContact(senderId);
        const currentBotName = getBotName();

        if (!message.key.fromMe) {
            await sock.sendMessage(chatId, { 
                text: `┌─ *${currentBotName}* ─┐\n│\n│ ✦ Only the captain can rename the ship!\n│\n└─────────────┘` 
            }, { quoted: fake });
            return;
        }

        // Use fullArgs from command parser (handles prefix+space correctly)
        // Fallback: parse raw text but skip the command word itself
        let name = (fullArgs || '').trim();
        if (!name) {
            const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
            const parts = text.trim().split(/\s+/);
            // Skip prefix+command (first token), rest is the name
            name = parts.slice(1).join(' ').trim();
        }

        if (!name) {
            await sock.sendMessage(chatId, { 
                text: `┌─ *${currentBotName}* ─┐
│
│ ✦ What shall we name the bot?
│
│ ✦ Usage:
│ .setbotname YourBotName
│
│ ✦ Example:
│ .setbotname MagicBot
│
└────────────────────┘` 
            }, { quoted: fake });
            return;
        }

        setBotName(name);
        
        const successMessages = [
            `┌─ *✨ NAME CHANGED* ─┐
│
│ ✦ The bot shall now be known as:
│ • *${name}*
│
│ ✦ A new identity, a new adventure!
│
└────────────────────┘`,
            
            `┌─ *✨ TRANSFORMATION* ─┐
│
│ ✦ Old name fades away...
│ ✦ New name rises: *${name}*
│
│ ✦ The bot has been reborn!
│
└────────────────────┘`,
            
            `┌─ *✨ RENAMED* ─┐
│
│ ✦ The magic now flows through:
│ • *${name}*
│
│ ✦ Great choice, captain!
│
└────────────────────┘`
        ];
        
        await sock.sendMessage(chatId, { 
            text: successMessages[Math.floor(Math.random() * successMessages.length)] 
        }, { quoted: fake });
        
    } catch (error) {
        console.error('Error in setbotname command:', error.message, 'Line:', error.stack?.split('\n')[1]);
        await sock.sendMessage(chatId, { 
            text: `┌─ *${currentBotName}* ─┐\n│\n│ ✦ Name change spell failed: ${error.message}\n│\n└─────────────┘` 
        }, { quoted: fake });
    }
}

async function setmenuimageCommand(sock, chatId, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const fake = createFakeContact(senderId);
        const botName = getBotName();

        if (!message.key.fromMe) {
            await sock.sendMessage(chatId, { 
                text: `┌─ *${botName}* ─┐\n│\n│ ✦ Only the owner can change the menu image!\n│\n└─────────────┘` 
            }, { quoted: fake });
            return;
        }

        const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
        const args = text.split(' ').slice(1).join(' ').trim();

        if (args && (args.startsWith('http://') || args.startsWith('https://'))) {
            setMenuImage(args);
            
            const urlSuccessMessages = [
                `┌─ *✨ MENU IMAGE* ─┐
│
│ ✦ Image URL captured!
│ ✦ Menu will now wear new clothes
│
│ ✦ URL: ${args.substring(0, 30)}...
│
└────────────────────┘`,
                
                `┌─ *✨ IMAGE SET* ─┐
│
│ ✦ Menu image URL has been stored
│ ✦ Beauty from the web, now yours
│
│ ✦ The menu has been adorned!
│
└────────────────────┘`
            ];
            
            await sock.sendMessage(chatId, { 
                text: urlSuccessMessages[Math.floor(Math.random() * urlSuccessMessages.length)] 
            }, { quoted: fake });
            return;
        }

        const hasImage = !!quotedMessage?.imageMessage;
        const hasVideo = !!quotedMessage?.videoMessage;

        if (!hasImage && !hasVideo) {
            await sock.sendMessage(chatId, { 
                text: `┌─ *${botName}* ─┐
│
│ ✦ What image shall grace the menu?
│
│ ✦ Ways to cast this spell:
│ • Reply to an image with .setmenuimage
│ • Reply to a video with .setmenuimage
│ • .setmenuimage https://example.com/image.jpg
│
│ ✦ Example:
│ (Reply to a photo or video) .setmenuimage
│
└────────────────────┘` 
            }, { quoted: fake });
            return;
        }

        try {
            // Show typing indicator while processing
            await sock.sendPresenceUpdate('composing', chatId);
            
            const assetsDir = path.join(__dirname, '..', 'assets');
            if (!fs.existsSync(assetsDir)) {
                fs.mkdirSync(assetsDir, { recursive: true });
            }

            if (hasVideo) {
                // Handle video: download and save as menu video (used with style 7)
                const stream = await downloadContentFromMessage(quotedMessage.videoMessage, 'video');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }
                const videoPath = path.join(assetsDir, 'menuvideo.mp4');
                fs.writeFileSync(videoPath, buffer);
                // Also save as GIF path reference for compatibility
                const { setMenuVideo } = require('../../davelib/botConfig');
                setMenuVideo(videoPath);
                await sock.sendMessage(chatId, { 
                    text: `┌─ *✨ VIDEO CAPTURED* ─┐\n│\n│ ✦ Menu video has been set!\n│ ✦ Use style 7 to display it\n│\n│ ✦ Stored at: assets/menuvideo.mp4\n│\n└────────────────────┘`
                }, { quoted: fake });
                return;
            }

            const stream = await downloadContentFromMessage(quotedMessage.imageMessage, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            const imagePath = path.join(assetsDir, 'menuimage.jpg');
            fs.writeFileSync(imagePath, buffer);

            setMenuImage(imagePath);
            
            const successMessages = [
                `┌─ *✨ IMAGE CAPTURED* ─┐
│
│ ✦ Menu image has been updated!
│ ✦ Your bot looks more fabulous than ever
│
│ ✦ Magic stored at: assets/menuimage.jpg
│
└────────────────────┘`,
                
                `┌─ *✨ VISUAL UPGRADE* ─┐
│
│ ✦ New menu image locked in!
│ ✦ Beauty has been added to the bot
│
│ ✦ The menu has been enchanted!
│
└────────────────────┘`,
                
                `┌─ *✨ IMAGE SET* ─┐
│
│ ✦ Your chosen image now graces the menu
│ ✦ Every .menu command will show it
│
│ ✦ Perfect choice, captain!
│
└────────────────────┘`
            ];
            
            await sock.sendMessage(chatId, { 
                text: successMessages[Math.floor(Math.random() * successMessages.length)] 
            }, { quoted: fake });
            
        } catch (downloadError) {
            await sock.sendMessage(chatId, { 
                text: `┌─ *${botName}* ─┐\n│\n│ ✦ Failed to download image: ${downloadError.message}\n│\n└─────────────┘` 
            }, { quoted: fake });
        }
    } catch (error) {
        console.error('Error in setmenuimage command:', error.message, 'Line:', error.stack?.split('\n')[1]);
        await sock.sendMessage(chatId, { 
            text: `┌─ *${botName}* ─┐\n│\n│ ✦ Image spell failed: ${error.message}\n│\n└─────────────┘` 
        }, { quoted: fake });
    }
}

module.exports = {
    setbotconfigCommand,
    setbotnameCommand,
    setmenuimageCommand
};