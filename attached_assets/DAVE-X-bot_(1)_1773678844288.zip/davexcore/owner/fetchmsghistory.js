const { createFakeContact, getBotName } = require('../../davelib/fakeContact');
const db = require('../../Database/database');

async function fetchmsghistoryCommand(sock, chatId, message, fullArgs) {
    const botName = getBotName();
    const senderId = message.key.participant || message.key.remoteJid;
    const fake = createFakeContact(senderId);

    const isOwner = message.key.fromMe || db.isSudo(senderId);
    if (!isOwner) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\n❌ Owner only command!`
        }, { quoted: fake });
    }

    const args = (fullArgs || '').trim();
    const count = parseInt(args) || 25;

    if (count < 1 || count > 100) {
        return sock.sendMessage(chatId, {
            text: `*${botName}*\nProvide a count between 1 and 100.\n\nUsage: fetchmsghistory <count>\nExample: fetchmsghistory 50`
        }, { quoted: fake });
    }

    // sock.fetchMessageHistory requires the oldest message key in the chat.
    // We find it from the quoted message, or fall back to a dummy key for the current chat.
    let oldestMsgKey = null;
    let oldestMsgTimestamp = Math.floor(Date.now() / 1000) - 86400; // 24 hours ago as default

    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedKey = message.message?.extendedTextMessage?.contextInfo;
    if (quotedKey?.stanzaId) {
        oldestMsgKey = {
            remoteJid: chatId,
            id: quotedKey.stanzaId,
            fromMe: quotedKey.participant ? false : true
        };
        oldestMsgTimestamp = quotedKey.quotedMessage?.timestamp || oldestMsgTimestamp;
    } else {
        oldestMsgKey = {
            remoteJid: chatId,
            id: message.key.id,
            fromMe: false
        };
    }

    try {
        const requestId = await sock.fetchMessageHistory(count, oldestMsgKey, oldestMsgTimestamp);

        await sock.sendMessage(chatId, {
            text: `┌─ *${botName} History Sync* ─┐\n│\n│ Request sent to WhatsApp.\n│ Requested: ${count} messages\n│ ID: ${requestId || 'sent'}\n│\n│ How it works:\n│ WhatsApp asks your phone to\n│ forward the history here.\n│ Your phone must be online.\n│\n│ Scroll up — new messages\n│ stream in over the next\n│ few seconds or minutes.\n│\n│ Note: Groups have limited\n│ history sync support.\n│\n└─────────────────────┘`
        }, { quoted: fake });
    } catch (err) {
        const msg = err.message || '';
        const hint = msg.includes('authenticated') || msg.includes('auth')
            ? 'Bot session needs to be re-authenticated.'
            : msg.includes('timeout')
            ? 'Request timed out. Your phone may be offline.'
            : msg;
        await sock.sendMessage(chatId, {
            text: `┌─ *${botName} History Sync* ─┐\n│\n│ Request failed:\n│ ${hint}\n│\n│ Try quoting an older message\n│ to set the starting point.\n│\n└─────────────────────┘`
        }, { quoted: fake });
    }
}

module.exports = { fetchmsghistoryCommand };
