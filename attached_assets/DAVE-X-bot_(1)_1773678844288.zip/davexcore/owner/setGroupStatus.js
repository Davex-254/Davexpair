const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const crypto = require('crypto');
const ffmpeg = require('fluent-ffmpeg');
const { PassThrough } = require('stream');
const { createFakeContact, getBotName } = require('../../davelib/fakeContact');

//================================================
// Sticker conversion (simple fallback)
//================================================
async function convertStickerToImageSimple(stickerBuffer) {
    if (stickerBuffer.slice(0, 12).toString('hex').includes('52494646')) { // RIFF header
        console.log('Detected WebP sticker, using fallback conversion');
        return stickerBuffer; 
    }
    return stickerBuffer;
}

async function convertStickerToImage(stickerBuffer, mimetype = 'image/webp') {
    try {
        return await convertStickerToImageSimple(stickerBuffer);
    } catch (error) {
        console.error('Sticker conversion failed:', error);
        throw new Error(`Sticker conversion failed: ${error.message}`);
    }
}

// ================================================
// Main command
// ================================================
async function setGroupStatusCommand(sock, chatId, msg) {
    // Create fake contact for replies
    const fake = createFakeContact(msg?.key?.participant || chatId);
    const botName = getBotName();
    
    try {
        // Group check
        const isGroup = chatId.endsWith('@g.us');
        if (!isGroup) {
            return sock.sendMessage(chatId, { 
                text: `┌─ *${botName}* ─┐\n│\n│ ✦ This magic only works in groups!\n│\n└─────────────┘` 
            }, { quoted: fake });
        }

        // Admin check
        const participant = await sock.groupMetadata(chatId).then(metadata =>
            metadata.participants.find(p => p.id === msg.key.participant || p.id === msg.key.remoteJid)
        );
        const isAdmin = participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
        
        if (!isAdmin && !msg.key.fromMe) {
            return sock.sendMessage(chatId, { 
                text: `┌─ *${botName}* ─┐\n│\n│ ✦ Sorry, only captains can steer the ship!\n│\n└─────────────┘` 
            }, { quoted: fake });
        }

        const messageText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
        const quotedMessage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const commandRegex = /^[.!#/]?(tosgroup|togstatus|swgc|groupstatus)\s*/i;

        let textAfterCommand = '';
        if (messageText.trim()) {
            const match = messageText.match(commandRegex);
            if (match) textAfterCommand = messageText.slice(match[0].length).trim();
        }

        if (!quotedMessage && !textAfterCommand) {
            return sock.sendMessage(chatId, { 
                text: getHelpText(botName) 
            }, { quoted: fake });
        }

        let payload = null;

        if (quotedMessage) {
            payload = await buildPayloadFromQuoted(quotedMessage);
            if (textAfterCommand && payload) {
                if (payload.video || payload.image || (payload.convertedSticker && payload.image)) {
                    payload.caption = textAfterCommand;
                }
            }
        } else if (textAfterCommand) {
            payload = { text: textAfterCommand };
        }

        if (!payload) {
            return sock.sendMessage(chatId, { 
                text: getHelpText(botName) 
            }, { quoted: fake });
        }

        // Send group status
        await sendGroupStatus(sock, chatId, payload);

        // Sweet response variations
        const mediaType = detectMediaType(quotedMessage, payload);
        const successMessages = [
            `┌─ *${botName}* ─┐\n│\n│ ✦ Status broadcasted! (${mediaType})`,
            `┌─ *${botName}* ─┐\n│\n│ ✦ Your story is live! (${mediaType})`,
            `┌─ *${botName}* ─┐\n│\n│ ✦ Everyone can see it now! (${mediaType})`,
            `┌─ *${botName}* ─┐\n│\n│ ✦ Magic posted to group! (${mediaType})`,
            `┌─ *${botName}* ─┐\n│\n│ ✦ Update shared with the crew! (${mediaType})`,
            `┌─ *${botName}* ─┐\n│\n│ ✦ Status update successful! (${mediaType})`
        ];
        
        let successMsg = successMessages[Math.floor(Math.random() * successMessages.length)];
        
        if (payload.caption) {
            const captionMessages = [
                `\n│ 📝 With message: "${payload.caption}"`,
                `\n│ 📝 Caption: ${payload.caption}`,
                `\n│ 📝 Says: ${payload.caption}`
            ];
            successMsg = successMsg.replace('─┐', '─┐') + captionMessages[Math.floor(Math.random() * captionMessages.length)];
        }
        
        if (payload.convertedSticker) {
            const stickerMessages = [
                `\n│ ✨ Sticker magically transformed!`,
                `\n│ ✨ Sticker → Image conversion complete`,
                `\n│ ✨ Your sticker is now a picture!`
            ];
            successMsg = successMsg.replace('─┐', '─┐') + stickerMessages[Math.floor(Math.random() * stickerMessages.length)];
        }
        
        successMsg += `\n│\n└─────────────┘`;
        successMsg = successMsg.replace('─┐\n│\n│', '─┐');

        await sock.sendMessage(chatId, { 
            text: successMsg 
        }, { quoted: fake });

    } catch (error) {
        console.error('Error in group status command:', error);
        
        // Sweet error variations
        const errorMessages = [
            `┌─ *${botName}* ─┐\n│\n│ ✦ Oops! Magic fizzled: ${error.message}\n│\n└─────────────┘`,
            `┌─ *${botName}* ─┐\n│\n│ ✦ Spell failed: ${error.message}\n│\n└─────────────┘`,
            `┌─ *${botName}* ─┐\n│\n│ ✦ Something went wrong: ${error.message}\n│\n└─────────────┘`,
            `┌─ *${botName}* ─┐\n│\n│ ✦ Couldn't cast that spell: ${error.message}\n│\n└─────────────┘`
        ];
        
        await sock.sendMessage(chatId, { 
            text: errorMessages[Math.floor(Math.random() * errorMessages.length)]
        }, { quoted: fake });
    }
}

/* ------------------ Helpers ------------------ */

// Magical help text
function getHelpText(botName) {
    const helpVariations = [
        `┌─ *${botName}* ─┐
│
│ ✦ Cast your spell:
│ • .tosgroup your message
│ • Reply to media + .tosgroup
│ • Reply to sticker (auto converts)
│
│ ✦ Works with:
│ Images · Videos · Audio · Stickers
│
│ ✦ Example:
│ Reply to a photo with .tosgroup Hello!
│
└────────────────────┘`,

        `┌─ *${botName}* ─┐
│
│ ✦ Share your magic:
│ • Text status: .tosgroup <text>
│ • Media status: Reply + .tosgroup
│ • Stickers become images automatically
│
│ ✦ Supported:
│ 🖼️ Image · 🎬 Video · 🎧 Audio · 📦 Sticker
│
│ ✦ Try:
│ Reply to a video with .tosgroup
│
└────────────────────┘`,

        `┌─ *${botName}* ─┐
│
│ ✦ Group Story Magic:
│ • Type .tosgroup + your words
│ • Reply to any image/video/audio
│ • Stickers transform into images
│
│ ✦ Compatible with:
│ All media types welcome!
│
│ ✦ Example:
│ .tosgroup Good morning everyone!
│
└────────────────────┘`
    ];
    
    return helpVariations[Math.floor(Math.random() * helpVariations.length)];
}

// Build payload from quoted message
async function buildPayloadFromQuoted(quotedMessage) {
    if (quotedMessage.videoMessage) {
        const buffer = await downloadToBuffer(quotedMessage.videoMessage, 'video');
        return { 
            video: buffer, 
            caption: quotedMessage.videoMessage.caption || '',
            gifPlayback: quotedMessage.videoMessage.gifPlayback || false,
            mimetype: quotedMessage.videoMessage.mimetype || 'video/mp4'
        };
    } else if (quotedMessage.imageMessage) {
        const buffer = await downloadToBuffer(quotedMessage.imageMessage, 'image');
        return { 
            image: buffer, 
            caption: quotedMessage.imageMessage.caption || '',
            mimetype: quotedMessage.imageMessage.mimetype || 'image/jpeg'
        };
    } else if (quotedMessage.audioMessage) {
        const buffer = await downloadToBuffer(quotedMessage.audioMessage, 'audio');
        if (quotedMessage.audioMessage.ptt) {
            const audioVn = await toVN(buffer);
            return { audio: audioVn, mimetype: "audio/ogg; codecs=opus", ptt: true };
        } else {
            return { audio: buffer, mimetype: quotedMessage.audioMessage.mimetype || 'audio/mpeg', ptt: false };
        }
    } else if (quotedMessage.stickerMessage) {
        try {
            const buffer = await downloadToBuffer(quotedMessage.stickerMessage, 'sticker');
            const imageBuffer = await convertStickerToImage(buffer, quotedMessage.stickerMessage.mimetype);
            return { 
                image: imageBuffer, 
                caption: quotedMessage.stickerMessage.caption || '',
                mimetype: 'image/png',
                convertedSticker: true,
                originalMimetype: quotedMessage.stickerMessage.mimetype
            };
        } catch (conversionError) {
            console.error('Sticker conversion failed:', conversionError);
            
            const errorMsgs = [
                `✦ Couldn't transform that sticker (${quotedMessage.stickerMessage.mimetype || 'unknown'})`,
                `✦ Sticker resisted the magic (${quotedMessage.stickerMessage.mimetype || 'unknown'})`,
                `✦ Unsupported sticker format (${quotedMessage.stickerMessage.mimetype || 'unknown'})`
            ];
            return { text: errorMsgs[Math.floor(Math.random() * errorMsgs.length)] };
        }
    } else if (quotedMessage.conversation || quotedMessage.extendedTextMessage?.text) {
        const textContent = quotedMessage.conversation || quotedMessage.extendedTextMessage?.text || '';
        return { text: textContent };
    }
    return null;
}

// Detect media type
function detectMediaType(quotedMessage, payload = null) {
    if (!quotedMessage) return 'Text';
    if (quotedMessage.videoMessage) return 'Video';
    if (quotedMessage.imageMessage) return 'Image';
    if (quotedMessage.audioMessage) return 'Audio';
    if (quotedMessage.stickerMessage) {
        if (payload && payload.convertedSticker) return 'Sticker ✦ Image';
        return 'Sticker';
    }
    return 'Text';
}

// Download message content
async function downloadToBuffer(message, type) {
    const stream = await downloadContentFromMessage(message, type);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
    return buffer;
}

// Send group status
async function sendGroupStatus(conn, jid, content) {
    const { generateWAMessageContent, generateWAMessageFromContent } = require('@whiskeysockets/baileys');
    
    const inside = await generateWAMessageContent(content, { upload: conn.waUploadToServer });
    const messageSecret = crypto.randomBytes(32);
    const m = generateWAMessageFromContent(jid, {
        messageContextInfo: { messageSecret },
        groupStatusMessageV2: { message: { ...inside, messageContextInfo: { messageSecret } } }
    }, {});
    
    await conn.relayMessage(jid, m.message, { messageId: m.key.id });
    return m;
}

// Convert audio to voice note
async function toVN(inputBuffer) {
    return new Promise((resolve, reject) => {
        const inStream = new PassThrough();
        inStream.end(inputBuffer);
        const outStream = new PassThrough();
        const chunks = [];
        
        ffmpeg(inStream)
            .noVideo()
            .audioCodec("libopus")
            .format("ogg")
            .audioBitrate("48k")
            .audioChannels(1)
            .audioFrequency(48000)
            .on("error", reject)
            .on("end", () => resolve(Buffer.concat(chunks)))
            .pipe(outStream, { end: true });
            
        outStream.on("data", chunk => chunks.push(chunk));
    });
}

module.exports = setGroupStatusCommand;