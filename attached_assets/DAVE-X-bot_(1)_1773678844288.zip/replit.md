# DAVE-X WhatsApp Bot

## Overview
A WhatsApp bot built with Node.js and @whiskeysockets/baileys ^7.0.0-rc.9. Features an Express web server on port 5000 (status page), SQLite + optional PostgreSQL storage, and a wide range of automation, moderation, media, and AI commands.

## Recent Changes (Session Mar 2026)
- **Anti-spam cooldown**: Created `davelib/antiWarnCooldown.js` — shared 30s per-user per-group cooldown for warning messages. Applied to antisticker, antivideo, antiimage, antiaudio, antidocument, antibadword, antilink. Messages are still deleted immediately; only the warning text is throttled.
- **AI command styling**: `aiGpt4.js` (`.ai`) and `ai.js` (`.gemini`) now use DAVE-X bordered format `┌─ *DAVE-X AI* ─┐ … └─────────────────┘`. Both commands fixed to use `args` from dave.js instead of raw message text parsing.
- **Browser string**: Updated from `["Ubuntu", "Chrome", "20.0.04"]` to `["Ubuntu", "Chrome", "126.0.6478.127"]` (correct realistic Chrome version).
- **cedit command**: New `.cedit <new text>` command — quote any bot message then use cedit to edit it via Baileys v7 `{ text, edit: key }` API. File: `davexcore/utility/cedit.js`.
- **chatModify error messages**: Improved pin/unpin/archive/unarchive error messages for WA Business app state errors — now gives actionable guidance.

## Architecture
- **index.js** — Main entry point: Express web server, session management, Baileys socket setup, connection/event handling
- **dave.js** — Core message handler (3000+ lines): command router, all bot logic
- **davexcore/** — Feature modules organized by category:
  - `automation/` — alwaysonline, autostatus, autoread, welcome, goodbye, etc.
  - `anti/` — antidelete, antiedit, antilink, antikick, etc.
  - `group/` — tagall, promote, kick, warn, mute, etc.
  - `owner/` — help, setprefix, setowner, menuManage, etc.
- **davelib/** — Shared utilities: fakeContact, greetings, botConfig, server.html
- **Database/** — SQLite (primary) + PostgreSQL (settings sync), settingsStore

## Key Configuration
- Session stored in `./session/` (configurable via `SESSION_PATH` env var)
- Settings in SQLite at `./storage/davex.db`
- Environment variables via `.env` file

## SESSION_ID — Critical Notes
- SESSION_ID **only** contains `creds.json` (account identity). It does NOT save Signal sender-key sessions or per-contact Signal sessions.
- Never delete the `./session/` folder unless WhatsApp explicitly logged out (401/403/419). The session files that accumulate there (`pre-key-*.json`, `session-*.json`, `sender-key-*.json`) are required for message decryption.
- After any session clear + restore from SESSION_ID: expect a history sync of `type=append` messages that all fail to decrypt (unavoidable — those used old Signal sessions). Only `type=notify` (live) messages will decrypt using the fresh pre-keys.
- To update SESSION_ID: use the Replit Secrets panel (lock icon in sidebar) and update `SESSION_ID`. Bot auto-detects the change via MD5 fingerprint and downloads the new session.
- `.env` override is enabled (`override: true`) — if `SESSION_ID` is set in `.env`, it takes precedence over Replit secrets.

## SESSION_ID — Deployment Guide
- After connecting, the bot writes the current session to `new_session_id.txt` in the project root.
- Copy that file's content and set it as the `SESSION_ID` env var (shared) — this ensures the bot survives restarts without re-pairing.
- The bot auto-detects a changed SESSION_ID via MD5 fingerprint and downloads the new session on restart.
- To deploy for someone else: get their `DAVE-X:~<base64>` session string, set it as SESSION_ID, restart.
- NEVER clear the `./session/` folder manually — only WhatsApp's 401/403/419 logout should trigger a clear.

## Recent Changes
### 2026-03-09 (Session 3)
1. **Reaction flood fix** (dave.js): Reactions no longer trigger the verbose INCOMING TRANSMISSION banner. This was causing massive log spam and CPU/memory waste on every group emoji reaction. Reactions are still counted for zombie detection.
2. **`getName()` fixed** (dave.js): Now checks `global.pushNameCache` first before falling back to phone number. Commands that used to show "Unknown" now display the real name.
3. **`.filter vcf` routing fixed** (dave.js): `.filter vcf <query>` now correctly routes to the VCF filter command. Also added support for replying to a VCF document file with `.filter vcf <query>` to filter contacts from that specific file.
4. **VCF names fixed** (davexcore/utility/vcf.js): Contacts no longer default to "Dave x 🔐". Now uses pushName cache first, then participant.notify, then `Contact +<phone>` as fallback.
5. **`.mychannels` command added** (davexcore/owner/mychannels.js): New command to follow/unfollow/list/mute WhatsApp channels the bot manages. Usage: `.mychannels`, `.mychannels follow <link>`, `.mychannels unfollow <number>`, `.mychannels mute/unmute <number>`.
6. **Session auto-export** (index.js): On every successful connection, bot writes current session to `new_session_id.txt`. Makes it easy to update SESSION_ID after pairing.
7. **`safeRequire()` helper added** (dave.js): Command module load failures now log an error instead of crashing the entire bot.
8. **Pino level restored to silent** (index.js): Diagnostic `warn` level and `[RAW]` logging removed.
9. **SESSION_ID** stored as shared env var (updated after each successful connection automatically).

### 2026-03-09 (Session 2)
1. **`isLidJid` fixed** (davelib/lidResolver.js): Was using heuristics that incorrectly flagged newsletter JIDs. Now correctly checks only for `@lid` suffix.
2. **dotenv override enabled** (index.js): `.env` file values now take precedence over Replit secrets.
3. **`type=notify` guard** (index.js): Bot now skips `type=append` (history replay) messages to prevent error 479 flood.
4. **Stale-session re-pair mode** (index.js): `isStaleSession && !sessionExists()` calls `getLoginMethod()` instead of looping 30s + exiting.

### 2026-03-06
1. **Panel login fix** (index.js): No longer hard-exits when no TTY. If `BOT_NUMBER` or `OWNER_NUMBER` is in `.env`, auto-uses pairing code on panels. Otherwise waits 30s with helpful message.
2. **Session ID change detection** (index.js): Added MD5 fingerprint (`session_fingerprint.txt`) — when `SESSION_ID` in `.env` changes, automatically clears old session and downloads new one.
3. **Removed antiviewonce from message hot-path** (dave.js): `handleAntiviewonce` was called on every single message. Removed from hot path; `.vv` / `.viewonce` commands still work.
4. **alwaysonline no longer starts by default** (alwaysonline.js): `initPresenceOnConnect` no longer auto-starts the presence loop. Only starts if user explicitly configured alwaysonline/alwaysoffline via command.
5. **AI menu trimmed to 3 commands** (help.js): Help menu AI section now shows only `.ai`, `.gemini`, `.vision`. All other AI command handlers still exist but are unlisted.
6. **Default menu style changed to text-only** (menuManage.js): Default changed from style '1' (document) to style '2' (plain text). Long text automatically gets a WhatsApp "read more" collapse button.
7. **Welcome uses person's profile picture** (welcome.js): Fixed — `avatarUrl` (joining person's own pp) is now used as the thumbnail, falling back to group picture if no pp set.
8. **Goodbye uses person's profile picture** (goodbye.js): Added person pp fetch; goodbye message now shows the leaving person's photo, with group pic as fallback.
9. **Anti-feature detection made non-blocking** (dave.js): All anti-feature checks (antilink, antibadword, antisticker, antiimage, etc.) were sequentially `await`ed before commands could run. All moved to `setImmediate` fire-and-forget — commands now respond immediately.
10. **Autoreact to status fixed** (autostatus.js): Updated `reactToStatus` to use `sock.sendMessage` with proper `react` + `statusJidList` (Baileys v7 method), with fallback to `relayMessage` for compatibility.

## Workflow
- **Start application**: `node shadowmd/index.js` — DAVEX MINI (Shadow MD) is now the primary running bot

## Shadow MD (DAVEX MINI) — shadowmd/
- **Entry**: `shadowmd/index.js` loads Telegram bot (bot.js) + WhatsApp commands (drenox.js)
- **Pairing**: done via Telegram bot. `pair.js` handles the WhatsApp Baileys connection.
- **Settings**: `settings.js` — per-session persistent key/value via `database/botSettings.json`
- **Commands**: `drenox.js` (13000+ lines), all commands routing with `getSetting`/`setSetting`

### Key Fixes (2026-03-07)
1. **Autoview/autoreact status** (pair.js): Now handled IN pair.js before passing to drenox (which returned early for status@broadcast). Uses `bad.signalRepository.lidMapping.getPNForLID(lid)` for LID→phone JID resolution (same as DAVE-X fix).
2. **Per-session settings** (drenox.js): `autoview`/`autolike`/`statusemoji` commands now use `setSetting(sessionKey, ...)` where `sessionKey = bad.user.id.split(':')[0]` — each bot session has isolated, file-persisted settings. No more shared globals.
3. **All relative fs paths fixed** (drenox.js): `process.chdir(__dirname)` at top so `./allfunc/...` paths resolve to `shadowmd/`. `pair.js` uses `SESSION_DIR = path.join(__dirname, ...)`.
4. **ANTIHIJACK_DB crash fixed** (drenox.js): Variable was commented out but still referenced — now properly declared.
5. **Media files fixed**: Copied from `media /` (trailing space) to correct `media/` directory.
6. **Ping command**: Returns only bot name + speed, quoted via fakeContact vCard.
7. **Default botmode**: public (via `allfunc/botmode.txt` = 'public').
8. **Unicode fonts removed** from index.js startup banner.
