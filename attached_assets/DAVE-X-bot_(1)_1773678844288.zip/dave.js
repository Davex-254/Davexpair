const getName = (jid) => {
    const raw = (jid || '').split('@')[0].split(':')[0];
    if (global.pushNameCache) {
        const cached = global.pushNameCache.get(raw);
        if (cached) return cached;
    }
    const contact = store?.contacts[jid] || {};
    return contact.notify || contact.name || raw;
};
const path = require('path');
const fs = require('fs');
const chalk = require('chalk').default || require('chalk');

function safeRequire(modulePath, fallback = {}) {
    try {
        return require(modulePath);
    } catch (e) {
        const label = modulePath.split('/').pop();
        console.error(`[ DAVE-X ] ❌ Failed to load module "${label}": ${e.message}`);
        if (typeof fallback === 'function') return fallback;
        return Object.assign(function noop() {}, fallback);
    }
}

// ========== TEMP FOLDER SETUP ==========

const customTemp = path.join(process.cwd(), 'temp');
if (!fs.existsSync(customTemp)) fs.mkdirSync(customTemp, { recursive: true });
process.env.TMPDIR = customTemp;
process.env.TEMP = customTemp;
process.env.TMP = customTemp;

// Clean temp folder every 1 hour
setInterval(() => {
    if (!fs.existsSync(customTemp)) return;
    
    fs.readdir(customTemp, (err, files) => {
        if (err) return;
        for (const file of files) {
            const filePath = path.join(customTemp, file);
            fs.stat(filePath, (err, stats) => {
                if (!err && Date.now() - stats.mtimeMs > 60 * 60 * 1000) {
                    fs.unlink(filePath, () => {});
                }
            });
        }
    });
}, 60 * 60 * 1000);
// Store original console.log (before any overrides from index.js)
const originalConsoleLog = console.log;

// ========== GROUP NAME & LID RESOLUTION CACHES ==========
const groupNameCache = new Map();
const GROUP_CACHE_TTL = 5 * 60 * 1000;
const MAX_GROUP_CACHE = 100;
setInterval(() => { if (groupNameCache.size > MAX_GROUP_CACHE) groupNameCache.clear(); }, 10 * 60 * 1000);
function getGroupNameSync(chatId) {
    const cached = groupNameCache.get(chatId);
    if (cached) return cached.name;
    return chatId.split('@')[0];
}
function refreshGroupNameCache(sock, chatId) {
    const cached = groupNameCache.get(chatId);
    if (cached && Date.now() - cached.ts < GROUP_CACHE_TTL) return;
    sock.groupMetadata(chatId).then(meta => {
        const name = meta?.subject || chatId.split('@')[0];
        groupNameCache.set(chatId, { name, ts: Date.now() });
    }).catch(() => {});
}

// ========== LID RESOLUTION (shared module) ==========
const {
    lidPhoneCache,
    cacheLidPhone,
    resolvePhoneFromLid,
    resolveSenderFromGroup,
    isLidJid
} = require('./davelib/lidResolver');

// ── resolveParticipantNumber (sync-first, async group fallback) ────────
async function resolveParticipantNumber(sock, participant) {
    if (!participant) return '';
    const num = participant.split('@')[0].split(':')[0];
    if (isLidJid(participant)) {
        const resolved = resolvePhoneFromLid(participant, sock);
        if (resolved) return resolved;
        if (sock) {
            const fromGroup = await resolveSenderFromGroup(participant, null, sock);
            if (fromGroup) return fromGroup;
        }
    }
    return num;
}

// ========== GLITCH TEXT FUNCTION ==========
const glitchText = (text) => {
    return chalk.hex('#00ffff').bold(text) + chalk.hex('#ff00ff')('_');
};

// ========== MODULE IMPORTS ==========
const { getBotName, createFakeContact } = require('./davelib/fakeContact');
const settings = require('./daveset');
require('./config.js');
const { isBanned } = require('./davelib/isBanned');
const yts = require('yt-search');
const { fetchBuffer, smsg, fetchJson, sleep, formatSize, randomKarakter } = require('./davelib/myfunc');
const fetch = require('node-fetch');
const ytdl = require('ytdl-core');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const { jidDecode } = require('@whiskeysockets/baileys');
const { isSudo } = require('./davelib/index');
const { registerContact, getAllContacts } = require('./davelib/contactRegistry');
const isAdmin = require('./davelib/isAdmin');

// Message Handler
const {
    getMessageText,
    isEditedMessage,
    getEditedMessageText,
    extractCommand,
    shouldProcessEditedMessage
} = require('./davelib/messageHandler');

// ========== COMMAND IMPORTS ==========

// === CORE & BOT MANAGEMENT ===
const { getPrefix, handleSetPrefixCommand } = require('./davexcore/owner/setprefix');
const { getOwnerName, handleSetOwnerCommand } = require('./davexcore/owner/setowner');
const { 
    setbotconfigCommand,
    setbotnameCommand,
    setmenuimageCommand 
} = require('./davexcore/owner/setbotconfig');
const ownerCommand = require('./davexcore/owner/owner');
const pingCommand = require('./davexcore/owner/ping');
const aliveCommand = require('./davexcore/owner/alive');
const updateCommand = require('./davexcore/owner/update');
const settingsCommand = require('./davexcore/owner/settings');
const { sudoCommand } = require('./davexcore/owner/sudo');
const clearSessionCommand = require('./davexcore/owner/clearsession');
const mygroupsCommand = require('./davexcore/owner/mygroups');
const savecontactCommand = require('./davexcore/owner/savecontact');
const { updatenotifyCommand } = require('./davexcore/owner/updatenotify');
const { menuManageCommand } = require('./davexcore/owner/menuManage');
const helpCommand = require('./davexcore/owner/help');
const bioCommand = require('./davexcore/owner/bio');
const setfontCommand = require('./davexcore/owner/setfont');
const { pinchatCommand, unpinchatCommand } = require('./davexcore/owner/pinchat');
const disappearCommand = require('./davexcore/group/disappear');

// === MODERATION COMMANDS ===
const banCommand = require('./davexcore/group/ban');
const unbanCommand = require('./davexcore/group/unban');
const muteCommand = require('./davexcore/group/mute');
const unmuteCommand = require('./davexcore/group/unmute');
const kickCommand = require('./davexcore/group/kick');
const warnCommand = require('./davexcore/group/warn');
const warningsCommand = require('./davexcore/group/warnings');
const { promoteCommand, handlePromotionEvent } = require('./davexcore/group/promote');
const { demoteCommand, handleDemotionEvent } = require('./davexcore/group/demote');
const { createeventCommand } = require('./davexcore/group/createevent');
const { memberlabelCommand } = require('./davexcore/group/memberlabel');
const { pinmsgCommand, unpinmsgCommand } = require('./davexcore/group/pinmsg');
const { clearCommand, handleClearCommand } = require('./davexcore/group/clear');
const kickAllCommand = require('./davexcore/group/kickall');
const { blockCommand, unblockCommand, blocklistCommand, unblockallCommand } = require('./davexcore/group/blockUnblock');
const { removeProfilePicCommand, setProfilePicPrivacyCommand } = require('./davexcore/owner/profilepic');

// === GROUP MANAGEMENT ===
const groupInfoCommand = require('./davexcore/group/groupinfo');
const staffCommand = require('./davexcore/group/staff');
const resetlinkCommand = require('./davexcore/group/resetlink');
const linkgroupCommand = require('./davexcore/group/linkgroup');
const creategroupCommand = require('./davexcore/group/creategroup');
const leaveGroupCommand = require('./davexcore/group/leave');
const { 
    setGroupDescription, 
    setGroupName, 
    setGroupPhoto 
} = require('./davexcore/group/groupmanage');
const {
    groupLockCommand,
    groupUnlockCommand,
    groupCloseCommand,
    groupOpenCommand,
    addModeCommand,
    joinApprovalCommand
} = require('./davexcore/group/groupsettings');
const { tagAllCommand } = require('./davexcore/group/tagall');
const tagCommand = require('./davexcore/group/tag');
const tagNotAdminCommand = require('./davexcore/group/tagnotadmin');
const hideTagCommand = require('./davexcore/group/hidetag');
const { addMemberCommand } = require('./davexcore/group/addmember');

// === ANTI-FEATURES ===
const { handleAntiLinkDetection, handleAntilinkCommand } = require('./davexcore/anti/antilink');
const { handleAntiStatusMention, antigroupmentionCommand } = require('./davexcore/anti/antigroupmention');
const { handleChartDetection, antichartCommand } = require('./davexcore/anti/antichart');
const { antiforwardCommand, handleForwardDetection } = require('./davexcore/anti/antiforward');
const { handleAntitagCommand, handleTagDetection } = require('./davexcore/anti/antitag');
const { handleAntiBadwordCommand, handleBadwordDetection, antibadwordCommand } = require('./davexcore/anti/antibadword');
const { handleMentionDetection, mentionToggleCommand, setMentionCommand } = require('./davexcore/anti/mention');
const { antimentionCommand, handleMentionDetection: handleNewMentionDetection } = require('./davexcore/anti/antimention');
const { antipromoteCommand, handleAntipromote } = require('./davexcore/anti/antipromote');
const { antidemoteCommand, handleAntidemote } = require('./davexcore/anti/antidemote');
const { antibugCommand, handleBugDetection } = require('./davexcore/anti/antibug');
const { antibugDmCommand, handleAntibugDm } = require('./davexcore/anti/antibugdm');
const { antibotCommand, handleAntibotDetection } = require('./davexcore/anti/antibot');
const { antivirtexCommand, handleAntivirtexDetection } = require('./davexcore/anti/antivirtex');
const { antivideoCommand, handleVideoDetection } = require('./davexcore/anti/antivideo');
const { antidocumentCommand, handleDocumentDetection } = require('./davexcore/anti/antidocument');
const { antifilesCommand, handleFilesDetection } = require('./davexcore/anti/antifiles');
const { antistickerCommand, handleStickerDetection } = require('./davexcore/anti/antisticker');
const { antiimageCommand, handleImageDetection } = require('./davexcore/anti/antiimage');
const { antiaudioCommand, handleAudioDetection } = require('./davexcore/anti/antiaudio');
const { antikickCommand, handleAntikick, getGroupConfig: getAntikickConfig } = require('./davexcore/anti/antikick');
const { getGroupConfig } = require('./Database/settingsStore');
const { getBotMode, setBotMode } = require('./Database/database');
const { handleAntideleteCommand, handleMessageRevocation, storeMessage } = require('./davexcore/anti/antidelete');
const { antieditCommand, storeOriginalMessage, handleEditedMessage, handleMessageUpdate } = require('./davexcore/anti/antiedit');
const { handleAntiviewonce, antiviewonceCommand } = require('./davexcore/anti/antiviewonce');

// === AUTOMATION FEATURES ===
const { autotypingCommand, isAutotypingEnabled, handleAutotypingForMessage } = require('./davexcore/automation/autotyping');
const { autoreadCommand, isAutoreadEnabled, handleAutoread } = require('./davexcore/automation/autoread');
const { autorecordingCommand, isAutorecordingEnabled, handleAutorecordingForMessage } = require('./davexcore/automation/autorecording');
const { autoStatusCommand, handleStatusUpdate } = require('./davexcore/automation/autostatus');
const { autobioCommand, startAutoBio } = require('./davexcore/automation/autobio');
const { newsletterreactCommand } = require('./davexcore/automation/newsletterreact');
const { welcomeCommand, handleJoinEvent } = require('./davexcore/automation/welcome');
const { goodbyeCommand, handleLeaveEvent } = require('./davexcore/automation/goodbye');
const { handleChatbotCommand, handleChatbotResponse } = require('./davexcore/automation/chatbot');
const { addCommandReaction, handleAutoreactForMessage, handleAreactCommand } = require('./davelib/reactions');
const { incrementMessageCount, topMembers } = require('./davexcore/group/topmembers');
const { pmblockerCommand, readState: readPmBlockerState } = require('./davexcore/group/pmblocker');
const { anticallCommand, setcallmsgCommand, handleIncomingCall, readState: readAnticallState } = require('./davexcore/anti/anticall');
const { groupanticallCommand, handleGroupCall } = require('./davexcore/anti/groupanticall');
const { startupWelcomeCommand } = require('./davexcore/owner/startupwelcome');
const { broadcastCommand } = require('./davexcore/owner/broadcast');
const { pinCommand, unpinCommand, archiveCommand, unarchiveCommand, disappearingCommand } = require('./davexcore/automation/chatmanage');
const { autoreadReceiptsCommand } = require('./davexcore/automation/autoReadReciepts');
const lastseenCommand = require('./davexcore/utility/lastseen');


// === MEDIA & ENTERTAINMENT ===
const stickerCommand = require('./davexcore/media/sticker');
const simageCommand = require('./davexcore/media/simage');
const attpCommand = require('./davexcore/media/attp');
const emojimixCommand = require('./davexcore/media/emojimix');
const stickerTelegramCommand = require('./davexcore/media/stickertelegram');
const stickercropCommand = require('./davexcore/media/stickercrop');
const { qcCommand } = require('./davexcore/media/quotesticker');
const ttsCommand = require('./davexcore/media/tts');
const memeCommand = require('./davexcore/media/meme');
const { songCommand, processSongDownload } = require('./davexcore/downloads/song');
const { getPending: getSongPending } = require('./davelib/songPending');
const videoCommand = require('./davexcore/downloads/video');
const playCommand = require('./davexcore/downloads/play');
const { ytplayCommand, ytsongCommand } = require('./davexcore/downloads/ytdl');
const ytsCommand = require('./davexcore/downloads/yts');
const { tiktokCommand, processTiktokDownload } = require('./davexcore/downloads/tiktok');
const { getTiktokPending } = require('./davelib/tiktokPending');
const spotifyCommand = require('./davexcore/downloads/spotify');
const ytdocvideoCommand = require('./davexcore/downloads/ytdocvideo');
const ytdocplayCommand = require('./davexcore/downloads/ytdocplay');
const shazamCommand = require('./davexcore/media/shazam');
const instagramCommand = require('./davexcore/downloads/instagram');
const { igsCommand } = require('./davexcore/downloads/igs');
const facebookCommand = require('./davexcore/downloads/facebook');
const movieCommand = require('./davexcore/utility/movie');
const { animeCommand } = require('./davexcore/media/anime');
const { piesCommand, piesAlias } = require('./davexcore/media/pies');
const imagineCommand = require('./davexcore/ai/imagine');
const mediafireCommand = require('./davexcore/downloads/mediafire');

// === AI & TOOLS ===
const aiCommand = require('./davexcore/ai/ai');
const visionCommand = require('./davexcore/ai/vision');
const locationCommand = require('./davexcore/utility/location');
const shareLocationCommand = require('./davexcore/utility/sharelocation');
const pollCommand = require('./davexcore/utility/poll');
const gpt4Command = require('./davexcore/ai/aiGpt4');
const { handleTranslateCommand } = require('./davexcore/utility/translate');
const { handleSsCommand } = require('./davexcore/utility/ss');
const googleCommand = require('./davexcore/utility/google');
const { githubCommand, processGithubZip, getGithubPending } = require('./davexcore/utility/github');
const gitcloneCommand = require('./davexcore/downloads/gitclone');
const apkCommand = require('./davexcore/downloads/apk');
const urlCommand = require('./davexcore/utility/url');
const { shortenUrlCommand } = require('./davexcore/utility/tinyurl');
const { analyzeCommand } = require('./davexcore/ai/analyze');
const encryptCommand = require('./davexcore/utility/encrypt');
const fetchCommand = require('./davexcore/utility/fetch');
const removebgCommand = require('./davexcore/media/removebg');
const { reminiCommand } = require('./davexcore/media/remini');
const { nightCommand, prettyCommand, uglyCommand } = require('./davexcore/media/imageedit');
const blurCommand = require('./davexcore/media/img-blur');
const textmakerCommand = require('./davexcore/media/textmaker');
const characterCommand = require('./davexcore/ai/character');
const wastedCommand = require('./davexcore/media/wasted');
const setProfilePicture = require('./davexcore/media/setpp');
const getppCommand = require('./davexcore/media/getpp');
const viewOnceCommand = require('./davexcore/media/viewonce');
const toAudioCommand = require('./davexcore/media/toAudio');
const setGroupStatusCommand = require('./davexcore/owner/setGroupStatus');
const imageCommand = require('./davexcore/media/image');
const hijackCommand = require('./davexcore/owner/hijack');

// === GAMES & FUN ===
const { startHangman, guessLetter } = require('./davexcore/games/hangman');
const { startTrivia, answerTrivia } = require('./davexcore/games/trivia');
const { tictactoeCommand, tictactoeAICommand, handleTicTacToeMove, handleTicTacToeJoin, tictactoeEndCommand } = require('./davexcore/games/tictactoe');
const { connectFourCommand, handleConnectFourMove } = require('./davexcore/games/connect4');
const { wcgCommand, wcgAICommand, wcgBeginCommand, wcgEndCommand, wcgScoresCommand, handleWcgJoin, handleWcgWord, hasWcgGame, hasWaitingWcgGame } = require('./davexcore/games/wordchain');
const { diceCommand, diceAICommand, handleDiceJoin, handleDiceBegin, handleDiceRoll, diceEndCommand, hasDiceGame } = require('./davexcore/games/dice');
const { acceptCommand, rejectCommand, acceptAllCommand, rejectAllCommand, listRequestsCommand } = require('./davexcore/group/joinrequests');
const tagAdminsCommand = require('./davexcore/group/tagadmins');
const onlineCommand = require('./davexcore/group/online');
const { setBotOnlineCommand, setBotOfflineCommand, setTypingCommand, setRecordingCommand, stopPresenceCommand } = require('./davexcore/automation/botpresence');
const { showPrivacyCommand, onlinePrivacyCommand, callPrivacyCommand, readReceiptsCommand, groupsPrivacyCommand, statusPrivacyCommand, ppPrivacyCommand, msgPrivacyCommand, linkPreviewsPrivacyCommand } = require('./davexcore/owner/privacy');
const jokeCommand = require('./davexcore/misc/joke');
const quoteCommand = require('./davexcore/misc/quote');
const factCommand = require('./davexcore/misc/fact');
const { complimentCommand } = require('./davexcore/misc/compliment');
const { insultCommand } = require('./davexcore/misc/insult');
const { eightBallCommand } = require('./davexcore/games/eightball');
const { lyricsCommand } = require('./davexcore/utility/lyrics');
const { dareCommand } = require('./davexcore/misc/dare');
const { truthCommand } = require('./davexcore/misc/truth');
const { flirtCommand } = require('./davexcore/misc/flirt');
const shipCommand = require('./davexcore/games/ship');
const { simpCommand } = require('./davexcore/misc/simp');
const { stupidCommand } = require('./davexcore/misc/stupid');
const pairCommand = require('./davexcore/owner/pair');

// === UTILITIES ===
const deleteCommand = require('./davexcore/utility/delete');
const editmsgCommand = require('./davexcore/utility/editmsg');
const weatherCommand = require('./davexcore/utility/weather');
const newsCommand = require('./davexcore/utility/news');
const channelidCommand = require('./davexcore/owner/channelid');
const { chaneljidCommand } = require('./davexcore/owner/chanel');
const { newsletterCommand } = require('./davexcore/owner/newsletter');
const { bizprofileCommand } = require('./davexcore/owner/bizprofile');
const { fetchmsghistoryCommand } = require('./davexcore/owner/fetchmsghistory');
const { mychannelsCommand, trackChannel } = require('./davexcore/owner/mychannels');
const vcfCommand = require('./davexcore/utility/vcf');
const wallpaperCommand = require('./davexcore/media/wallpaper');
const takeCommand = require('./davexcore/media/take');
const clearTmpCommand = require('./davexcore/utility/cleartmp');
const { tostatusCommand } = require('./davexcore/media/tostatus');
const saveStatusCommand = require('./davexcore/downloads/saveStatus');
const vv2Command = require('./davexcore/media/vv2');
const { vnCommand } = require('./davexcore/media/vn');

// === MISC COMMANDS ===
const { miscCommand } = require('./davexcore/misc/misc');
const { goodnightCommand } = require('./davexcore/misc/goodnight');
const { shayariCommand } = require('./davexcore/misc/shayari');
const { rosedayCommand } = require('./davexcore/misc/roseday');

// === SPORTS ===
const {
    eplStandingsCommand,
    bundesligaStandingsCommand,
    laligaStandingsCommand,
    serieAStandingsCommand,
    ligue1StandingsCommand,
    matchesCommand
} = require('./davexcore/utility/sports');

// === RELIGIOUS ===
const {
    bibleCommand,
    bibleListCommand,
    quranCommand
} = require('./davexcore/utility/bible');

// === DEV REACT ===
const handleDevReact = require('./davexcore/automation/devReact');

// === NEW COMMANDS ===
const joinCommand = require('./davexcore/utility/join');
const dalleCommand = require('./davexcore/ai/dalle');
const aivideoCommand = require('./davexcore/ai/aivideo');
const { goodmorningCommand, goodafternoonCommand, goodeveningCommand } = require('./davexcore/automation/greetings');
const { logoCommand, carbonCommand } = require('./davexcore/media/design');
const { tomp4Command } = require('./davexcore/media/tomp4');
const { togifCommand } = require('./davexcore/media/togif');
const toimgCommand = require('./davexcore/media/toimg');
const { ipLookupCommand, whoIsCommand, reverseipCommand } = require('./davexcore/utility/ethicalhacking');
const resetMenuImageCommand = require('./davexcore/owner/resetmenuimage');
const pinterestCommand = require('./davexcore/downloads/pinterest');
const rpsCommand = require('./davexcore/games/rps');
const slotCommand = require('./davexcore/games/slot');

const teraboxCommand = require('./davexcore/downloads/terabox');

// === NEW AI COMMANDS ===
const deepseekCommand = require('./davexcore/ai/deepseek');
const grokCommand = require('./davexcore/ai/grok');
const wormgptCommand = require('./davexcore/ai/wormgpt');
const copilotCommand = require('./davexcore/ai/copilot');
const metaAICommand = require('./davexcore/ai/metai');
const ilamaCommand = require('./davexcore/ai/ilama');
const mistralCommand = require('./davexcore/ai/mistral');
const perplexityCommand = require('./davexcore/ai/perplexity');
const blackboxCommand = require('./davexcore/ai/blackbox');
const speechwriterCommand = require('./davexcore/ai/speechwriter');

// === NEW GAME COMMANDS ===
const { coinflipCommand } = require('./davexcore/games/coinflip');
const { numguessCommand } = require('./davexcore/games/numguess');
const { wyrCommand } = require('./davexcore/games/wouldyourather');
const { quizCommand, handleQuizAnswer, hasActiveQuiz } = require('./davexcore/games/quiz');

// ========== GLOBAL SETTINGS ==========
global.packname = settings?.packname || "DAVE-X";
global.author = settings?.author || "DAVE-X BOT";
global.channelLink = "https://whatsapp.com/channel/0029VbApvFQ2Jl84lhONkc3k";
global.ytchanel = "";

const channelInfo = {};

// Override console.log with glitch frame for message logging
console.log = function(...args) {
    // Skip if it's our custom logs (to avoid recursion)
    if (args[0] && typeof args[0] === 'string' && args[0].includes('┌─────────────────')) {
        originalConsoleLog.apply(console, args);
        return;
    }
    
    // Check if this is a message/command log
    const message = args.join(' ');
    if (message.includes('[CMD]') || message.includes('[MSG]')) {
        // These are handled separately in the message handler
        originalConsoleLog.apply(console, args);
    } else {
        originalConsoleLog.apply(console, args);
    }
};

// ========== MESSAGE HANDLER ==========
async function handleMessages(sock, messageUpdate, printLog) {
    try {
        global.sock = sock;

        const { messages, type } = messageUpdate;

        const message = messages[0];
        if (!message?.message) return;

        // Newsletter messages — react handled directly in index.js, skip command processing
        if (message.key?.remoteJid?.endsWith('@newsletter')) return;

        if (!message._editedCommandOnly) {
            // Handle automation features (non-blocking)
            // autoread: checks if enabled FIRST (guard is first line of handleAutoread)
            handleAutoread(sock, message).catch(() => {});
            handleDevReact(sock, message).catch(() => {});

            // Store messages for anti-features (non-blocking)
            if (message.message) {
                setImmediate(() => storeMessage(sock, message));
                // Antiviewonce — runs automatically when enabled, sender never knows
                setImmediate(() => handleAntiviewonce(sock, message).catch(() => {}));
            }

            // Store for antiedit tracking (edits handled via messages.update in index.js)
            setImmediate(() => storeOriginalMessage(message));

            if (message.message?.protocolMessage?.type === 14) {
                const editUpdate = {
                    key: message.message.protocolMessage.key || message.key,
                    update: { message: message.message }
                };
                await handleEditedMessage(sock, editUpdate);
                const _editedText = getEditedMessageText(message);
                const _prefix = getPrefix();
                const _isCommand = _editedText && (_prefix === '' || _editedText.startsWith(_prefix));
                if (!_isCommand) return;
            }

            if (message.message?.protocolMessage?.type === 0) {
                await handleMessageRevocation(sock, message);
                return;
            }
        }

        const chatId = message.key.remoteJid;
        const senderId = message.key.participant || message.key.remoteJid;
        if (senderId && senderId.endsWith('@s.whatsapp.net')) registerContact(senderId);
        let senderNumber = (senderId || '').split(':')[0].split('@')[0];
        
        if (isLidJid(senderId)) {
            // Layer 1: sync cache + signalRepository (zero latency)
            const resolved = resolvePhoneFromLid(senderId, sock);
            if (resolved && /^\d{7,15}$/.test(resolved)) {
                senderNumber = resolved;
            } else {
                // Layers 2-4 run in background — populate cache for next message, don't block commands
                const _lidNum = senderNumber;
                const _chatId = chatId;
                setImmediate(async () => {
                    try {
                        if (sock?.signalRepository?.lidMapping?.getPNForLID) {
                            for (const fmt of [senderId, `${_lidNum}@lid`, `${_lidNum}:0@lid`]) {
                                const pn = await Promise.resolve(sock.signalRepository.lidMapping.getPNForLID(fmt));
                                if (pn) {
                                    const num = String(pn).split('@')[0].replace(/[^0-9]/g, '');
                                    if (num.length >= 7 && num.length <= 15 && num !== _lidNum) {
                                        cacheLidPhone(_lidNum, num);
                                        return;
                                    }
                                }
                            }
                        }
                        if (store?.contacts) {
                            const contact = store.contacts[senderId] || store.contacts[`${_lidNum}@s.whatsapp.net`];
                            if (contact?.id) {
                                const cnum = contact.id.split('@')[0].split(':')[0];
                                if (/^\d{7,15}$/.test(cnum) && cnum !== _lidNum) { cacheLidPhone(_lidNum, cnum); return; }
                            }
                        }
                        // Layer 4: scan current group participants for p.lid match
                        if (_chatId?.endsWith('@g.us')) {
                            try {
                                const meta = await sock.groupMetadata(_chatId);
                                for (const p of (meta?.participants || [])) {
                                    const pLidNum = (p.lid || '').split('@')[0].split(':')[0];
                                    const pPhoneNum = (p.id || '').split('@')[0].split(':')[0];
                                    if (pLidNum === _lidNum && /^\d{7,15}$/.test(pPhoneNum) && pPhoneNum !== _lidNum) {
                                        cacheLidPhone(_lidNum, pPhoneNum);
                                        return;
                                    }
                                }
                            } catch {}
                        }
                    } catch {}
                });
            }
        }
        
        const pushName = message.pushName
            || global.pushNameCache?.get(senderNumber)
            || global.pushNameCache?.get((senderId || '').split('@')[0].split(':')[0])
            || senderNumber;

        // Cache push names globally so VCF, goodbye, and other modules can find real names
        if (message.pushName) {
            if (!global.pushNameCache) global.pushNameCache = new Map();
            global.pushNameCache.set(senderId.split('@')[0].split(':')[0], message.pushName);
            if (senderNumber && senderNumber !== senderId.split('@')[0].split(':')[0]) {
                global.pushNameCache.set(senderNumber, message.pushName);
            }
        }

        const prefix = getPrefix();
        const isPrefixless = prefix === '';
        const isGroup = chatId.endsWith('@g.us');
        const senderIsSudo = await isSudo(senderId);

        const msgType = Object.keys(message.message || {}).find(k => 
            k !== 'messageContextInfo' && k !== 'senderKeyDistributionMessage'
        ) || 'unknown';

        let userMessage = getMessageText(message);

        let groupName = '';
        if (isGroup) {
            groupName = getGroupNameSync(chatId);
            refreshGroupNameCache(sock, chatId);
        }

        // ========== GLITCH FRAME LOGGING FOR EVERY MESSAGE ==========
        if (message.message) {
            const mtype = Object.keys(message.message)[0].replace('Message', '').replace('ExtendedText', 'Text');

            // Skip verbose banner for reactions — they flood the log and add no value
            const isReactionMsg = mtype === 'reaction' ||
                Object.keys(message.message || {}).includes('reactionMessage');

            if (!isReactionMsg) {
            const messageContent = userMessage || mtype || 'Unknown';
            
            console.log(chalk.bgHex('#0a0a0a').hex('#00ff00')('┌───────────────── MESSAGE ─────────────────┐'));
            console.log(chalk.bgHex('#0a0a0a').hex('#ff00ff')(`   ⚡ ${glitchText('INCOMING TRANSMISSION')}`));
            console.log(chalk.bgHex('#0a0a0a').hex('#00ffff')('├─────────────────────────────────────────────┤'));
            
            const entries = [
                ['🕐', 'TIMESTAMP', new Date().toLocaleString()],
                ['📡', 'CONTENT', messageContent.substring(0, 50) + (messageContent.length > 50 ? '...' : '')],
                ['👤', 'USER', pushName],
                ['🔢', 'NUMBER', `+${senderNumber}`], // Shows real number with + prefix
                ...(isGroup ? [
                    ['👥', 'GROUP', groupName],
                    ['🔗', 'GROUP_ID', chatId.split('@')[0]]
                ] : [
                    ['💬', 'CHAT', 'PRIVATE']
                ]),
                ['📱', 'TYPE', mtype]
            ];

            entries.forEach(([icon, label, value]) => {
                console.log(
                    chalk.bgHex('#0a0a0a').hex('#ffff00')(`   ${icon} `) +
                    chalk.bgHex('#0a0a0a').hex('#00ff00')(`${label}:`) +
                    chalk.bgHex('#0a0a0a').hex('#ffffff')(` ${value}`)
                );
            });
            
            console.log(chalk.bgHex('#0a0a0a').hex('#00ff00')('└─────────────────────────────────────────────┘\n'));
            }
        }

        const fake = createFakeContact(message);

        // Check bot mode access
        try {
            const botMode = getBotMode();
            if (botMode === 'group' && !isGroup) return;
            if (botMode === 'pm' && isGroup) return;
            if (botMode === 'private' && !message.key.fromMe && !senderIsSudo) return;
        } catch (error) {
            // Non-fatal — default to allowing all messages
        }

        // Check if user is banned
        if (userMessage && isBanned(senderId) && !userMessage.startsWith(`${prefix}unban`)) {
            if (Math.random() < 0.1) {
                await sock.sendMessage(chatId, {
                    text: 'You are banned from using the bot. Contact an admin to get unbanned.',
                    ...channelInfo
                });
            }
            return;
        }

        // Skip bot's own non-text messages (audio/video/images etc.) — they have no userMessage
        // and would crash on .trim() calls below, causing error spam back into the chat
        if (!userMessage && message.key.fromMe) return;

        // Handle game moves (Tic Tac Toe & Connect Four)
        if (/^[1-9]$/.test(userMessage)) {
            const tttResult = await handleTicTacToeMove(sock, chatId, senderId, userMessage);
            if (!tttResult && parseInt(userMessage) <= 7) {
                await handleConnectFourMove(sock, chatId, senderId, userMessage);
            }
        }

        // Handle Word Chain game words (single words during active game)
        if (hasWcgGame && hasWcgGame(chatId) && /^[a-zA-Z]+$/.test(userMessage.trim())) {
            await handleWcgWord(sock, chatId, senderId, userMessage.trim(), fake);
        }

        // Handle Quiz answers (A/B/C/D)
        if (hasActiveQuiz && hasActiveQuiz(chatId) && /^[ABCD]$/i.test(userMessage.trim())) {
            await handleQuizAnswer(sock, chatId, message, userMessage.trim());
        }

        // Increment message count for top members
        if (!message.key.fromMe && !message._editedCommandOnly) incrementMessageCount(chatId, senderId);

        // ====== ANTI FEATURES DETECTION (non-blocking — runs in background) ======
        if (isGroup) {
            setImmediate(async () => {
                try {
                    handleAntiLinkDetection(sock, message).catch(() => {});
                    handleAntiStatusMention(sock, message).catch(() => {});

                    const isSticker = message.message?.stickerMessage;
                    const isImage = message.message?.imageMessage;
                    const isVideo = message.message?.videoMessage;
                    const isAudio = message.message?.audioMessage || message.message?.pttMessage;
                    const isDocument = message.message?.documentMessage;
                    const hasText = userMessage && userMessage.trim() !== '';

                    if (isSticker) handleStickerDetection(sock, chatId, message, senderId).catch(() => {});
                    if (isImage) handleImageDetection(sock, chatId, message, senderId).catch(() => {});
                    if (isVideo) handleVideoDetection(sock, chatId, message, senderId).catch(() => {});
                    if (isAudio) handleAudioDetection(sock, chatId, message, senderId).catch(() => {});
                    if (isDocument) handleDocumentDetection(sock, chatId, message, senderId).catch(() => {});
                    if (isSticker || isImage || isVideo || isAudio || isDocument) {
                        handleFilesDetection(sock, chatId, message, senderId).catch(() => {});
                    }

                    handleChartDetection(sock, chatId, message, senderId).catch(() => {});
                    handleForwardDetection(sock, chatId, message, senderId).catch(() => {});
                    handleBugDetection(sock, chatId, message, senderId).catch(() => {});

                    if (hasText) {
                        handleBadwordDetection(sock, chatId, message, userMessage, senderId).catch(() => {});
                        handleNewMentionDetection(sock, chatId, message, senderId).catch(() => {});
                        handleAntibotDetection(sock, chatId, message, userMessage, senderId).catch(() => {});
                        handleAntivirtexDetection(sock, chatId, message, userMessage, senderId).catch(() => {});
                    }
                } catch {}
            });
        }
        // Anti-features for DMs (non-blocking)
        if (!isGroup && !message.key.fromMe && !senderIsSudo) {
            setImmediate(() => {
                handleBugDetection(sock, chatId, message, senderId).catch(() => {});
                handleAntibugDm(sock, chatId, message, senderId).catch(() => {});
            });
        }
        // ====== END ANTI FEATURES DETECTION ======

        // PM Blocker check
        if (!isGroup && !message.key.fromMe && !senderIsSudo) {
            try {
                const pmState = readPmBlockerState ? readPmBlockerState() : { enabled: false };
                if (pmState && pmState.enabled) {
                    await sock.sendMessage(chatId, { text: pmState.message || 'Private messages are blocked. Contact owner in groups only.' });
                    return;
                }
            } catch (e) { 
                // Continue if pmblocker fails
            }
        }

        // Auto typing, recording, and reactions — fire-and-forget, never block command execution
        if (isAutotypingEnabled()) {
            handleAutotypingForMessage(sock, chatId).catch(() => {});
        }

        if (isAutorecordingEnabled()) {
            handleAutorecordingForMessage(sock, chatId).catch(() => {});
        }

        // Autoreact fires for ALL messages (not just commands), respecting pm/group/per-chat scope
        handleAutoreactForMessage(sock, message).catch(() => {});

        if (userMessage) {
            const lowerMsg = userMessage.trim().toLowerCase();
            if (lowerMsg === 'resetprefix' || lowerMsg === 'getprefix' || lowerMsg === 'prefix') {
                const currentPrefix = getPrefix() || '.';
                const botName = getBotName();
                const isOwner = message.key.fromMe || senderId === `${settings.ownerNumber}@s.whatsapp.net` || senderIsSudo;
                if (lowerMsg === 'resetprefix' && isOwner) {
                    const { setPrefix } = require('./davexcore/owner/setprefix');
                    setPrefix('.');
                    await sock.sendMessage(chatId, { text: `*${botName}*\nPrefix has been reset to: .` }, { quoted: fake });
                } else if (lowerMsg === 'resetprefix') {
                    // Not owner, ignore silently
                } else if (lowerMsg === 'getprefix' || lowerMsg === 'prefix') {
                    // Owner only — everywhere (DMs and groups)
                    if (isOwner) {
                        await sock.sendMessage(chatId, { text: `*${botName}*\nCurrent prefix: *${currentPrefix === '' ? 'None (prefixless)' : currentPrefix}*` }, { quoted: fake });
                    }
                }
                return;
            }
        }

        // Extract command
        let command, args, fullArgs;
        if (userMessage) {
            const extracted = extractCommand(userMessage, prefix);
            command = extracted.command;
            args = extracted.args;
            fullArgs = extracted.fullArgs;
            
            if (command) {
                const chatLabel = isGroup ? chatId.split('@')[0] : 'DM';
                const typeLabel = msgType.replace('Message', '').replace('extendedText', 'text');
                const cmdLine = `${prefix}${command}${fullArgs ? ' ' + fullArgs.substring(0, 50) + (fullArgs.length > 50 ? '...' : '') : ''}`;
                
                global._lastCmd = `${prefix}${command}`;
                global._lastCmdTime = new Date().toISOString();
                global._lastCmdError = null;

                // Command log with glitch frame
                console.log(chalk.bgHex('#0a0a0a').hex('#00ff00')('┌───────────────── COMMAND ─────────────────┐'));
                console.log(chalk.bgHex('#0a0a0a').hex('#ff00ff')(`   ⚡ ${glitchText('COMMAND EXECUTED')}`));
                console.log(chalk.bgHex('#0a0a0a').hex('#00ffff')('├─────────────────────────────────────────────┤'));
                
                const cmdEntries = [
                    ['🕐', 'TIME', new Date().toLocaleString()],
                    ['⚡', 'COMMAND', `${prefix}${command}`],
                    ['📝', 'ARGS', fullArgs || 'None'],
                    ['👤', 'USER', pushName],
                    ['🔢', 'NUMBER', `+${senderNumber}`],
                    ['📍', 'CHAT', chatLabel],
                    ['📱', 'TYPE', typeLabel]
                ];

                cmdEntries.forEach(([icon, label, value]) => {
                    console.log(
                        chalk.bgHex('#0a0a0a').hex('#ffff00')(`   ${icon} `) +
                        chalk.bgHex('#0a0a0a').hex('#00ff00')(`${label}:`) +
                        chalk.bgHex('#0a0a0a').hex('#ffffff')(` ${value}`)
                    );
                });
                
                console.log(chalk.bgHex('#0a0a0a').hex('#00ff00')('└─────────────────────────────────────────────┘\n'));
            }
        }

        // If no command but has text, handle chatbot/tag detection
        if (!command && userMessage) {
            // Handle song/play format choice buttons
            if (['song_audio', 'song_doc', 'song_voice'].includes(userMessage)) {
                const format = userMessage.split('_')[1];
                const pending = getSongPending(chatId);
                if (pending) {
                    await processSongDownload(sock, chatId, message, format);
                } else {
                    await sock.sendMessage(chatId, {
                        text: `*${getBotName()}*\nNo pending search. Use .song or .play first.`
                    }, { quoted: fake });
                }
                return;
            }

            if (['tiktok_video', 'tiktok_audio'].includes(userMessage)) {
                const format = userMessage === 'tiktok_video' ? 'video' : 'audio';
                const pending = getTiktokPending(chatId);
                if (pending) {
                    await processTiktokDownload(sock, chatId, message, format);
                } else {
                    await sock.sendMessage(chatId, {
                        text: `*${getBotName()}*\nNo pending TikTok. Use .tiktok <url> first.`
                    }, { quoted: fake });
                }
                return;
            }

            if (userMessage === 'github_zip' || userMessage === 'zip') {
                const pending = getGithubPending(chatId);
                if (pending) {
                    await processGithubZip(sock, chatId, message);
                } else {
                    await sock.sendMessage(chatId, {
                        text: `*${getBotName()}*\nNo pending repo. Use .github first.`
                    }, { quoted: fake });
                }
                return;
            }
            if (isGroup) {
                await handleChatbotResponse(sock, chatId, message, userMessage, senderId);
                await handleTagDetection(sock, message);
                await handleMentionDetection(sock, chatId, message);
            }
            return;
        }

        if (!command) return;

        // Define command categories
        const adminCommands = [
            'mute', 'unmute', 'ban', 'unban', 'promote', 'demote', 'kick', 
            'linkgroup', 'linkgc', 'tagall', 'tagnotadmin', 'hidetag', 'antilink', 
            'antitag', 'setgdesc', 'setgname', 'setgpp', 'antikick', 
            'antipromote', 'antidemote', 'antibug', 'antigroupmention', 'groupmention',
            'antimention', 'antiaudio', 'antivideo', 'antidocument', 
            'antifiles', 'antisticker', 'antiimage', 'antibadword', 
            'antichart', 'antiforward', 'antibot', 'antivirtex', 'antivortex', 'welcome', 'goodbye',
            'add', 'groupinfo', 'infogroup', 'infogrupo', 'admin', 'listadmin',
            'staff', 'reset', 'revoke', 'resetlink', 'tagadmins', 'admins',
            'accept', 'approve', 'reject', 'decline', 'acceptall', 'rejectall',
            'listrequests', 'requests', 'joinrequests', 'online',
            'warn', 'warnings', 'kickall', 'tag', 'clear',
            'chatbot', 'ship'
        ];
        
        const ownerCommands = [
            'mode', 'autostatus', 'antidelete', 'cleartmp', 'setpp', 
            'tostatus', 'clearsession', 'areact', 'autoreact', 'autotyping', 
            'autoread', 'pmblocker', 'antibugdm', 'setbotconfig', 'setbotname', 
            'setmenuimage', 'setfont', 'font', 'hijack', 'pair', 'autorecording', 'chatbot',
            'autocall', 'broadcast', 'creategroup', 'setowner', 'setprefix',
            'vv2', 'antiedit', 'antiviewonce', 'sad', 'startupwelcome',
            'pin', 'unpin', 'archive',
            'unarchive', 'disappearing', 'readreceipts', 'autoreadreceipts',
            'setbio', 'bio', 'removebio', 'resetbio', 'clearbio',
            'autobio',
            'newsletterreact', 'channelreact', 'nwreact',
            'autoreply', 'autoreplyoff', 'autostatusreply',
            'autoviewstatus', 'autostatusview',
            'pinchat', 'pinconvo', 'unpinchat', 'unpinconvo',
            'disappear', 'ephemeral', 'menuset', 'menuconfig', 'menustyle'
        ];

        const isAdminCommand = adminCommands.includes(command);
        const isOwnerCommand = ownerCommands.includes(command);

        if (!isGroup && isAdminCommand) {
            await sock.sendMessage(chatId, {
                text: 'This command can only be used in groups, not in private chats!'
            }, { quoted: fake });
            return;
        }

        let isSenderAdmin = false;
        let isBotAdmin = false;

        if (isGroup && isAdminCommand) {
            const adminStatus = await isAdmin(sock, chatId, senderId, message);
            isSenderAdmin = adminStatus.isSenderAdmin;
            isBotAdmin = adminStatus.isBotAdmin;

            if (!isBotAdmin && command !== 'welcome' && command !== 'goodbye') {
                await sock.sendMessage(chatId, { text: 'Please make the bot an admin to use admin commands.' }, { quoted: fake });
                return;
            }

            if (
                ['mute', 'unmute', 'ban', 'unban', 'promote', 'demote', 'kick', 'hijack', 
                'antilink', 'antitag', 'antikick', 'antipromote', 'antidemote', 'antibug',
                'antigroupmention', 'groupmention', 'antimention', 'antiaudio', 'antivideo', 'antidocument',
                'antifiles', 'antisticker', 'antiimage', 'antibadword', 'antichart', 'antiforward', 'antibot', 'antivirtex', 'antivortex', 'add',
                'kickall', 'resetlink', 'reset', 'revoke', 'setgdesc', 'setgname', 'setgpp',
                'accept', 'approve', 'reject', 'decline', 'acceptall', 'rejectall',
                'listrequests', 'requests', 'joinrequests', 'warn'].includes(command)
            ) {
                if (!isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, {
                        text: 'Sorry, only group admins can use this command.',
                        ...channelInfo
                    }, { quoted: fake });
                    return;
                }
            }
        }

        if (isOwnerCommand) {
            if (!message.key.fromMe && !senderIsSudo) {
                await sock.sendMessage(chatId, { text: 'This command is only available for the owner or sudo!' }, { quoted: fake });
                return;
            }
        }

        let commandExecuted = false;

        // ========== COMMAND SWITCH CASE ==========
        try {
        switch (command) {
            // === BOT MANAGEMENT ===
            case 'setprefix':
                await handleSetPrefixCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'setowner':
                await handleSetOwnerCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'owner':
                await ownerCommand(sock, chatId);
                commandExecuted = true;
                break;
                
            case 'ping':
            case 'p':
                await pingCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'uptime':
            case 'alive':
            case 'up':
            case 'runtime':
                await aliveCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'help':
            case 'menu':
            case 'h':
            case 'allmenu':
                await helpCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'menuconfig':
            case 'menustyle':
            case 'menuset':
            case 'setmenu':
                await menuManageCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
                
            case 'settings':
            case 'getsettings':
                await settingsCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'sudo':
            case 'addsudo':
            case 'delsudo':
            case 'removesudo':
            case 'listsudo':
                if (command === 'addsudo') {
                    const rawText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
                    const rest = rawText.trim().split(/\s+/).slice(1).join(' ');
                    message.message = message.message || {};
                    if (message.message.conversation !== undefined) {
                        message.message.conversation = `${prefix}sudo add ${rest}`;
                    } else if (message.message.extendedTextMessage) {
                        message.message.extendedTextMessage.text = `${prefix}sudo add ${rest}`;
                    }
                } else if (command === 'delsudo' || command === 'removesudo') {
                    const rawText = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
                    const rest = rawText.trim().split(/\s+/).slice(1).join(' ');
                    message.message = message.message || {};
                    if (message.message.conversation !== undefined) {
                        message.message.conversation = `${prefix}sudo del ${rest}`;
                    } else if (message.message.extendedTextMessage) {
                        message.message.extendedTextMessage.text = `${prefix}sudo del ${rest}`;
                    }
                } else if (command === 'listsudo') {
                    message.message = message.message || {};
                    if (message.message.conversation !== undefined) {
                        message.message.conversation = `${prefix}sudo list`;
                    } else if (message.message.extendedTextMessage) {
                        message.message.extendedTextMessage.text = `${prefix}sudo list`;
                    }
                }
                await sudoCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'clearsession':
            case 'clearsesi':
                await clearSessionCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'mode':
    {
        if (!message.key.fromMe && !senderIsSudo) {
            await sock.sendMessage(chatId, { 
                text: `✦ Only the owner can change bot mode` 
            }, { quoted: fake });
            return;
        }

        const action = args[0]?.toLowerCase();
        const validModes = ['private', 'public', 'group', 'pm'];

        const modeDescriptions = {
            private: `Now only you can use the bot`,
            public: `Everyone can now use the bot`,
            group: `Bot will now only work in groups`,
            pm: `Bot will now only work in private chats`
        };

        if (!action) {
            const currentMode = getBotMode();
            await sock.sendMessage(chatId, {
                text: `✦ Current mode: ${currentMode}

To change mode:
${prefix}mode private
${prefix}mode public
${prefix}mode group
${prefix}mode pm

Example: ${prefix}mode group`
            }, { quoted: fake });
            return;
        }

        if (!validModes.includes(action)) {
            await sock.sendMessage(chatId, {
                text: `✦ Use one of these: private, public, group, pm

Example: ${prefix}mode group`
            }, { quoted: fake });
            return;
        }

        try {
            setBotMode(action);
            await sock.sendMessage(chatId, {
                text: `✦ Mode set to ${action}\n${modeDescriptions[action]}`
            }, { quoted: fake });
        } catch (error) {
            console.error('Error updating access mode:', error);
            await sock.sendMessage(chatId, {
                text: `✦ Something went wrong updating the mode`
            }, { quoted: fake });
        }
    }
    commandExecuted = true;
    break;
            case 'update':
            case 'start':
            case 'restart':
                {
                    const zipArg = args[0] && args[0].startsWith('http') ? args[0] : '';
                    await updateCommand(sock, chatId, message, senderIsSudo, zipArg);
                }
                commandExecuted = true;
                break;

            // === MODERATION COMMANDS ===
            case 'ban':
                await banCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'unban':
                await unbanCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'mute':
                {
                    const muteArg = args[0];
                    const muteDuration = muteArg !== undefined ? parseInt(muteArg, 10) : undefined;
                    if (muteArg !== undefined && (isNaN(muteDuration) || muteDuration <= 0)) {
                        await sock.sendMessage(chatId, { text: 'Please provide a valid number of minutes or use .mute with no number to mute immediately.' }, { quoted: fake });
                    } else {
                        await muteCommand(sock, chatId, senderId, message, muteDuration);
                    }
                }
                commandExecuted = true;
                break;
                
            case 'unmute':
                await unmuteCommand(sock, chatId, senderId);
                commandExecuted = true;
                break;

            case 'grouplock':
            case 'lockgroup':
                await groupLockCommand(sock, chatId, senderId, message);
                commandExecuted = true;
                break;

            case 'groupunlock':
            case 'unlockgroup':
                await groupUnlockCommand(sock, chatId, senderId, message);
                commandExecuted = true;
                break;

            case 'groupclose':
            case 'closegroup':
            case 'groupannounce':
                await groupCloseCommand(sock, chatId, senderId, message);
                commandExecuted = true;
                break;

            case 'groupopen':
            case 'opengroup':
                await groupOpenCommand(sock, chatId, senderId, message);
                commandExecuted = true;
                break;

            case 'addmode':
            case 'memberaddmode':
                await addModeCommand(sock, chatId, senderId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'joinapproval':
            case 'approvalmode':
                await joinApprovalCommand(sock, chatId, senderId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'kick':
                const mentionedJidListKick = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await kickCommand(sock, chatId, senderId, mentionedJidListKick, message);
                commandExecuted = true;
                break;
                
            case 'warn':
                const mentionedJidListWarn = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await warnCommand(sock, chatId, senderId, mentionedJidListWarn, message);
                commandExecuted = true;
                break;
                
            case 'warnings':
                const mentionedJidListWarnings = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await warningsCommand(sock, chatId, mentionedJidListWarnings);
                commandExecuted = true;
                break;
                
            case 'promote':
                const mentionedJidListPromote = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await promoteCommand(sock, chatId, mentionedJidListPromote, message);
                commandExecuted = true;
                break;
                
            case 'demote':
                const mentionedJidListDemote = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await demoteCommand(sock, chatId, mentionedJidListDemote, message);
                commandExecuted = true;
                break;
                
            case 'clear':
                if (isGroup) await clearCommand(sock, chatId);
                commandExecuted = true;
                break;

            case 'clearall':
            case 'clearchat':
                await handleClearCommand(sock, chatId, message, senderId);
                commandExecuted = true;
                break;
                
            case 'removeall':
            case 'killall':
                await kickAllCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'block':
                await blockCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case 'lastseen':
                await lastseenCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            // ── Bot global presence (never affects message processing) ──────────
            case 'setonline':
            case 'available':
            case 'goliveline':
            case 'boonline':
                await setBotOnlineCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'setoffline':
            case 'unavailable':
            case 'alwaysoffline':
            case 'gooffline':
            case 'botoffline':
                await setBotOfflineCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            // ── Per-chat presence (works in both PM and groups) ──────────────────
            case 'typing':
            case 'simtyping':
            case 'faketyping':
                await setTypingCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'simrecording':
            case 'fakerecording':
            case 'voicesim':
                await setRecordingCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'stoptyping':
            case 'stoprecording':
            case 'stoppresence':
                await stopPresenceCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            // ── Privacy settings ─────────────────────────────────────────────────
            case 'myprivacy':
            case 'privacyinfo':
            case 'privacysettings':
            case 'showprivacy':
                await showPrivacyCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'onlineprivacy':
            case 'privacyonline':
                await onlinePrivacyCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'callprivacy':
            case 'privacycall':
                await callPrivacyCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'readreceipts':
            case 'receiptprivacy':
            case 'bluetick':
                await readReceiptsCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'groupsprivacy':
            case 'groupaddprivacy':
            case 'privacygroups':
                await groupsPrivacyCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'statusprivacy':
            case 'privacystatus':
                await statusPrivacyCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'ppprivacy':
            case 'picprivacy':
            case 'photoprivacy':
            case 'profilepicprivacy':
                await ppPrivacyCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'msgprivacy':
            case 'messageprivacy':
            case 'privacymsg':
                await msgPrivacyCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'linkpreviewsprivacy':
            case 'linkprivacy':
            case 'linkpreview':
                await linkPreviewsPrivacyCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'createcalllink':
            case 'calllink': {
                const fake = createFakeContact(message);
                const botName = getBotName();
                const callType = (args[0] || 'audio').toLowerCase() === 'video' ? 'video' : 'audio';
                try {
                    const token = await sock.createCallLink(callType);
                    await sock.sendMessage(chatId, {
                        text: `✦ *${botName}*\n\n📞 ${callType === 'video' ? '📹 Video' : '🔊 Audio'} call link created:\n\nhttps://call.whatsapp.com/voice/CfwvFIJd4U3GrFVA3lkBbe`
                            .replace('https://call.whatsapp.com/voice/CfwvFIJd4U3GrFVA3lkBbe', token ? `https://call.whatsapp.com/voice/${token}` : '_(link unavailable — WhatsApp Business required)_')
                    }, { quoted: fake });
                } catch (err) {
                    await sock.sendMessage(chatId, { text: `❌ Failed to create call link: ${err.message}` }, { quoted: fake });
                }
                commandExecuted = true;
                break;
            }

            case 'unblock':
                await unblockCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'blocklist':
            case 'listblock':
                await blocklistCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'unblockall':
            case 'unblockeveryone':
                await unblockallCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'mygroups':
            case 'listgroups':
            case 'groups':
                await mygroupsCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'savecontact':
            case 'addcontact':
            case 'contact':
                await savecontactCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'updatenotify':
            case 'autoupdate':
                await updatenotifyCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'removepp':
            case 'removeprofilepic':
            case 'removepfp':
                await removeProfilePicCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'ppnone':
            case 'profilepicnone':
            case 'pfpnone':
                await setProfilePicPrivacyCommand(sock, chatId, message, 'none');
                commandExecuted = true;
                break;

            case 'ppall':
            case 'profilepicall':
            case 'pfpall':
                await setProfilePicPrivacyCommand(sock, chatId, message, 'all');
                commandExecuted = true;
                break;

            case 'ppcontacts':
            case 'profilepiccontacts':
                await setProfilePicPrivacyCommand(sock, chatId, message, 'contacts');
                commandExecuted = true;
                break;

            case 'pp':
            case 'profilepic': {
                const ppArg = (fullArgs || '').trim().toLowerCase();
                if (ppArg === 'all') {
                    await setProfilePicPrivacyCommand(sock, chatId, message, 'all');
                } else if (ppArg === 'none') {
                    await setProfilePicPrivacyCommand(sock, chatId, message, 'none');
                } else if (ppArg === 'contacts') {
                    await setProfilePicPrivacyCommand(sock, chatId, message, 'contacts');
                } else {
                    const _bn = getBotName();
                    const _fk = createFakeContact(message);
                    await sock.sendMessage(chatId, {
                        text: `✦ *${_bn}* | Profile Pic Privacy\n\n.pp all — everyone can see\n.pp none — nobody can see\n.pp contacts — contacts only\n.removepp — remove profile picture`
                    }, { quoted: _fk });
                }
                commandExecuted = true;
                break;
            }

            // === GROUP MANAGEMENT ===
            case 'groupinfo':
            case 'infogroup':
            case 'infogrupo':
                await groupInfoCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'admin':
            case 'listadmin':
            case 'staff':
                await staffCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'reset':
            case 'revoke':
            case 'resetlink':
                await resetlinkCommand(sock, chatId, senderId);
                commandExecuted = true;
                break;
                
            case 'linkgroup':
            case 'linkgc':
                await linkgroupCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'creategroup':
            case 'creategc':
                await creategroupCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
                case 'join':
    await joinCommand(sock, chatId, message);
    commandExecuted = true;
    break;
                
            case 'left':
            case 'leave':
                await leaveGroupCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'setgdesc':
                await setGroupDescription(sock, chatId, senderId, fullArgs, message);
                commandExecuted = true;
                break;
                
            case 'setgname':
            case 'setgroupname':
            case 'groupname':
                await setGroupName(sock, chatId, senderId, fullArgs, message);
                commandExecuted = true;
                break;
                
            case 'setgpp':
                await setGroupPhoto(sock, chatId, senderId, message);
                commandExecuted = true;
                break;
                
            case 'tagall':
                if (isSenderAdmin || message.key.fromMe) {
                    await tagAllCommand(sock, chatId, senderId, message);
                } else {
                    await sock.sendMessage(chatId, { text: '_Only admins can use this command_' }, { quoted: fake });
                }
                commandExecuted = true;
                break;
                
            case 'tagnotadmin':
                await tagNotAdminCommand(sock, chatId, senderId, message);
                commandExecuted = true;
                break;
            case 'hidetag':
                {
                    const messageText = fullArgs;
                    const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
                    await hideTagCommand(sock, chatId, senderId, messageText, replyMessage, message);
                }
                commandExecuted = true;
                break;
                
            case 'tag':
                const messageText = fullArgs;
                const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
                await tagCommand(sock, chatId, senderId, messageText, replyMessage, message);
                commandExecuted = true;
                break;

            case 'tagadmins':
            case 'admins':
                await tagAdminsCommand(sock, chatId, senderId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'online':
                await onlineCommand(sock, chatId, senderId, message);
                commandExecuted = true;
                break;

            case 'accept':
            case 'approve':
                await acceptCommand(sock, chatId, senderId, fullArgs, message, fake);
                commandExecuted = true;
                break;

            case 'reject':
            case 'decline':
                await rejectCommand(sock, chatId, senderId, fullArgs, message, fake);
                commandExecuted = true;
                break;

            case 'acceptall':
                await acceptAllCommand(sock, chatId, senderId, message, fake);
                commandExecuted = true;
                break;

            case 'rejectall':
                await rejectAllCommand(sock, chatId, senderId, message, fake);
                commandExecuted = true;
                break;

            case 'listrequests':
            case 'requests':
            case 'joinrequests':
                await listRequestsCommand(sock, chatId, senderId, message, fake);
                commandExecuted = true;
                break;

            case 'add':
                await addMemberCommand(sock, chatId, message, fullArgs, prefix, senderId, isSenderAdmin, isBotAdmin, isGroup);
                commandExecuted = true;
                break;

            // === ANTI-FEATURES ===
            case 'antilink':
                const antilinkAdminStatus = await isAdmin(sock, chatId, senderId);
                const antilinkIsSenderAdmin = antilinkAdminStatus.isSenderAdmin;
                const antilinkIsBotAdmin = antilinkAdminStatus.isBotAdmin;

                if (!antilinkIsBotAdmin) {
                    await sock.sendMessage(chatId, { 
                        text: '❌ Bot must be admin to use anti-link!' 
                    }, { quoted: fake });
                    return;
                }

                const antilinkSubCmd = args[0]?.toLowerCase();
                if (!['status', 'help'].includes(antilinkSubCmd) && !antilinkIsSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, { 
                        text: '❌ Only group admins can configure anti-link!' 
                    }, { quoted: fake });
                    return;
                }

                await handleAntilinkCommand(sock, chatId, userMessage, senderId, antilinkIsSenderAdmin);
                commandExecuted = true;
                break;
                
            case 'antigroupmention':
            case 'groupmention':
                const agmAdminStatus = await isAdmin(sock, chatId, senderId);
                const agmIsSenderAdmin = agmAdminStatus.isSenderAdmin;
                const agmIsBotAdmin = agmAdminStatus.isBotAdmin;

                if (!agmIsBotAdmin) {
                    await sock.sendMessage(chatId, { 
                        text: '❌ Bot must be admin to use anti-group mention!' 
                    }, { quoted: fake });
                    return;
                }

                if (!agmIsSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, { 
                        text: '❌ Only group admins can configure anti-group mention!' 
                    }, { quoted: fake });
                    return;
                }

                await antigroupmentionCommand(sock, chatId, message, senderId, fullArgs);
                commandExecuted = true;
                break;
                
            case 'antichart': {
                const antichartAdminStatus = await isAdmin(sock, chatId, senderId);
                const antichartIsSenderAdmin = antichartAdminStatus.isSenderAdmin;
                const antichartIsBotAdmin = antichartAdminStatus.isBotAdmin;

                if (!antichartIsBotAdmin) {
                    await sock.sendMessage(chatId, { text: '❌ Bot must be admin to use anti-chart!' }, { quoted: fake });
                    return;
                }
                if (!antichartIsSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, { text: '❌ Only group admins can configure anti-chart!' }, { quoted: fake });
                    return;
                }
                await antichartCommand(sock, chatId, message, senderId, antichartIsSenderAdmin, fullArgs);
                commandExecuted = true;
                break;
            }

            case 'antiforward': {
                const afAdminStatus = await isAdmin(sock, chatId, senderId);
                if (!afAdminStatus.isBotAdmin) {
                    await sock.sendMessage(chatId, { text: '❌ Bot must be admin to use anti-forward!' }, { quoted: fake });
                    return;
                }
                if (!afAdminStatus.isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, { text: '❌ Only group admins can configure anti-forward!' }, { quoted: fake });
                    return;
                }
                await antiforwardCommand(sock, chatId, userMessage, senderId, afAdminStatus.isSenderAdmin, message);
                commandExecuted = true;
                break;
            }
                
            case 'antitag':
                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, {
                        text: 'Please make the bot an admin first.',
                        ...channelInfo
                    }, { quoted: fake });
                    return;
                }
                await handleAntitagCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                commandExecuted = true;
                break;
                
            case 'antiedit':
                if (!message.key.fromMe && !senderIsSudo) {
                    await sock.sendMessage(chatId, { 
                        text: `Owner only command!` 
                    }, { quoted: fake });
                    return;
                }
                await antieditCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'antidelete':
                await handleAntideleteCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'antiviewonce':
                await antiviewonceCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'mention':
                {
                    const isOwner = message.key.fromMe || senderIsSudo;
                    await mentionToggleCommand(sock, chatId, message, fullArgs, isOwner);
                }
                commandExecuted = true;
                break;
                
            case 'setmention':
                {
                    const isOwner = message.key.fromMe || senderIsSudo;
                    await setMentionCommand(sock, chatId, message, isOwner);
                }
                commandExecuted = true;
                break;
                
            case 'antibadword':
                await antibadwordCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'antibot':
                await antibotCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'antivirtex':
            case 'antivortex':
                await antivirtexCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'antimention':
                await antimentionCommand(sock, chatId, message, senderId);
                commandExecuted = true;
                break;
                
            case 'antipromote':
                await antipromoteCommand(sock, chatId, message, senderId);
                commandExecuted = true;
                break;
                
            case 'antidemote':
                await antidemoteCommand(sock, chatId, message, senderId);
                commandExecuted = true;
                break;
                
            case 'antibug':
                await antibugCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                commandExecuted = true;
                break;

            case 'antibugdm':
                await antibugDmCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'antikick':
                await antikickCommand(sock, chatId, message, senderId, isSenderAdmin);
                commandExecuted = true;
                break;
                
            case 'antiaudio':
                await antiaudioCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                commandExecuted = true;
                break;
                
            case 'antivideo':
                await antivideoCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                commandExecuted = true;
                break;
                
            case 'antidocument':
                await antidocumentCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                commandExecuted = true;
                break;
                
            case 'antifiles':
                await antifilesCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                commandExecuted = true;
                break;
                
            case 'antisticker':
                await antistickerCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                commandExecuted = true;
                break;
                
            case 'antiimage':
                await antiimageCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                commandExecuted = true;
                break;

            // === AUTOMATION FEATURES ===
            case 'autotyping':
                await autotypingCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'autoread':
                await autoreadCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'autorecording':
                await autorecordingCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;


            case 'pin':
                await pinCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'unpin':
                await unpinCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'archive':
                await archiveCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'unarchive':
                await unarchiveCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'disappearing':
                await disappearCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'readreceipts':
            case 'autoreadreceipts':
                await autoreadReceiptsCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'autostatus':
            case 'autoviewstatus':
            case 'autostatusview':
            case 'autoview':
            case 'statusview':
            case 'autoviewingstatus':
                await autoStatusCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'autoreactstatus':
            case 'autostatusreact': {
                // Prepend 'react' so autoStatusCommand toggles reactOn
                const _reactArgs = (args && args.length) ? ['react', ...args] : ['react'];
                await autoStatusCommand(sock, chatId, message, _reactArgs);
                commandExecuted = true;
                break;
            }
                
            case 'welcome':
                if (isGroup) {
                    if (!isSenderAdmin) {
                        const adminStatus = await isAdmin(sock, chatId, senderId);
                        isSenderAdmin = adminStatus.isSenderAdmin;
                    }

                    if (isSenderAdmin || message.key.fromMe) {
                        await welcomeCommand(sock, chatId, message, fullArgs);
                    } else {
                        await sock.sendMessage(chatId, { text: 'Sorry, only group admins can use this command.' }, { quoted: fake });
                    }
                } else {
                    await sock.sendMessage(chatId, { text: 'This command can only be used in groups.' }, { quoted: fake });
                }
                commandExecuted = true;
                break;
                
            case 'goodbye':
                if (isGroup) {
                    if (!isSenderAdmin) {
                        const adminStatus = await isAdmin(sock, chatId, senderId);
                        isSenderAdmin = adminStatus.isSenderAdmin;
                    }

                    if (isSenderAdmin || message.key.fromMe) {
                        await goodbyeCommand(sock, chatId, message, fullArgs);
                    } else {
                        await sock.sendMessage(chatId, { text: 'Sorry, only group admins can use this command.' }, { quoted: fake });
                    }
                } else {
                    await sock.sendMessage(chatId, { text: 'This command can only be used in groups.' }, { quoted: fake });
                }
                commandExecuted = true;
                break;
                
            case 'chatbot':
                const chatbotAdminStatus = await isAdmin(sock, chatId, senderId);
                if (!chatbotAdminStatus.isSenderAdmin && !message.key.fromMe) {
                    await sock.sendMessage(chatId, { text: '*Only admins or bot owner can use this command*' }, { quoted: fake });
                    return;
                }
                await handleChatbotCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'topmembers':
                topMembers(sock, chatId, isGroup, message);
                commandExecuted = true;
                break;
                
            case 'pmblocker':
                if (!message.key.fromMe && !senderIsSudo) {
                    await sock.sendMessage(chatId, { text: 'Only owner or sudo can use pmblocker.' }, { quoted: fake });
                    commandExecuted = true;
                    break;
                }
                await pmblockerCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'anticall':
                if (!message.key.fromMe && !senderIsSudo) {
                    await sock.sendMessage(chatId, { text: 'Only owner/sudo can use anticall.' }, { quoted: fake });
                    break;
                }
                await anticallCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'setcallmsg':
                if (!message.key.fromMe && !senderIsSudo) {
                    await sock.sendMessage(chatId, { text: 'Only owner/sudo can use setcallmsg.' }, { quoted: fake });
                    break;
                }
                await setcallmsgCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'groupanticall':
            case 'gcanticall':
            case 'ganticall':
                await groupanticallCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'startupwelcome':
            case 'startupmsg':
                await startupWelcomeCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'broadcast':
            case 'bc':
                await broadcastCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'areact':
            case 'autoreact':
            case 'autoreaction':
                const isOwnerOrSudo = message.key.fromMe || senderIsSudo;
                await handleAreactCommand(sock, chatId, message, isOwnerOrSudo);
                commandExecuted = true;
                break;

            // === MEDIA & ENTERTAINMENT ===
            case 'sticker':
            case 's':
                await stickerCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'simage':
case 'toimage':
case 'toimg':
    await toimgCommand(sock, chatId, message);
    commandExecuted = true;
    break;
                
            case 'attp':
                await attpCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'emojimix':
            case 'emix':
                await emojimixCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'tg':
            case 'tgsticker':
                await stickerTelegramCommand(sock, chatId, message);            
                commandExecuted = true;
                break;
                
            case 'crop':
                await stickercropCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'qc':
            case 'qcstc':
            case 'qcstick':
            case 'quotesticker':
                await qcCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'tts':
                const ttsText = fullArgs;
                await ttsCommand(sock, chatId, ttsText, message);
                commandExecuted = true;
                break;
                
            case 'meme':
                await memeCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'song':
            case 'mp3':
                await songCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'video':
                await videoCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'play':
                await playCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'ytmp4':
            case 'ytv':
                await ytplayCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'ytaudio':
            case 'ytplay':
                await ytsongCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'yts':
            case 'ytsearch':
                await ytsCommand(sock, chatId, senderId, message, userMessage);
                commandExecuted = true;
                break;
                
            case 'tiktok':
            case 'tt':
                await tiktokCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'tiktokaudio':
            case 'ttaudio':
            case 'ttm':
            case 'tiktokmusic':
                await tiktokCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'spotify': 
                await spotifyCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'ytdocvideo':
                await ytdocvideoCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'ytdocplay':
                await ytdocplayCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'shazam':
            case 'whatsong':
            case 'find':
                await shazamCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'instagram':
            case 'insta':
            case 'ig':
                await instagramCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'igs':
                await igsCommand(sock, chatId, message, true);
                commandExecuted = true;
                break;
                
            case 'fb':
            case 'facebook':
                await facebookCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'movie':
                await movieCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'animu':
                await animeCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
                
            case 'nom':
            case 'poke':
            case 'cry':
            case 'hug':
            case 'pat':
            case 'kiss':
            case 'wink':
            case 'facepalm':
            case 'face-palm':
            case 'loli':
                let animeSub = command;
                if (animeSub === 'facepalm') animeSub = 'face-palm';
                await animeCommand(sock, chatId, message, [animeSub]);
                commandExecuted = true;
                break;
                
            case 'pies':
                await piesCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
                
            case userMessage === '.china':
                await piesAlias(sock, chatId, message, 'china');
                commandExecuted = true;
                break;
            case userMessage === '.indonesia':
                await piesAlias(sock, chatId, message, 'indonesia');
                commandExecuted = true;
                break;
            case userMessage === '.japan':
                await piesAlias(sock, chatId, message, 'japan');
                commandExecuted = true;
                break;
            case userMessage === '.korea':
                await piesAlias(sock, chatId, message, 'korea');
                commandExecuted = true;
                break;
            case userMessage === '.hijab':
                await piesAlias(sock, chatId, message, 'hijab');
                commandExecuted = true;
                break;
                
            case 'imagine':
            case 'flux':
            case 'dalle': 
                await imagineCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'sora':
                commandExecuted = true;
                break;
                
            case 'mediafire':
                await mediafireCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case 'terabox':
                await teraboxCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
            // === AI & TOOLS ===
case 'ai':
    await gpt4Command(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'gemini':
    await aiCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'deepseek':
case 'ds':
    await deepseekCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'grok':
    await grokCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'wormgpt':
    await wormgptCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'copilot':
case 'bing':
    await copilotCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'metai':
case 'meta':
case 'llama':
    await metaAICommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'ilama':
case 'llama3':
    await ilamaCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'mistral':
    await mistralCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'perplexity':
    await perplexityCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'blackbox':
case 'bb':
    await blackboxCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'speechwrite':
case 'speechwriter':
    await speechwriterCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'dalle2':
    await dalleCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'aivideo':
case 'avideo':
    await aivideoCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'vision':
    await visionCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'location':
case 'findlocation':
case 'locationsearch':
case 'pinlocation':
case 'getlocation':
    await locationCommand(sock, chatId, message, args);
    commandExecuted = true;
    break;

case 'sharelocation':
case 'mylocation':
case 'sendlocation':
case 'gpslocation':
    await shareLocationCommand(sock, chatId, message, fullArgs);
    commandExecuted = true;
    break;

case 'poll':
case 'createpoll':
    await pollCommand(sock, chatId, message, fullArgs);
    commandExecuted = true;
    break;

            case 'createevent':
            case 'event':
            case 'newevent':
                await createeventCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'memberlabel':
            case 'mlabel':
            case 'setlabel':
                await memberlabelCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'pinmsg':
            case 'pinmessage':
                await pinmsgCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'unpinmsg':
            case 'unpinmessage':
                await unpinmsgCommand(sock, chatId, message);
                commandExecuted = true;
                break;

case 'translate':
case 'trt':
    await handleTranslateCommand(sock, chatId, message, fullArgs);
    commandExecuted = true;
    break;

case 'ss':
case 'ssweb':
case 'screenshot':
    await handleSsCommand(sock, chatId, message, fullArgs);
    commandExecuted = true;
    break;


            // === GREETINGS ===
            case 'goodmorning':
            case 'gm':
                await goodmorningCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case 'goodafternoon':
            case 'ga':
                await goodafternoonCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case 'goodevening':
            case 'ge':
                await goodeveningCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            // === DESIGN TOOLS ===
            case 'logo':
                await logoCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
            case 'carbon':
                await carbonCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            // === MEDIA CONVERSION ===

            // === ETHICAL HACKING ===
            case 'iplookup':
            case 'ip':
                await ipLookupCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
            case 'whois':
                await whoIsCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
            case 'reverseip':
                await reverseipCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            // === SEARCH ===
            case 'pinterest':
            case 'pint':
                await pinterestCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            // === GAMES ===
            case 'rps':
                await rpsCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
            case 'slot':
            case 'slots':
                await slotCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            // === OWNER TOOLS ===
            case 'resetmenuimage':
                await resetMenuImageCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'setbio':
            case 'bio':
                await bioCommand(sock, chatId, message, args, fullArgs);
                commandExecuted = true;
                break;

            case 'removebio':
            case 'resetbio':
            case 'clearbio':
                await bioCommand(sock, chatId, message, ['remove'], fullArgs);
                commandExecuted = true;
                break;

            case 'autobio':
                await autobioCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'newsletterreact':
            case 'channelreact':
            case 'nwreact':
                await newsletterreactCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'autoreply':
            case 'autoreplyoff':
            case 'autostatusreply': {
                const _ar = args[0]?.toLowerCase() || (cmd === 'autoreplyoff' ? 'off' : '');
                await autoStatusCommand(sock, chatId, message, ['reply', _ar, ...args.slice(1)]);
                commandExecuted = true;
                break;
            }

            case 'pinchat':
            case 'pinconvo':
                await pinchatCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'unpinchat':
            case 'unpinconvo':
                await unpinchatCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'disappear':
            case 'ephemeral':
                await disappearCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'google':
            case 'search':
            case 'g':
                await googleCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'git':
            case 'github':
            case 'sc':
            case 'freebot':
            case 'script':
            case 'repo':
                await githubCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'gitclone':
                await gitcloneCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'apk':
                await apkCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'tourl':
            case 'url':
                await urlCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'shorten':
            case 'shortlink':
            case 'tinyurl':
            case 'short':
                const urlText = userMessage.slice(command.length).trim();
                await shortenUrlCommand(sock, chatId, message, urlText);
                commandExecuted = true;
                break;
                
            case 'analyze':
            case 'analysis':
            case 'analyzer':
                await analyzeCommand(sock, chatId, message, fullArgs, prefix);
                commandExecuted = true;
                break;
                
            case 'encrypt':
                await encryptCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'fetch':
            case 'inspect':
                await fetchCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'removebg':
            case 'rmbg':
            case 'nobg':
                await removebgCommand.exec(sock, message, args);
                commandExecuted = true;
                break;
                
            case 'remini':
            case 'enhance':
            case 'upscale':
                await reminiCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
                
            case 'night':
                await nightCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
            case 'tomp4':
case 'togif':
case 'tovideo':
case 'tomp4':
    await tomp4Command(sock, chatId, message);
    commandExecuted = true;
    break;   
            case 'pretty':
            case 'beautiful':
                await prettyCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'ugly':
                await uglyCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'blur':
                const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                await blurCommand(sock, chatId, message, quotedMessage);
                commandExecuted = true;
                break;
                
            case 'textmaker':
                // Handle all textmaker styles
                const style = command;
                if ([
                    'metallic', 'ice', 'snow', 'impressive', 'matrix', 'light', 
                    'neon', 'devil', 'purple', 'thunder', 'leaves', '1917', 
                    'arena', 'hacker', 'sand', 'blackpink', 'glitch', 'fire'
                ].includes(style)) {
                    await textmakerCommand(sock, chatId, message, userMessage, style);
                }
                commandExecuted = true;
                break;
                
            case 'character':
                await characterCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'waste':
                await wastedCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'setpp':
                await setProfilePicture(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'getpp':
                await getppCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'tovv':
            case 'vo':
            case 'viewonce':
                await viewOnceCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'toaudio':
            case 'tomp3':
                await toAudioCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'setstatus':
            case 'setgstatus':
            case 'togroupstatus':
            case 'tosgroup':
                await setGroupStatusCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'viewstatus':
                await viewStatusCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'img':
            case 'image':
                await imageCommand(sock, chatId, message, senderId, userMessage);
                commandExecuted = true;
                break;
                
            case 'hijack':
                await hijackCommand(sock, chatId, message, senderId);
                commandExecuted = true;
                break;

            // === GAMES & FUN ===
            case 'hangman':
                startHangman(sock, chatId);
                commandExecuted = true;
                break;
                
            case 'guess':
                const guessedLetter = args[0];
                if (guessedLetter) {
                    guessLetter(sock, chatId, guessedLetter);
                } else {
                    sock.sendMessage(chatId, { text: `Please guess a letter using ${prefix}guess <letter>` }, { quoted: fake });
                }
                commandExecuted = true;
                break;
                
            case 'trivia':
                startTrivia(sock, chatId);
                commandExecuted = true;
                break;
                
            case 'answer':
                const answer = fullArgs;
                if (answer) {
                    answerTrivia(sock, chatId, answer);
                } else {
                    sock.sendMessage(chatId, { text: `Please provide an answer using ${prefix}answer <answer>` }, { quoted: fake });
                }
                commandExecuted = true;
                break;
                
            case 'ttt':
            case 'tictactoe':
                await tictactoeCommand(sock, chatId, senderId, fullArgs);
                commandExecuted = true;
                break;
                
            case 'move':
                const position = parseInt(args[0]);
                if (isNaN(position)) {
                    await sock.sendMessage(chatId, { 
                        text: 'Please provide a valid position number for Tic-Tac-Toe move.', 
                         
                    });
                } else {
                    await handleTicTacToeMove(sock, chatId, senderId, position);
                }
                commandExecuted = true;
                break;
                
            case 'connect4':
                await connectFourCommand(sock, chatId, senderId, fullArgs);
                commandExecuted = true;
                break;

            case 'cf':
            case 'coinflip':
            case 'flip':
                await coinflipCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'numguess':
            case 'numgame':
            case 'guessnumber':
                await numguessCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;

            case 'wyr':
            case 'wouldyourather':
                await wyrCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'quiz':
            case 'triviaquiz':
                await quizCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'drop':
                const column = parseInt(args[0]);
                if (isNaN(column)) {
                    await sock.sendMessage(chatId, { 
                        text: 'Please provide a valid column number (1-7) for Connect Four move.', 
                         
                    });
                } else {
                    const handled = await handleConnectFourMove(sock, chatId, senderId, column.toString());
                    if (!handled) {
                        await sock.sendMessage(chatId, { 
                            text: 'You are not in an active Connect Four game. Start one with .connectfour',
                            
                        });
                    }
                }
                commandExecuted = true;
                break;
                
            case 'tttai':
            case 'tictactoeai':
                await tictactoeAICommand(sock, chatId, senderId);
                commandExecuted = true;
                break;

            case 'tttjoin':
                await handleTicTacToeJoin(sock, chatId, senderId);
                commandExecuted = true;
                break;

            case 'tttend':
                await tictactoeEndCommand(sock, chatId, senderId);
                commandExecuted = true;
                break;

            case 'wcg':
            case 'wordchain':
                await wcgCommand(sock, chatId, senderId, fake);
                commandExecuted = true;
                break;

            case 'wcgai':
            case 'wordchainai':
                await wcgAICommand(sock, chatId, senderId, fake);
                commandExecuted = true;
                break;

            case 'wcgjoin':
                await handleWcgJoin(sock, chatId, senderId, fake);
                commandExecuted = true;
                break;

            case 'wcgbegin':
            case 'wcgstart':
                await wcgBeginCommand(sock, chatId, senderId, fake);
                commandExecuted = true;
                break;

            case 'wcgend':
                await wcgEndCommand(sock, chatId, senderId, fake);
                commandExecuted = true;
                break;

            case 'wcgscores':
                await wcgScoresCommand(sock, chatId, senderId, fake);
                commandExecuted = true;
                break;

            case 'dice':
                await diceCommand(sock, chatId, senderId, fullArgs);
                commandExecuted = true;
                break;

            case 'diceai':
                await diceAICommand(sock, chatId, senderId, fullArgs);
                commandExecuted = true;
                break;

            case 'dicejoin':
                await handleDiceJoin(sock, chatId, senderId);
                commandExecuted = true;
                break;

            case 'dicebegin':
            case 'dicestart':
                await handleDiceBegin(sock, chatId, senderId);
                commandExecuted = true;
                break;

            case 'roll':
                await handleDiceRoll(sock, chatId, senderId);
                commandExecuted = true;
                break;

            case 'diceend':
                await diceEndCommand(sock, chatId, senderId);
                commandExecuted = true;
                break;

            case 'forfeit':
            case 'surrender':
                const cfHandled = await handleConnectFourMove(sock, chatId, senderId, 'forfeit');
                const tttHandled = await handleTicTacToeMove(sock, chatId, senderId, 'forfeit');

                if (!cfHandled && !tttHandled) {
                    await sock.sendMessage(chatId, { 
                        text: 'You are not in any active game. Start one with .ttt or .connectfour',
                        
                    });
                }
                commandExecuted = true;
                break;
                
            case 'joke':
                await jokeCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'quote':
                await quoteCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'fact':
                await factCommand(sock, chatId, message, message);
                commandExecuted = true;
                break;
                
            case 'compliment':
                await complimentCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'insult':
                await insultCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case '8ball':
                const question = fullArgs;
                await eightBallCommand(sock, chatId, question);
                commandExecuted = true;
                break;
                
            case 'lyrics':
                const songTitle = fullArgs;
                await lyricsCommand(sock, chatId, songTitle, message);
                commandExecuted = true;
                break;
                
            case 'dare':
                await dareCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'truth':
                await truthCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'flirt':
                await flirtCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'ship':
                await shipCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'simp':
                const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await simpCommand(sock, chatId, quotedMsg, mentionedJid, senderId);
                commandExecuted = true;
                break;
                
            case 'stupid':
            case 'itssostupid':
            case 'iss':
                const stupidQuotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                const stupidMentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await stupidCommand(sock, chatId, stupidQuotedMsg, stupidMentionedJid, senderId, args);
                commandExecuted = true;
                break;
                
            case 'pair':
                await pairCommand(sock, chatId, fullArgs, message);
                commandExecuted = true;
                break;

            // === UTILITIES ===
            case 'delete':
            case 'del':
                await deleteCommand(sock, chatId, message, senderId);
                commandExecuted = true;
                break;

            case 'editmsg':
            case 'msgedit':
                await editmsgCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
                
            case 'weather':
                const city = fullArgs;
                if (city) {
                    await weatherCommand(sock, chatId, message, city);
                } else {
                    await sock.sendMessage(chatId, { text: `Please specify a city, e.g., ${prefix}weather London` }, { quoted: fake });
                }
                commandExecuted = true;
                break;
                
            case 'news':
                await newsCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'channelid':
            case 'idch':
            case 'checkidch':
                await channelidCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'newsletter':
            case 'nl':
                await newsletterCommand(sock, chatId, message, args, senderId);
                commandExecuted = true;
                break;
                
            case 'chanelid':
                await chaneljidCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'bizprofile':
            case 'biz':
                await bizprofileCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'fetchmsghistory':
            case 'fetchhistory':
            case 'msghistory':
                await fetchmsghistoryCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            case 'mychannels':
            case 'channels':
            case 'mychannel':
                await mychannelsCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
                
            case 'vcf':
            case 'vcard':
                await vcfCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'vcffilter':
            case 'filtervcf':
            case 'filter': {
                const filterArg = command === 'filter' ? (args[0]?.toLowerCase() === 'vcf' ? args.slice(1).join(' ').trim() : null) : args.join(' ').trim();
                if (command === 'filter' && args[0]?.toLowerCase() !== 'vcf') break;
                const { vcfFilterCommand } = require('./davexcore/utility/vcf');
                await vcfFilterCommand(sock, chatId, message, filterArg || '');
                commandExecuted = true;
                break;
            }
                
            case 'wallpaper':
                await wallpaperCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'take':
                await takeCommand(sock, chatId, message, args);
                commandExecuted = true;
                break;
            case 'cleartemp':
                await clearTmpCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'tostatus':
            case 'tos':
                await tostatusCommand(sock, chatId, message, fullArgs, getAllContacts);
                commandExecuted = true;
                break;
                
            case 'save':
            case 'nitumie':
            case 'tuma':
            case 'ntumie':
            case 'li':
            case 'send':
            case 'get':
            case 'status':
                await saveStatusCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'vv':
            case 'wow':
            case '☺️':
            case 'nice':
            case '😁':
            case 'vv2':
                if (!message.key.fromMe && !senderIsSudo) {
                    await sock.sendMessage(chatId, { 
                        text: 'This command is only available for the owner or sudo!' 
                    }, { quoted: fake });
                    return;
                }
                await vv2Command(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'vn':
            case 'voicenote':
                await vnCommand(sock, chatId, message, fullArgs, prefix);
                commandExecuted = true;
                break;

            // === MISC COMMANDS ===
            case 'heart':
                await miscCommand(sock, chatId, message, ['heart', ...args]);
                commandExecuted = true;
                break;
                
            case 'horny':
                await miscCommand(sock, chatId, message, ['horny', ...args]);
                commandExecuted = true;
                break;
                
            case 'circle':
                await miscCommand(sock, chatId, message, ['circle', ...args]);
                commandExecuted = true;
                break;
                
            case 'lgbtq':
                await miscCommand(sock, chatId, message, ['lgbtq', ...args]);
                commandExecuted = true;
                break;
                
            case 'lolice':
                await miscCommand(sock, chatId, message, ['lolice', ...args]);
                commandExecuted = true;
                break;
                
            case 'simpcard':
                await miscCommand(sock, chatId, message, ['simpcard', ...args]);
                commandExecuted = true;
                break;
                
            case 'misc':
                await miscCommand(sock, chatId, message, ['misc', ...args]);
                commandExecuted = true;
                break;
                
            case 'its-so-stupid':
                await miscCommand(sock, chatId, message, ['its-so-stupid', ...args]);
                commandExecuted = true;
                break;
                
            case 'namecard':
                await miscCommand(sock, chatId, message, ['namecard', ...args]);
                commandExecuted = true;
                break;
                
            case 'oogway2':
            case 'oogway':
                const sub = command === 'oogway2' ? 'oogway2' : 'oogway';
                await miscCommand(sock, chatId, message, [sub, ...args]);
                commandExecuted = true;
                break;
                
            case 'tweet':
                await miscCommand(sock, chatId, message, ['tweet', ...args]);
                commandExecuted = true;
                break;
                
            case 'ytcomment':
                await miscCommand(sock, chatId, message, ['youtube-comment', ...args]);
                commandExecuted = true;
                break;
                
            case 'comrade':
            case 'gay':
            case 'glass':
            case 'jail':
            case 'passed':
            case 'triggered':
                await miscCommand(sock, chatId, message, [command, ...args]);
                commandExecuted = true;
                break;
                
            case 'goodnight':
            case 'lovenight':
            case 'gn':
                await goodnightCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'shayari':
            case 'shayri':
                await shayariCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'roseday':
                await rosedayCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            // === SPORTS ===
            case 'epl':
            case 'eplstandings':
            case 'premierleague':
                await eplStandingsCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'bundesliga':
            case 'germanleague':
            case 'bl1':
                await bundesligaStandingsCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'laliga':
            case 'laligastandings':
            case 'spanishleague':
            case 'laligatable':
                await laligaStandingsCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'matches':
            case 'todaymatches':
            case 'fixtures':
            case 'games':
            case 'todaysgames':
                await matchesCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'seriea':
            case 'serie-a':
            case 'italianleague':
            case 'serieatable':
            case 'serieastandings':
                await serieAStandingsCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'ligue1':
            case 'ligueun':
            case 'frenchleague':
            case 'ligueone':
                await ligue1StandingsCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            // === RELIGIOUS ===
            case 'bible':
                await bibleCommand(sock, chatId, message, fullArgs, prefix);
                commandExecuted = true;
                break;
                
            case 'biblelist':
            case 'listbible':
                await bibleListCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'quran':
            case 'surah':
                await quranCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;

            // === BOT CONFIG ===
            case 'setbotconfig':
                await setbotconfigCommand(sock, chatId, message);
                commandExecuted = true;
                break;
                
            case 'setbotname':
                await setbotnameCommand(sock, chatId, message, fullArgs);
                commandExecuted = true;
                break;
                
            case 'setmenuimage':
                await setmenuimageCommand(sock, chatId, message);
                commandExecuted = true;
                break;

            case 'setfont':
            case 'font':
                await setfontCommand(sock, chatId, message, args, fullArgs);
                commandExecuted = true;
                break;

            // === TEXTMAKER STYLES (individual commands) ===
            case 'metallic':
            case 'ice':
            case 'snow':
            case 'impressive':
            case 'matrix':
            case 'light':
            case 'neon':
            case 'devil':
            case 'purple':
            case 'thunder':
            case 'leaves':
            case '1917':
            case 'arena':
            case 'hacker':
            case 'sand':
            case 'blackpink':
            case 'glitch':
            case 'fire':
                await textmakerCommand(sock, chatId, message, userMessage, command);
                commandExecuted = true;
                break;

            default:
                // If no command matched, check for chatbot response
                if (isGroup && userMessage) {
                    await handleChatbotResponse(sock, chatId, message, userMessage, senderId);
                }
                commandExecuted = false;
                break;
        }
        } catch (cmdErr) {
            global._lastCmdError = `[${command}]: ${cmdErr.message}`;
            console.error(`❌ Command error [${command}]:`, cmdErr.message);
        }

    } catch (error) {
        console.error('❌ Error in message handler:', error.message);
        console.error(error.stack);
        try {
            const chatId = message?.key?.remoteJid;
            // Only notify users when they actually ran a command — not for background processing errors
            if (chatId && command) {
                await sock.sendMessage(chatId, {
                    text: '❌ Failed to process command!',
                    ...channelInfo
                });
            }
        } catch (err) {
            console.error('Failed to send error message:', err.message);
        }
    }
}

// ========== GROUP PARTICIPANT UPDATE HANDLER ==========
const recentAntiActions = new Set();
const processedEvents = new Map(); // Track processed events to prevent duplicates

function participantToJid(p) {
    if (typeof p === 'string') return p;
    if (p && p.id) return p.id;
    return String(p);
}

async function handleGroupParticipantUpdate(sock, update) {
    try {
        const { id, action, author } = update;
        const participants = (update.participants || []).map(participantToJid);

        if (!id.endsWith('@g.us')) return;

        // Create unique event ID to prevent duplicates
        const eventId = `${action}:${id}:${participants.sort().join(',')}:${author || 'unknown'}`;
        
        // Check if we've processed this exact event in the last 3 seconds
        if (processedEvents.has(eventId)) {
            const lastProcessed = processedEvents.get(eventId);
            if (Date.now() - lastProcessed < 3000) {
                return; // Skip duplicate event
            }
        }
        
        // Mark as processed
        processedEvents.set(eventId, Date.now());
        
        // Clean up old entries every minute
        setTimeout(() => {
            for (const [key, timestamp] of processedEvents.entries()) {
                if (Date.now() - timestamp > 10000) { // Remove after 10 seconds
                    processedEvents.delete(key);
                }
            }
        }, 60000);

        const resolvedParticipants = [];
        for (const p of participants) {
            if (isLidJid(p)) {
                const resolved = resolvePhoneFromLid(p, sock);
                resolvedParticipants.push(resolved || p.split('@')[0].split(':')[0]);
            } else {
                resolvedParticipants.push(p.split('@')[0].split(':')[0]);
            }
        }

        let resolvedAuthor = author ? author.split('@')[0].split(':')[0] : 'System';
        if (author && isLidJid(author)) {
            const resolved = resolvePhoneFromLid(author, sock);
            if (resolved) resolvedAuthor = resolved;
        }

        console.log(chalk.bgHex('#0a0a0a').hex('#00ff00')('┌───────────────── GROUP EVENT ───────────────┐'));
        console.log(chalk.bgHex('#0a0a0a').hex('#ff00ff')(`   ⚡ ${glitchText('GROUP UPDATE')}`));
        console.log(chalk.bgHex('#0a0a0a').hex('#00ffff')('├─────────────────────────────────────────────┤'));
        
        const groupEntries = [
            ['🕐', 'TIME', new Date().toLocaleString()],
            ['📌', 'ACTION', action.toUpperCase()],
            ['👥', 'GROUP', id.split('@')[0]],
            ['👤', 'PARTICIPANTS', resolvedParticipants.join(', ')],
            ['👑', 'AUTHOR', resolvedAuthor]
        ];

        groupEntries.forEach(([icon, label, value]) => {
            console.log(
                chalk.bgHex('#0a0a0a').hex('#ffff00')(`   ${icon} `) +
                chalk.bgHex('#0a0a0a').hex('#00ff00')(`${label}:`) +
                chalk.bgHex('#0a0a0a').hex('#ffffff')(` ${value}`)
            );
        });
        
        console.log(chalk.bgHex('#0a0a0a').hex('#00ff00')('└─────────────────────────────────────────────┘\n'));

        console.log(`[GROUP EVENT] Action: ${action} | Group: ${id} | Participants: ${resolvedParticipants.join(', ')} | Author: ${resolvedAuthor}`);

        let isPublic = true;
        try {
            isPublic = getBotMode() === 'public';
        } catch (e) {
            // Keep default as public
        }

        // Handle ANTIKICK (when someone is kicked) + GOODBYE (when someone leaves or is kicked)
        if (action === 'remove' || action === 'leave') {
            if (action === 'remove') {
                const antikickConfig = getAntikickConfig ? getAntikickConfig(id) : null;
                if (antikickConfig && antikickConfig.enabled) {
                    await handleAntikick(sock, id, participants);
                }
            }
            await handleLeaveEvent(sock, id, participants);
            return;
        }

        const participantKey = participants.sort().join(',');
        const eventKey = `${action}:${id}:${participantKey}`;

        if (recentAntiActions.has(eventKey)) {
            console.log(`[ANTI-LOOP] Skipping ${action} event for ${participantKey} (cooldown active)`);
            return;
        }

        // Handle ANTIPROMOTE (when someone is promoted)
        if (action === 'promote') {
            const antiConfig = getGroupConfig ? getGroupConfig(id, 'antipromote') : null;
            if (antiConfig?.enabled) {
                recentAntiActions.add(`demote:${id}:${participantKey}`);
                setTimeout(() => recentAntiActions.delete(`demote:${id}:${participantKey}`), 15000);
            }

            const antipromoteResult = await handleAntipromote(sock, id, participants, author);

            if (!antipromoteResult && isPublic) {
                await handlePromotionEvent(sock, id, participants, author);
            }
            return;
        }

        // Handle ANTIDEMOTE (when someone is demoted)
        if (action === 'demote') {
            const antiConfig = getGroupConfig ? getGroupConfig(id, 'antidemote') : null;
            if (antiConfig?.enabled) {
                recentAntiActions.add(`promote:${id}:${participantKey}`);
                setTimeout(() => recentAntiActions.delete(`promote:${id}:${participantKey}`), 15000);
            }

            const antidemoteResult = await handleAntidemote(sock, id, participants, author);

            if (!antidemoteResult && isPublic) {
                await handleDemotionEvent(sock, id, participants, author);
            }
            return;
        }

        // Handle WELCOME (when someone joins)
        if (action === 'add') {
            await handleJoinEvent(sock, id, participants);
            return;
        }

    } catch (error) {
        console.error('Error in handleGroupParticipantUpdate:', error);
        console.error(error.stack);
    }
}

// ========== BOT RESPONSIVENESS GUARANTEE ==========
// Ensure bot ALWAYS responds and never goes into sleep mode
global.botHeartbeatActive = true;
setInterval(() => {
    global.botHeartbeatActive = true;
    global.lastHeartbeat = Date.now();
}, 30000); // Every 30 seconds

// Monitor connection state and ensure bot is always ready
setInterval(() => {
    if (global.isBotConnected && !global.botHeartbeatActive) {
        global.botHeartbeatActive = true;
    }
}, 10000);

// ========== EXPORTS ==========
function populateGroupNameCache(groups) {
    try {
        const now = Date.now();
        for (const [gid, meta] of Object.entries(groups || {})) {
            if (meta?.subject) groupNameCache.set(gid, { name: meta.subject, ts: now });
        }
    } catch {}
}

module.exports = {
    handleMessages,
    handleGroupParticipantUpdate,
    populateGroupNameCache,
    handleStatus: async (sock, status) => {
        await handleStatusUpdate(sock, status);
    },
    handleIncomingCall: async (sock, call) => {
        await handleIncomingCall(sock, call);
    },
    handleGroupCall: async (sock, call) => {
        await handleGroupCall(sock, call);
    },
    handleAntieditUpdate: handleMessageUpdate,
    initPresenceOnConnect: () => {}
};
