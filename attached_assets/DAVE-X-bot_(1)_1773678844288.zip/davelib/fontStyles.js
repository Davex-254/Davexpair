// ========== DAVE-X FONT STYLE SYSTEM ==========
// Converts ASCII text to Unicode font variants for WhatsApp

const FONT_STYLES = {
    none: {
        name: 'Default',
        description: 'Normal text, no style',
        preview: 'Hello World',
        convert: (text) => text
    },
    bold: {
        name: 'Bold',
        description: 'WhatsApp bold formatting',
        preview: '*Hello World*',
        convert: (text) => text // Applied via WA markdown prefix/suffix
    },
    italic: {
        name: 'Italic',
        description: 'WhatsApp italic formatting',
        preview: '_Hello World_',
        convert: (text) => text
    },
    strikethrough: {
        name: 'Strikethrough',
        description: 'Slashed through text',
        preview: '~Hello World~',
        convert: (text) => text
    },
    mono: {
        name: 'Monospace',
        description: 'Code/monospace style',
        preview: '```Hello World```',
        convert: (text) => text
    },
    serif_bold: {
        name: 'Serif Bold',
        description: 'Bold serif unicode font',
        preview: '𝐇𝐞𝐥𝐥𝐨 𝐖𝐨𝐫𝐥𝐝',
        map: {
            upper: 0x1D400 - 65,
            lower: 0x1D41A - 97,
            digits: 0x1D7CE - 48
        }
    },
    serif_italic: {
        name: 'Serif Italic',
        description: 'Italic serif unicode font',
        preview: '𝐻𝑒𝑙𝑙𝑜 𝑊𝑜𝑟𝑙𝑑',
        map: {
            upper: 0x1D434 - 65,
            lower: 0x1D44E - 97
        },
        special_lower: { h: '\u{1D489}' }
    },
    serif_bold_italic: {
        name: 'Serif Bold Italic',
        description: 'Bold italic serif unicode font',
        preview: '𝑯𝒆𝒍𝒍𝒐 𝑾𝒐𝒓𝒍𝒅',
        map: {
            upper: 0x1D468 - 65,
            lower: 0x1D482 - 97
        }
    },
    script: {
        name: 'Script',
        description: 'Handwriting/cursive style',
        preview: '𝒽𝑒𝓁𝓁𝑜 𝒲𝑜𝓇𝓁𝒹',
        map: {
            upper: 0x1D49C - 65,
            lower: 0x1D4B6 - 97
        },
        special_upper: { B: '\u212C', E: '\u2130', F: '\u2131', H: '\u210B', I: '\u2110', L: '\u2112', M: '\u2133', R: '\u211B' },
        special_lower: { e: '\u212F', g: '\u210A', o: '\u2134' }
    },
    bold_script: {
        name: 'Bold Script',
        description: 'Bold cursive/handwriting style',
        preview: '𝓗𝓮𝓵𝓵𝓸 𝓦𝓸𝓻𝓵𝓭',
        map: {
            upper: 0x1D4D0 - 65,
            lower: 0x1D4EA - 97
        }
    },
    fraktur: {
        name: 'Fraktur',
        description: 'Gothic/old German style',
        preview: '𝔥𝔢𝔩𝔩𝔬 𝔚𝔬𝔯𝔩𝔡',
        map: {
            upper: 0x1D504 - 65,
            lower: 0x1D51E - 97
        },
        special_upper: { C: '\u212D', H: '\u210C', I: '\u2111', R: '\u211C', Z: '\u2128' }
    },
    double_struck: {
        name: 'Double Struck',
        description: 'Mathematical hollow letters',
        preview: '𝕙𝕖𝕝𝕝𝕠 𝕎𝕠𝕣𝕝𝕕',
        map: {
            upper: 0x1D538 - 65,
            lower: 0x1D552 - 97,
            digits: 0x1D7D8 - 48
        },
        special_upper: { C: '\u2102', H: '\u210D', N: '\u2115', P: '\u2119', Q: '\u211A', R: '\u211D', Z: '\u2124' }
    },
    sans: {
        name: 'Sans Serif',
        description: 'Clean sans-serif unicode font',
        preview: '𝖧𝖾𝗅𝗅𝗈 𝖶𝗈𝗋𝗅𝖽',
        map: {
            upper: 0x1D5A0 - 65,
            lower: 0x1D5BA - 97,
            digits: 0x1D7E2 - 48
        }
    },
    sans_bold: {
        name: 'Sans Bold',
        description: 'Bold sans-serif unicode font',
        preview: '𝗛𝗲𝗹𝗹𝗼 𝗪𝗼𝗿𝗹𝗱',
        map: {
            upper: 0x1D5D4 - 65,
            lower: 0x1D5EE - 97,
            digits: 0x1D7EC - 48
        }
    },
    sans_italic: {
        name: 'Sans Italic',
        description: 'Italic sans-serif unicode font',
        preview: '𝘏𝘦𝘭𝘭𝘰 𝘞𝘰𝘳𝘭𝘥',
        map: {
            upper: 0x1D608 - 65,
            lower: 0x1D622 - 97
        }
    },
    sans_bold_italic: {
        name: 'Sans Bold Italic',
        description: 'Bold italic sans-serif unicode font',
        preview: '𝙃𝙚𝙡𝙡𝙤 𝙒𝙤𝙧𝙡𝙙',
        map: {
            upper: 0x1D63C - 65,
            lower: 0x1D656 - 97
        }
    },
    monospace_uni: {
        name: 'Monospace',
        description: 'Unicode monospace font',
        preview: '𝙷𝚎𝚕𝚕𝚘 𝚆𝚘𝚛𝚕𝚍',
        map: {
            upper: 0x1D670 - 65,
            lower: 0x1D68A - 97,
            digits: 0x1D7F6 - 48
        }
    },
    fullwidth: {
        name: 'Fullwidth',
        description: 'Wide/fullwidth characters',
        preview: 'Ｈｅｌｌｏ Ｗｏｒｌｄ',
        map: {
            upper: 0xFF21 - 65,
            lower: 0xFF41 - 97,
            digits: 0xFF10 - 48
        }
    }
};

// WhatsApp markdown wrappers (applied around line-by-line text blocks)
const WA_WRAPPERS = {
    bold:          { prefix: '*', suffix: '*' },
    italic:        { prefix: '_', suffix: '_' },
    strikethrough: { prefix: '~', suffix: '~' },
    mono:          { prefix: '```', suffix: '```' }
};

function convertChar(char, style) {
    const code = char.charCodeAt(0);
    const isUpper = code >= 65 && code <= 90;
    const isLower = code >= 97 && code <= 122;
    const isDigit = code >= 48 && code <= 57;

    // Check special character overrides first
    if (isUpper && style.special_upper?.[char]) return style.special_upper[char];
    if (isLower && style.special_lower?.[char]) return style.special_lower[char];

    if (!style.map) return char;

    if (isUpper && style.map.upper !== undefined) {
        return String.fromCodePoint(code + style.map.upper);
    }
    if (isLower && style.map.lower !== undefined) {
        return String.fromCodePoint(code + style.map.lower);
    }
    if (isDigit && style.map.digits !== undefined) {
        return String.fromCodePoint(code + style.map.digits);
    }
    return char;
}

function applyUnicodeFont(text, styleName) {
    const style = FONT_STYLES[styleName];
    if (!style || !style.map) return text;
    return [...text].map(char => convertChar(char, style)).join('');
}

function applyWAWrapper(text, styleName) {
    const wrapper = WA_WRAPPERS[styleName];
    if (!wrapper) return text;
    // Apply line by line to preserve structure
    const lines = text.split('\n');
    return lines.map(line => {
        const trimmed = line.trim();
        if (!trimmed) return line;
        // Don't double-wrap lines already wrapped in WA markdown
        if (trimmed.startsWith(wrapper.prefix) && trimmed.endsWith(wrapper.suffix)) return line;
        // Preserve leading whitespace
        const leading = line.match(/^(\s*)/)?.[1] || '';
        return `${leading}${wrapper.prefix}${trimmed}${wrapper.suffix}`;
    }).join('\n');
}

function applyBotFont(text, styleName) {
    if (!text || !styleName || styleName === 'none') return text;
    // WhatsApp markdown wrappers
    if (WA_WRAPPERS[styleName]) return applyWAWrapper(text, styleName);
    // Unicode font substitution
    if (FONT_STYLES[styleName]?.map) return applyUnicodeFont(text, styleName);
    return text;
}

function getStyleList() {
    return Object.entries(FONT_STYLES).map(([key, val]) => ({
        key,
        name: val.name,
        description: val.description,
        preview: val.preview || applyBotFont('Hello World', key)
    }));
}

module.exports = { FONT_STYLES, applyBotFont, getStyleList };
