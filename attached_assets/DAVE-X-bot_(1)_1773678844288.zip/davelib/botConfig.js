const { getOwnerConfig, setOwnerConfig } = require('../Database/settingsStore');

const defaultConfig = {
    botName: 'DAVE-X',
    menuImage: '',
    menuVideo: '',
    ownerName: 'Dave',
    welcomeMessage: 'Welcome to the group!',
    goodbyeMessage: 'Goodbye!',
    antideletePrivate: true,
    botFont: 'none'
};

function getConfig() {
    try {
        const stored = getOwnerConfig('botconfig');
        return { ...defaultConfig, ...(stored || {}) };
    } catch (error) {
        console.error('Error getting bot config:', error.message, 'Line:', error.stack?.split('\n')[1]);
        return defaultConfig;
    }
}

function saveConfig(config) {
    try {
        setOwnerConfig('botconfig', config);
    } catch (error) {
        console.error('Error saving bot config:', error.message, 'Line:', error.stack?.split('\n')[1]);
    }
}

function getBotName()       { return getConfig().botName; }
function setBotName(name)   { const c = getConfig(); c.botName = name; saveConfig(c); }

function getMenuImage()     { return getConfig().menuImage; }
function setMenuImage(url)  { const c = getConfig(); c.menuImage = url; saveConfig(c); }

function getMenuVideo()     { return getConfig().menuVideo || ''; }
function setMenuVideo(url)  { const c = getConfig(); c.menuVideo = url; saveConfig(c); }

function getOwnerName()     { return getConfig().ownerName; }
function setOwnerName(name) { const c = getConfig(); c.ownerName = name; saveConfig(c); }

function isAntideletePrivateEnabled()    { return getConfig().antideletePrivate !== false; }
function setAntideletePrivate(enabled)   { const c = getConfig(); c.antideletePrivate = enabled; saveConfig(c); }

function getBotFont()       { return getConfig().botFont || 'none'; }
function setBotFont(font)   { const c = getConfig(); c.botFont = font; saveConfig(c); }

function updateConfig(updates) {
    const config = getConfig();
    Object.assign(config, updates);
    saveConfig(config);
}

module.exports = {
    getBotName,
    setBotName,
    getMenuImage,
    setMenuImage,
    getMenuVideo,
    setMenuVideo,
    getOwnerName,
    setOwnerName,
    isAntideletePrivateEnabled,
    setAntideletePrivate,
    getBotFont,
    setBotFont,
    getConfig,
    updateConfig
};
