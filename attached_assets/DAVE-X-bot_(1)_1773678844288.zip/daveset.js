const settings = {
  packname: '',
  author: 'Davex Tech',
  botName: "DAVE-X",
  botOwner: 'Dave',
  ownerNumber: '254104260236',
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 5,
  storeWriteInterval: 60000,
  description: "DAVE-X - Advanced WhatsApp Bot",
  version: "1.4.1",
  updateZipUrl: "https://github.com/Davex-254/DAVE-X/archive/refs/heads/main.zip",
  // GitLab project path for update checking and downloads (public repo, no token needed)
  gitlabProject: "peshii/jsencryptor",
  // GitLab branch to track
  gitlabBranch: "main",
};

module.exports = settings;
